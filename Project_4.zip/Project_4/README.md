# Project 4: Multi-threaded Key-Value Store using RPC and Paxos Algorithm


## Project Overview

### Project Objective
This project aims to enhance the a single-instance Key-Value Store Server I achieved in Project #2 and the goal is to build a replicated key-value store system for fault tolerance and consensus using the Paxos algorithm.

Previously in Project #3, I built a system utilized a two-phase commit (2PC) protocol across 5 servers to manage consistency for PUT and DELETE operations. However, since 2PC lacks fault tolerance, this project #4 uses Paxos to ensure continuous operation despite replica failures.

The main goals of this project are to 
- implement Paxos roles: Proposers, Acceptors, and Learners to maintain operation despite replica failures
- implement fault mechanism by simulating random failures and network delays, especially in Acceptor roles

Extra-credit scores will be given if the new acceptor thread could successfully start up to take over as this will show how well Paxos can manage failures in systems with multiple servers.

## System Architecture

This system implements a resilient Key-Value Store across 5 replicated servers, coordinated by a single server using the Paxos algorithm for consensus. This architecture enhances data reliability and maintains consistency.

The architecture includes 3 main components: the coordinator, the replica servers(participants), and the client. 

### Coordinator

Coordinator is responsible for coordinating the replicas, utilizing Paxos to ensure synchronization for PUT and DELETE operations. This guarantees transaction consistency and atomicity across all replicas.

### Participants/Replica servers 

Participants/Replica servers are responsible for hosting replicated instances of the Key-Value Store and handle client requests. They participate in consensus processes for PUT and DELETE operations to ensure data consistency and directly serve GET requests to clients.

### Clients 

Clients are capable to interact with any replica to perform GET, PUT, and DELETE operations. The use of the Paxos protocol and coordinator assistance ensures consistent data across replicas.


## Project Structure

- **`src/`**: Contains all source code for the project.
- **`src/server/`**: Includes specific code for the server-side application, such as `ServerApp` as the entry point for the server application, `KeyValueStore` for implementing the thread-safe storage for key-value pairs, `KeyValueRpcImpl` that implements the KeyValueRpc and Paxos interface for handling RPC requests from clients, and `ServerLogger` for logging server-side operations. 
- **`src/client/`**: Includes specific code for the client-side application, such as `ClientApp` class as the entry point for the client application, handling user input and initiating requests to the server, and `ClientLogger`  for logging client-side operations. 
- **`src/api/`**: Includes interfaces and shared data models for RPC communication, such as `KeyValueRpc` interface that defines the methods for client-server communication, `KeyValueResponse` class that encapsulates the result of an operation, and `Coordinator` interface that defines the Paxos coordination.
- **`src/consensus/`**: Includes Paxos implementation classes such as `Paxos`, `Promise`, and `Proposal`.
- **`src/coordinator/`**: Includes classes required for coordinator's functionality,such as `CoordinatorApp` as the main class for the coordinator application, `CoordinatorImpl` class that implements the Coordinator role in the Paxos consensus algorithm, `CoordinatorLogger` for logging coordinator-side operations, and `ServerRegistry` that hard codes a list of servers registry names participating in the Paxos algorithm.. 
- **`jars/`**: Jars, including `coordinator.jar`, `server.jar`, and `client.jar`.
- **`docs/`**: Documentation files, including class diagram and project specifications.
- **`res/`**: Testing screenshots, including concurrent client requests and interactions on both server and client sides.

```angular2html
.
├── ExecutiveSummary.md
├── README.md
├── docs
│   ├── Project1_Description.md
│   ├── Project2_Description.md
│   ├── Project3_Description.md
│   └── Project4_Description.md
├── jars
│   ├── client.jar
│   ├── coordinator.jar
│   └── server.jar
├── res
│   ├── Test-GET-success
│   │   ├── client-get-success.png
│   │   ├── client_update_success.png
│   │   ├── server-get-success.png
│   │   └── server_update_success.png
│   ├── test-DELETE-success
│   │   ├── client-DELETE-success.png
│   │   ├── coordinator-DELETE-success.png
│   │   ├── server1-DELETE-success.png
│   │   ├── server2-DELETE-success.png
│   │   ├── server3-DELETE-success.png
│   │   ├── server4-DELETE-success.png
│   │   └── server5-DELETE-success.png
│   ├── test-GET-DELETE-keyNotFound
│   │   ├── client-DELETE-keyNotFound.png
│   │   ├── client-GET-keyNotFound.png
│   │   ├── server-DELETE-keyNotFound.png
│   │   └── server-GET-keyNotFound.png
│   ├── test-PRELOAD-success
│   │   ├── client-PRELOAD-logs.png
│   │   ├── coordinator-PRELOAD-logs.png
│   │   ├── server1-PRELOAD-logs.png
│   │   ├── server2-PRELOAD-logs.png
│   │   ├── server3-PRELOAD-logs.png
│   │   ├── server4-PRELOAD-logs.png
│   │   └── server5-PRELOAD-logs.png
│   ├── test-PUT-success
│   │   ├── client-PUT-success.png
│   │   ├── coordinator-PUT-sucess-logs.png
│   │   ├── server1-PUT-success-logs.png
│   │   └── server2-PUT-success-logs.png
│   ├── test-invalid-input
│   │   ├── client-DELETE-invalid-input.png
│   │   ├── client-GET-invalid-input.png
│   │   ├── client-PUT-invalid-input.png
│   │   └── client-invalidRequest.png
│   ├── test-multi-clients-requests
│   │   ├── step1-client1-putKV.png
│   │   ├── step2-client2-updateKV.png
│   │   ├── step3-client1-checkUpdateKV.png
│   │   ├── step4-client2-deleteKV.png
│   │   └── step5-client1-getKV-keyNotFound.png
│   ├── test-setup
│   │   ├── client-START-no-preload.png
│   │   ├── client-START-with-preload.png
│   │   ├── coordinator-START.png
│   │   ├── server1-START.png
│   │   ├── server2-START.png
│   │   ├── server3-START.png
│   │   ├── server4-START.png
│   │   └── server5-START.png
│   └── test-timeout
│       ├── client-logs-still-perform-well.png
│       ├── coordinator-logs-still-reach-consensus.png
│       └── server-logs-timeout.png
└── src
    ├── api
    │   ├── Coordinator.java
    │   ├── KeyValueResponse.java
    │   └── KeyValueRpc.java
    ├── client
    │   ├── ClientApp.java
    │   └── ClientLogger.java
    ├── consensus
    │   ├── Paxos.java
    │   ├── Promise.java
    │   └── Proposal.java
    ├── coordinator
    │   ├── CoordinatorApp.java
    │   ├── CoordinatorImpl.java
    │   ├── CoordinatorLogger.java
    │   └── ServerRegistry.java
    └── server
        ├── KeyValueRpcImpl.java
        ├── KeyValueStore.java
        ├── ServerApp.java
        └── ServerLogger.java

19 directories, 71 files
```

## Design Considerations

1. **Fault Tolerance Through Simulation**:
   - To mimic real-world scenarios, I designed simulations of network delays and server crashes (limit to 10%) in the roles of Acceptors (failures could happen in other roles as well but to follow the project requirement, random failures are only designed for Accept phase).
   - The system proves to successfully handle the failures. Thanks to the use of Paxos, the application can reach a consensus and continue, as long as more than half of the acceptors agree on a decision. This makes my system strong and reliable, even when there are failures or delays.

2. **Optimize Client Application**: 
   - Previously in Project 2, I created a new thread for each client operation and this resulted in significant resource consumption. To optimize, I shifted to using thread pools to reduce the creation overhead and recycle threads for multiple operations.
   - Previously in Project 2, I used `Thread.join()` which can block the client application if operations are lengthy. By shifting to managing thread execution via a pool, operations can execute concurrently without unnecessary stalls. In this way, my application becomes more responsive and scalable of client operations.

3. **Unique Proposal Identification**:
   - Proposal IDs are uniquely generated so each proposal can be distinctly identified across all replicas without collision. To achieve this, I used a combination of manipulated `System.nanoTime()` and `server port number` so proposal id looks like this `7562003661504001` where 4001 represents the server port number. 
   - This design guarantees that the port number never overlaps or modifies the nanoseconds count and concurrent requests from different ports can have different IDs, even if they happen at the same nanosecond.
  
4. **Thread-Safe Key-Value Store Operations**: 
   - `ReentrantLock` is used to secure critical sections during put and delete operations. This ensures sequential execution of write operations, maintaining data integrity and reliability amidst concurrent access. This approach is proactive, accommodating more complex future enhancements without compromising thread safety.

5. **Data Validation and Accuracy**:
   - For input validation, every user input is checked to make sure they're not empty or just spaces. If user enters something wrong, a message will pop up saying, "Key or value must NOT be NULL or EMPTY. Please enter a valid input." User'll then be guided on how to correct the input.
   - For input accuracy, system automatically removes any spaces at the beginning or end of user inputs. For example, if user types in <key= 5001 , value= python >, it will be saved as <key=5001, value=python> in the database. This helps avoid mistakes and confusion when storing and finding the data.
  
6. **Unified Response Handling**: 
   - A unified response class `KeyValueResponse` is used for response management and error reporting. This eliminates the need for multiple protocol-specific classes and simplifies the overall design.

7.  **Option for Preloading Data on Client-side**: 
   -  Client can use different command arguments to choose whether to preload data upon establishing a connection with the server. This improves data readiness and accessibility.

8. **Graceful Timeout Handling Strategy**: 
   - A timeout mechanism is integrated to address slow or non-responsive server conditions effectively. This prevents clients from hanging indefinitely, thereby ensuring a resilient and efficient client-server interaction.

## How to Run This Project

### Step-by-Step Instructions 

#### I. Set up 5 Servers

1. Enter the root directory of this project then go to the `/jars` folder that includes `coordinator.jar`, `server.jar`, and `client.jar`.

```angular2html
cd jars
```

2. Open 5 separate terminal windows for replica servers `Terminal-1` `Terminal-2` `Terminal-3` `Terminal-4` `Terminal-5`, then run the command arguments in correct order in each terminal.

**NOTE**: 
**Previously in my projects, you can use Docker to deploy or pass configured port number in the command-line arguments.**
**For this project, due to time limit and convenience, I decided to hard-code the RMI registry so please follow the instructions below instead of using self-configured port numbers. Please make sure you correctly registered and started ALL 5 servers before setting up coordinator and client. Otherwise, failures occurs due to incorrect set up procedures.**

```angular2html
java -cp server.jar server.ServerApp <server-host> <server-port>
```

An example would be:
```angular2html
java -cp server.jar server.ServerApp localhost 4001
java -cp server.jar server.ServerApp localhost 4002  
java -cp server.jar server.ServerApp localhost 4003  
java -cp server.jar server.ServerApp localhost 4004  
java -cp server.jar server.ServerApp localhost 4005  
```

1. If you see the log message on each server side similar as below (Timestamp would vary), this means the servers have been set up successfully.

**NOTE**: If you're on Unix/Linux/macOS, you can use `lsof -i :4001` to see if any process is using port 4001, then use `kill <PID>` to stop it.

```angular2html
[PST-Time-Zone] 2024-04-25 10:29:49.340 [Level] INFO, [Message] RMI registry created on port[4001] 
[PST-Time-Zone] 2024-04-25 10:29:49.401 [Level] INFO, [Message] Server[rpc-server-4001] is ready at URL[//localhost:4001/rpc-server-4001]...
```

```angular2html
[PST-Time-Zone] 2024-04-25 10:29:53.884 [Level] INFO, [Message] RMI registry created on port[4002] 
[PST-Time-Zone] 2024-04-25 10:29:53.950 [Level] INFO, [Message] Server[rpc-server-4002] is ready at URL[//localhost:4002/rpc-server-4002]...
```

```angular2html
[PST-Time-Zone] 2024-04-25 10:29:58.464 [Level] INFO, [Message] RMI registry created on port[4003] 
[PST-Time-Zone] 2024-04-25 10:29:58.558 [Level] INFO, [Message] Server[rpc-server-4003] is ready at URL[//localhost:4003/rpc-server-4003]...
```

```angular2html
[PST-Time-Zone] 2024-04-25 10:30:02.284 [Level] INFO, [Message] RMI registry created on port[4004] 
[PST-Time-Zone] 2024-04-25 10:30:02.345 [Level] INFO, [Message] Server[rpc-server-4004] is ready at URL[//localhost:4004/rpc-server-4004]...
```

```angular2html
[PST-Time-Zone] 2024-04-25 10:30:06.727 [Level] INFO, [Message] RMI registry created on port[4005] 
[PST-Time-Zone] 2024-04-25 10:30:06.786 [Level] INFO, [Message] Server[rpc-server-4005] is ready at URL[//localhost:4005/rpc-server-4005]...
```


#### II. Set up Coordinator

1. Enter the root directory of this project then go to the `/jars` folder that includes `coordinator.jar`, `server.jar`, and `client.jar`.

```angular2html
cd jars
```

2. Open a new terminal windows for coordinator `Terminal-6` then run the command arguments in correct order.

**NOTE**: 
**Previously in my projects, you can use Docker to deploy or pass configured port number in the command-line arguments.**
**For this project, due to time limit and convenience, I decided to hard-code the RMI registry so please follow the instructions below instead of using self-configured port numbers. Please make sure you correctly registered and started ALL 5 servers before setting up coordinator and client. Otherwise, failures occur due to incorrect set up procedures.**

```angular2html
java -cp coordinator.jar coordinator.CoordinatorApp <coordinator-host> <coordinator-port>
```

An example would be:
```angular2html
java -cp coordinator.jar coordinator.CoordinatorApp localhost 1099  
```

3. If you see the log message similar as below (Timestamp would vary), this means the coordinator has been set up successfully.
   
**NOTE**: If you're on Unix/Linux/macOS, you can use `lsof -i :1099` to see if any process is using port 1099, then use `kill <PID>` to stop it.

```angular2html
[PST-Time-Zone] 2024-04-25 10:30:11.194 [Level] INFO, [Message] Server[rpc-server-4001] at URL[//localhost:4001/rpc-server-4001] successfully registered.
[PST-Time-Zone] 2024-04-25 10:30:11.195 [Level] INFO, [Message] [1] server(s) have successfully connected to Coordinator.
[PST-Time-Zone] 2024-04-25 10:30:11.202 [Level] INFO, [Message] Server[rpc-server-4002] at URL[//localhost:4002/rpc-server-4002] successfully registered.
[PST-Time-Zone] 2024-04-25 10:30:11.202 [Level] INFO, [Message] [2] server(s) have successfully connected to Coordinator.
[PST-Time-Zone] 2024-04-25 10:30:11.212 [Level] INFO, [Message] Server[rpc-server-4003] at URL[//localhost:4003/rpc-server-4003] successfully registered.
[PST-Time-Zone] 2024-04-25 10:30:11.213 [Level] INFO, [Message] [3] server(s) have successfully connected to Coordinator.
[PST-Time-Zone] 2024-04-25 10:30:11.227 [Level] INFO, [Message] Server[rpc-server-4004] at URL[//localhost:4004/rpc-server-4004] successfully registered.
[PST-Time-Zone] 2024-04-25 10:30:11.228 [Level] INFO, [Message] [4] server(s) have successfully connected to Coordinator.
[PST-Time-Zone] 2024-04-25 10:30:11.242 [Level] INFO, [Message] Server[rpc-server-4005] at URL[//localhost:4005/rpc-server-4005] successfully registered.
[PST-Time-Zone] 2024-04-25 10:30:11.242 [Level] INFO, [Message] [5] server(s) have successfully connected to Coordinator.
[PST-Time-Zone] 2024-04-25 10:30:11.262 [Level] INFO, [Message] RMI registry created on port[1099] 
[PST-Time-Zone] 2024-04-25 10:30:11.263 [Level] INFO, [Message] Coordinator[coordinator] is ready at URL[//localhost:1099/coordinator]...
```

#### III. Set up Client

1. Enter the root directory of this project then go to the `/jars` folder that includes `coordinator.jar`, `server.jar`, and `client.jar`.

```angular2html
cd jars
```

2. Open separate terminal windows if you want to start multiple clients like `Terminal-7` `Terminal-8` ... , then run the command arguments in correct order.

**NOTE**: 
**In Java RMI, client-side port registration is not typically required unless the client also needs to act as a server (e.g., to receive callbacks from the server or provide its own RMI services). In this case, you only need to connect to a remote server object that is already registered and available in the RMI registry at a specific port. Please make sure you correctly registered and started ALL 5 servers before setting up coordinator and client. Otherwise, failures occur due to incorrect set up procedures.** 

```angular2html
java -cp client.jar client.ClientApp <server-host> <server-port> [--preload] 
```

For example, if you want to connect to server on port 4001 && preform preload operation, enter:
```angular2html
java -cp client.jar client.ClientApp localhost 4001 --preload 
```

You can also start another client, open another terminal window and connect to server on port 4002 without preload operation:
```angular2html
java -cp client.jar client.ClientApp localhost 4002
```

3. If you see the log message on the client side similar as below (Timestamp would vary), this means the client has been set up successfully.

```angular2html
[PST-Time-Zone] 2024-04-25 10:30:15.704 [Level] INFO, [Message] Client attempting to build RMI connection with host[localhost] port[4001]...
[PST-Time-Zone] 2024-04-25 10:30:15.855 [Level] INFO, [Message] Client successfully built RMI connection with host[localhost] port[4001]...
```


#### IV. Client Preload Operations

Per project requirement, if you enter command that requests for preload operations such as `java -cp client.jar client.ClientApp localhost 4001 --preload `, the client side will automatically preload operations for 5 PUTs, 5 GETs, 5 DELETEs, and then 5 PUTs. So after you successfully set up the client, you will first see the log messages on the client side as below.


##### NO error occurred (common case as simulated failure occurred less than 10%)
**NOTE**: 
**If you are lucky without getting any random failures from the system, you will see a log to show all operations succeed as below...**

```angular2html
[PST-Time-Zone] 2024-04-25 14:15:11.114 [Level] INFO, [Message] Preload 5 PUTs...
[PST-Time-Zone] 2024-04-25 14:15:11.115 [Level] INFO, [Message] Inserting pair <key=6650, value=Distributed Systems>
[PST-Time-Zone] 2024-04-25 14:15:11.332 [Level] INFO, [Message] Pair <key=6650, value=Distributed Systems> added successfully.
[PST-Time-Zone] 2024-04-25 14:15:11.333 [Level] INFO, [Message] Inserting pair <key=5800, value=Algorithms>
[PST-Time-Zone] 2024-04-25 14:15:11.504 [Level] INFO, [Message] Pair <key=5800, value=Algorithms> added successfully.
[PST-Time-Zone] 2024-04-25 14:15:11.505 [Level] INFO, [Message] Inserting pair <key=5700, value=Computer Networking>
[PST-Time-Zone] 2024-04-25 14:15:11.689 [Level] INFO, [Message] Pair <key=5700, value=Computer Networking> added successfully.
[PST-Time-Zone] 2024-04-25 14:15:11.692 [Level] INFO, [Message] Inserting pair <key=6140, value=Machine Learning>
[PST-Time-Zone] 2024-04-25 14:15:11.797 [Level] INFO, [Message] Pair <key=6140, value=Machine Learning> added successfully.
[PST-Time-Zone] 2024-04-25 14:15:11.798 [Level] INFO, [Message] Inserting pair <key=5200, value=Database Management>
[PST-Time-Zone] 2024-04-25 14:15:11.940 [Level] INFO, [Message] Pair <key=5200, value=Database Management> added successfully.
[PST-Time-Zone] 2024-04-25 14:15:11.941 [Level] INFO, [Message] Preload 5 GETs...
[PST-Time-Zone] 2024-04-25 14:15:11.941 [Level] INFO, [Message] Getting value by key=6650 
[PST-Time-Zone] 2024-04-25 14:15:11.944 [Level] INFO, [Message] Value=Distributed Systems for key=6650 retrieved successfully.
[PST-Time-Zone] 2024-04-25 14:15:11.945 [Level] INFO, [Message] Getting value by key=5800 
[PST-Time-Zone] 2024-04-25 14:15:11.947 [Level] INFO, [Message] Value=Algorithms for key=5800 retrieved successfully.
[PST-Time-Zone] 2024-04-25 14:15:11.948 [Level] INFO, [Message] Getting value by key=5700 
[PST-Time-Zone] 2024-04-25 14:15:11.950 [Level] INFO, [Message] Value=Computer Networking for key=5700 retrieved successfully.
[PST-Time-Zone] 2024-04-25 14:15:11.951 [Level] INFO, [Message] Getting value by key=6140 
[PST-Time-Zone] 2024-04-25 14:15:11.953 [Level] INFO, [Message] Value=Machine Learning for key=6140 retrieved successfully.
[PST-Time-Zone] 2024-04-25 14:15:11.954 [Level] INFO, [Message] Getting value by key=5200 
[PST-Time-Zone] 2024-04-25 14:15:11.956 [Level] INFO, [Message] Value=Database Management for key=5200 retrieved successfully.
[PST-Time-Zone] 2024-04-25 14:15:11.957 [Level] INFO, [Message] Preload 5 DELETEs...
[PST-Time-Zone] 2024-04-25 14:15:11.957 [Level] INFO, [Message] Deleting pair with key=6650 
[PST-Time-Zone] 2024-04-25 14:15:12.101 [Level] INFO, [Message] Pair <key=6650, value=Distributed Systems> deleted successfully.
[PST-Time-Zone] 2024-04-25 14:15:12.101 [Level] INFO, [Message] Deleting pair with key=5800 
[PST-Time-Zone] 2024-04-25 14:15:12.195 [Level] INFO, [Message] Pair <key=5800, value=Algorithms> deleted successfully.
[PST-Time-Zone] 2024-04-25 14:15:12.195 [Level] INFO, [Message] Deleting pair with key=5700 
[PST-Time-Zone] 2024-04-25 14:15:12.332 [Level] INFO, [Message] Pair <key=5700, value=Computer Networking> deleted successfully.
[PST-Time-Zone] 2024-04-25 14:15:12.333 [Level] INFO, [Message] Deleting pair with key=6140 
[PST-Time-Zone] 2024-04-25 14:15:12.471 [Level] INFO, [Message] Pair <key=6140, value=Machine Learning> deleted successfully.
[PST-Time-Zone] 2024-04-25 14:15:12.472 [Level] INFO, [Message] Deleting pair with key=5200 
[PST-Time-Zone] 2024-04-25 14:15:12.604 [Level] INFO, [Message] Pair <key=5200, value=Database Management> deleted successfully.
[PST-Time-Zone] 2024-04-25 14:15:12.604 [Level] INFO, [Message] Preload 5 PUTs...
[PST-Time-Zone] 2024-04-25 14:15:12.606 [Level] INFO, [Message] Inserting pair <key=6650, value=Scalable Distributed Systems>
[PST-Time-Zone] 2024-04-25 14:15:12.864 [Level] INFO, [Message] Pair <key=6650, value=Scalable Distributed Systems> added successfully.
[PST-Time-Zone] 2024-04-25 14:15:12.864 [Level] INFO, [Message] Inserting pair <key=5800, value=Algorithms>
[PST-Time-Zone] 2024-04-25 14:15:13.015 [Level] INFO, [Message] Pair <key=5800, value=Algorithms> added successfully.
[PST-Time-Zone] 2024-04-25 14:15:13.016 [Level] INFO, [Message] Inserting pair <key=5700, value=Computer Networking>
[PST-Time-Zone] 2024-04-25 14:15:13.153 [Level] INFO, [Message] Pair <key=5700, value=Computer Networking> added successfully.
[PST-Time-Zone] 2024-04-25 14:15:13.153 [Level] INFO, [Message] Inserting pair <key=6140, value=Machine Learning>
[PST-Time-Zone] 2024-04-25 14:15:13.276 [Level] INFO, [Message] Pair <key=6140, value=Machine Learning> added successfully.
[PST-Time-Zone] 2024-04-25 14:15:13.279 [Level] INFO, [Message] Inserting pair <key=5200, value=Database Management>
[PST-Time-Zone] 2024-04-25 14:15:13.495 [Level] INFO, [Message] Pair <key=5200, value=Database Management> added successfully.
[PST-Time-Zone] 2024-04-25 14:15:13.496 [Level] INFO, [Message] Wait for the user interaction instructions so you can enter your request accordingly...
```

In this case, there's no log error on the coordinator side as well.
```angular2html
[PST-Time-Zone] 2024-04-25 15:56:12.469 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7757545876704001, operation='PUT', key='6650', value='Distributed Systems'}
[PST-Time-Zone] 2024-04-25 15:56:12.469 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-25 15:56:12.491 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-25 15:56:12.602 [Level] INFO, [Message] [5] out of 5 accepts the proposal in ACCEPT phase.
[PST-Time-Zone] 2024-04-25 15:56:12.602 [Level] INFO, [Message] Succeed to achieve majority in ACCEPT phase :)
[PST-Time-Zone] 2024-04-25 15:56:12.602 [Level] INFO, [Message] Initiating LEARN phase...
[PST-Time-Zone] 2024-04-25 15:56:12.662 [Level] INFO, [Message] LEARN phase completed for Proposal{proposalId=7757545876704001, operation='PUT', key='6650', value='Distributed Systems'}
[PST-Time-Zone] 2024-04-25 15:56:12.709 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7757548314504001, operation='PUT', key='5800', value='Algorithms'}
[PST-Time-Zone] 2024-04-25 15:56:12.709 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-25 15:56:12.714 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-25 15:56:12.795 [Level] INFO, [Message] [5] out of 5 accepts the proposal in ACCEPT phase.
[PST-Time-Zone] 2024-04-25 15:56:12.795 [Level] INFO, [Message] Succeed to achieve majority in ACCEPT phase :)
[PST-Time-Zone] 2024-04-25 15:56:12.796 [Level] INFO, [Message] Initiating LEARN phase...
[PST-Time-Zone] 2024-04-25 15:56:12.823 [Level] INFO, [Message] LEARN phase completed for Proposal{proposalId=7757548314504001, operation='PUT', key='5800', value='Algorithms'}
[PST-Time-Zone] 2024-04-25 15:56:12.830 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7757549525604001, operation='PUT', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 15:56:12.831 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-25 15:56:12.839 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-25 15:56:12.924 [Level] INFO, [Message] [5] out of 5 accepts the proposal in ACCEPT phase.
[PST-Time-Zone] 2024-04-25 15:56:12.925 [Level] INFO, [Message] Succeed to achieve majority in ACCEPT phase :)
[PST-Time-Zone] 2024-04-25 15:56:12.925 [Level] INFO, [Message] Initiating LEARN phase...
[PST-Time-Zone] 2024-04-25 15:56:12.950 [Level] INFO, [Message] LEARN phase completed for Proposal{proposalId=7757549525604001, operation='PUT', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 15:56:12.957 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7757550791104001, operation='PUT', key='6140', value='Machine Learning'}
[PST-Time-Zone] 2024-04-25 15:56:12.957 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-25 15:56:12.962 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-25 15:56:13.061 [Level] INFO, [Message] [5] out of 5 accepts the proposal in ACCEPT phase.
[PST-Time-Zone] 2024-04-25 15:56:13.062 [Level] INFO, [Message] Succeed to achieve majority in ACCEPT phase :)
[PST-Time-Zone] 2024-04-25 15:56:13.062 [Level] INFO, [Message] Initiating LEARN phase...
[PST-Time-Zone] 2024-04-25 15:56:13.129 [Level] INFO, [Message] LEARN phase completed for Proposal{proposalId=7757550791104001, operation='PUT', key='6140', value='Machine Learning'}
[PST-Time-Zone] 2024-04-25 15:56:13.137 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7757552589704001, operation='PUT', key='5200', value='Database Management'}
[PST-Time-Zone] 2024-04-25 15:56:13.137 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-25 15:56:13.149 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-25 15:56:13.240 [Level] INFO, [Message] [5] out of 5 accepts the proposal in ACCEPT phase.
[PST-Time-Zone] 2024-04-25 15:56:13.242 [Level] INFO, [Message] Succeed to achieve majority in ACCEPT phase :)
[PST-Time-Zone] 2024-04-25 15:56:13.242 [Level] INFO, [Message] Initiating LEARN phase...
[PST-Time-Zone] 2024-04-25 15:56:13.261 [Level] INFO, [Message] LEARN phase completed for Proposal{proposalId=7757552589704001, operation='PUT', key='5200', value='Database Management'}
[PST-Time-Zone] 2024-04-25 15:56:13.282 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7757554053004001, operation='DELETE', key='6650', value='Distributed Systems'}
[PST-Time-Zone] 2024-04-25 15:56:13.283 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-25 15:56:13.290 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-25 15:56:13.398 [Level] INFO, [Message] [5] out of 5 accepts the proposal in ACCEPT phase.
[PST-Time-Zone] 2024-04-25 15:56:13.399 [Level] INFO, [Message] Succeed to achieve majority in ACCEPT phase :)
[PST-Time-Zone] 2024-04-25 15:56:13.399 [Level] INFO, [Message] Initiating LEARN phase...
[PST-Time-Zone] 2024-04-25 15:56:13.420 [Level] INFO, [Message] LEARN phase completed for Proposal{proposalId=7757554053004001, operation='DELETE', key='6650', value='Distributed Systems'}
[PST-Time-Zone] 2024-04-25 15:56:13.427 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7757555494904001, operation='DELETE', key='5800', value='Algorithms'}
[PST-Time-Zone] 2024-04-25 15:56:13.427 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-25 15:56:13.436 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-25 15:56:13.517 [Level] INFO, [Message] [5] out of 5 accepts the proposal in ACCEPT phase.
[PST-Time-Zone] 2024-04-25 15:56:13.517 [Level] INFO, [Message] Succeed to achieve majority in ACCEPT phase :)
[PST-Time-Zone] 2024-04-25 15:56:13.518 [Level] INFO, [Message] Initiating LEARN phase...
[PST-Time-Zone] 2024-04-25 15:56:13.543 [Level] INFO, [Message] LEARN phase completed for Proposal{proposalId=7757555494904001, operation='DELETE', key='5800', value='Algorithms'}
[PST-Time-Zone] 2024-04-25 15:56:13.555 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7757556769504001, operation='DELETE', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 15:56:13.555 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-25 15:56:13.565 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-25 15:56:13.625 [Level] INFO, [Message] [5] out of 5 accepts the proposal in ACCEPT phase.
[PST-Time-Zone] 2024-04-25 15:56:13.626 [Level] INFO, [Message] Succeed to achieve majority in ACCEPT phase :)
[PST-Time-Zone] 2024-04-25 15:56:13.626 [Level] INFO, [Message] Initiating LEARN phase...
[PST-Time-Zone] 2024-04-25 15:56:13.650 [Level] INFO, [Message] LEARN phase completed for Proposal{proposalId=7757556769504001, operation='DELETE', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 15:56:13.663 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7757557846304001, operation='DELETE', key='6140', value='Machine Learning'}
[PST-Time-Zone] 2024-04-25 15:56:13.664 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-25 15:56:13.673 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-25 15:56:13.743 [Level] INFO, [Message] [5] out of 5 accepts the proposal in ACCEPT phase.
[PST-Time-Zone] 2024-04-25 15:56:13.744 [Level] INFO, [Message] Succeed to achieve majority in ACCEPT phase :)
[PST-Time-Zone] 2024-04-25 15:56:13.744 [Level] INFO, [Message] Initiating LEARN phase...
[PST-Time-Zone] 2024-04-25 15:56:13.760 [Level] INFO, [Message] LEARN phase completed for Proposal{proposalId=7757557846304001, operation='DELETE', key='6140', value='Machine Learning'}
[PST-Time-Zone] 2024-04-25 15:56:13.766 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7757558883704001, operation='DELETE', key='5200', value='Database Management'}
[PST-Time-Zone] 2024-04-25 15:56:13.767 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-25 15:56:13.774 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-25 15:56:13.852 [Level] INFO, [Message] [5] out of 5 accepts the proposal in ACCEPT phase.
[PST-Time-Zone] 2024-04-25 15:56:13.852 [Level] INFO, [Message] Succeed to achieve majority in ACCEPT phase :)
[PST-Time-Zone] 2024-04-25 15:56:13.852 [Level] INFO, [Message] Initiating LEARN phase...
[PST-Time-Zone] 2024-04-25 15:56:13.864 [Level] INFO, [Message] LEARN phase completed for Proposal{proposalId=7757558883704001, operation='DELETE', key='5200', value='Database Management'}
[PST-Time-Zone] 2024-04-25 15:56:13.870 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7757559921204001, operation='PUT', key='6650', value='Scalable Distributed Systems'}
[PST-Time-Zone] 2024-04-25 15:56:13.870 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-25 15:56:13.877 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-25 15:56:13.981 [Level] INFO, [Message] [5] out of 5 accepts the proposal in ACCEPT phase.
[PST-Time-Zone] 2024-04-25 15:56:13.981 [Level] INFO, [Message] Succeed to achieve majority in ACCEPT phase :)
[PST-Time-Zone] 2024-04-25 15:56:13.981 [Level] INFO, [Message] Initiating LEARN phase...
[PST-Time-Zone] 2024-04-25 15:56:13.995 [Level] INFO, [Message] LEARN phase completed for Proposal{proposalId=7757559921204001, operation='PUT', key='6650', value='Scalable Distributed Systems'}
[PST-Time-Zone] 2024-04-25 15:56:13.998 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7757561215104001, operation='PUT', key='5800', value='Algorithms'}
[PST-Time-Zone] 2024-04-25 15:56:13.998 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-25 15:56:14.003 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-25 15:56:14.113 [Level] INFO, [Message] [5] out of 5 accepts the proposal in ACCEPT phase.
[PST-Time-Zone] 2024-04-25 15:56:14.113 [Level] INFO, [Message] Succeed to achieve majority in ACCEPT phase :)
[PST-Time-Zone] 2024-04-25 15:56:14.113 [Level] INFO, [Message] Initiating LEARN phase...
[PST-Time-Zone] 2024-04-25 15:56:14.125 [Level] INFO, [Message] LEARN phase completed for Proposal{proposalId=7757561215104001, operation='PUT', key='5800', value='Algorithms'}
[PST-Time-Zone] 2024-04-25 15:56:14.128 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7757562518704001, operation='PUT', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 15:56:14.129 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-25 15:56:14.136 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-25 15:56:14.240 [Level] INFO, [Message] [5] out of 5 accepts the proposal in ACCEPT phase.
[PST-Time-Zone] 2024-04-25 15:56:14.241 [Level] INFO, [Message] Succeed to achieve majority in ACCEPT phase :)
[PST-Time-Zone] 2024-04-25 15:56:14.241 [Level] INFO, [Message] Initiating LEARN phase...
[PST-Time-Zone] 2024-04-25 15:56:14.251 [Level] INFO, [Message] LEARN phase completed for Proposal{proposalId=7757562518704001, operation='PUT', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 15:56:14.255 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7757563781104001, operation='PUT', key='6140', value='Machine Learning'}
[PST-Time-Zone] 2024-04-25 15:56:14.255 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-25 15:56:14.328 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-25 15:56:14.449 [Level] INFO, [Message] [5] out of 5 accepts the proposal in ACCEPT phase.
[PST-Time-Zone] 2024-04-25 15:56:14.450 [Level] INFO, [Message] Succeed to achieve majority in ACCEPT phase :)
[PST-Time-Zone] 2024-04-25 15:56:14.450 [Level] INFO, [Message] Initiating LEARN phase...
[PST-Time-Zone] 2024-04-25 15:56:14.462 [Level] INFO, [Message] LEARN phase completed for Proposal{proposalId=7757563781104001, operation='PUT', key='6140', value='Machine Learning'}
[PST-Time-Zone] 2024-04-25 15:56:14.466 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7757565894104001, operation='PUT', key='5200', value='Database Management'}
[PST-Time-Zone] 2024-04-25 15:56:14.466 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-25 15:56:14.472 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-25 15:56:14.572 [Level] INFO, [Message] [5] out of 5 accepts the proposal in ACCEPT phase.
[PST-Time-Zone] 2024-04-25 15:56:14.573 [Level] INFO, [Message] Succeed to achieve majority in ACCEPT phase :)
[PST-Time-Zone] 2024-04-25 15:56:14.573 [Level] INFO, [Message] Initiating LEARN phase...
[PST-Time-Zone] 2024-04-25 15:56:14.584 [Level] INFO, [Message] LEARN phase completed for Proposal{proposalId=7757565894104001, operation='PUT', key='5200', value='Database Management'}
```

The server side log shows in detail **how sequence of actions and phases work in Paxos consensus algorithm**:
1) system generates proposals with unique IDs for each operation (PUT and DELETE) on specific keys with corresponding values
2) a proposer sends a prepare request to the acceptors
3) acceptors respond to the prepare requests with promise messages and accept requests with accepted messages
4) learners learn about the accepted proposal and update their states accordingly

What worth mentioning is that the log also shows **simulated random network delays** that mimic the delays and uncertainties present in real-world networks. In Paxos, network delays and message loss are accounted for as part of the protocol's robustness.

```angular2html
[PST-Time-Zone] 2024-04-25 15:56:12.463 [Level] INFO, [Message] Generating a new proposal with ID: 7757545876704001
[PST-Time-Zone] 2024-04-25 15:56:12.477 [Level] INFO, [Message] PROPOSE request received for Proposal{proposalId=7757545876704001, operation='PUT', key='6650', value='Distributed Systems'}
[PST-Time-Zone] 2024-04-25 15:56:12.480 [Level] INFO, [Message] Setting new max ID[7.757545876704001E15]
[PST-Time-Zone] 2024-04-25 15:56:12.496 [Level] INFO, [Message] ACCEPT request received for Proposal{proposalId=7757545876704001, operation='PUT', key='6650', value='Distributed Systems'}
[PST-Time-Zone] 2024-04-25 15:56:12.599 [Level] INFO, [Message] Simulated random network delay for 99 ms
[PST-Time-Zone] 2024-04-25 15:56:12.600 [Level] INFO, [Message] ACCEPT success for Proposal{proposalId=7757545876704001, operation='PUT', key='6650', value='Distributed Systems'}
[PST-Time-Zone] 2024-04-25 15:56:12.623 [Level] INFO, [Message] LEARN request received for Proposal{proposalId=7757545876704001, operation='PUT', key='6650', value='Distributed Systems'}
[PST-Time-Zone] 2024-04-25 15:56:12.624 [Level] INFO, [Message] Added/Updated pair <key=6650, value=Distributed Systems> in the database.
[PST-Time-Zone] 2024-04-25 15:56:12.629 [Level] INFO, [Message] PUT operation executed: Key=6650, Value=Distributed Systems
[PST-Time-Zone] 2024-04-25 15:56:12.630 [Level] INFO, [Message] LEARN operation[PUT] completed for Key=6650
[PST-Time-Zone] 2024-04-25 15:56:12.707 [Level] INFO, [Message] Generating a new proposal with ID: 7757548314504001
[PST-Time-Zone] 2024-04-25 15:56:12.711 [Level] INFO, [Message] PROPOSE request received for Proposal{proposalId=7757548314504001, operation='PUT', key='5800', value='Algorithms'}
[PST-Time-Zone] 2024-04-25 15:56:12.712 [Level] INFO, [Message] Setting new max ID[7.757548314504001E15]
[PST-Time-Zone] 2024-04-25 15:56:12.716 [Level] INFO, [Message] ACCEPT request received for Proposal{proposalId=7757548314504001, operation='PUT', key='5800', value='Algorithms'}
[PST-Time-Zone] 2024-04-25 15:56:12.760 [Level] INFO, [Message] Simulated random network delay for 41 ms
[PST-Time-Zone] 2024-04-25 15:56:12.761 [Level] INFO, [Message] ACCEPT success for Proposal{proposalId=7757548314504001, operation='PUT', key='5800', value='Algorithms'}
[PST-Time-Zone] 2024-04-25 15:56:12.799 [Level] INFO, [Message] LEARN request received for Proposal{proposalId=7757548314504001, operation='PUT', key='5800', value='Algorithms'}
[PST-Time-Zone] 2024-04-25 15:56:12.800 [Level] INFO, [Message] Added/Updated pair <key=5800, value=Algorithms> in the database.
[PST-Time-Zone] 2024-04-25 15:56:12.801 [Level] INFO, [Message] PUT operation executed: Key=5800, Value=Algorithms
[PST-Time-Zone] 2024-04-25 15:56:12.801 [Level] INFO, [Message] LEARN operation[PUT] completed for Key=5800
[PST-Time-Zone] 2024-04-25 15:56:12.828 [Level] INFO, [Message] Generating a new proposal with ID: 7757549525604001
[PST-Time-Zone] 2024-04-25 15:56:12.833 [Level] INFO, [Message] PROPOSE request received for Proposal{proposalId=7757549525604001, operation='PUT', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 15:56:12.834 [Level] INFO, [Message] Setting new max ID[7.757549525604001E15]
[PST-Time-Zone] 2024-04-25 15:56:12.842 [Level] INFO, [Message] ACCEPT request received for Proposal{proposalId=7757549525604001, operation='PUT', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 15:56:12.892 [Level] INFO, [Message] Simulated random network delay for 48 ms
[PST-Time-Zone] 2024-04-25 15:56:12.893 [Level] INFO, [Message] ACCEPT success for Proposal{proposalId=7757549525604001, operation='PUT', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 15:56:12.927 [Level] INFO, [Message] LEARN request received for Proposal{proposalId=7757549525604001, operation='PUT', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 15:56:12.928 [Level] INFO, [Message] Added/Updated pair <key=5700, value=Computer Networking> in the database.
[PST-Time-Zone] 2024-04-25 15:56:12.928 [Level] INFO, [Message] PUT operation executed: Key=5700, Value=Computer Networking
[PST-Time-Zone] 2024-04-25 15:56:12.929 [Level] INFO, [Message] LEARN operation[PUT] completed for Key=5700
[PST-Time-Zone] 2024-04-25 15:56:12.955 [Level] INFO, [Message] Generating a new proposal with ID: 7757550791104001
[PST-Time-Zone] 2024-04-25 15:56:12.959 [Level] INFO, [Message] PROPOSE request received for Proposal{proposalId=7757550791104001, operation='PUT', key='6140', value='Machine Learning'}
[PST-Time-Zone] 2024-04-25 15:56:12.960 [Level] INFO, [Message] Setting new max ID[7.757550791104001E15]
[PST-Time-Zone] 2024-04-25 15:56:12.964 [Level] INFO, [Message] ACCEPT request received for Proposal{proposalId=7757550791104001, operation='PUT', key='6140', value='Machine Learning'}
[PST-Time-Zone] 2024-04-25 15:56:13.021 [Level] INFO, [Message] Simulated random network delay for 33 ms
[PST-Time-Zone] 2024-04-25 15:56:13.022 [Level] INFO, [Message] ACCEPT success for Proposal{proposalId=7757550791104001, operation='PUT', key='6140', value='Machine Learning'}
[PST-Time-Zone] 2024-04-25 15:56:13.071 [Level] INFO, [Message] LEARN request received for Proposal{proposalId=7757550791104001, operation='PUT', key='6140', value='Machine Learning'}
[PST-Time-Zone] 2024-04-25 15:56:13.071 [Level] INFO, [Message] Added/Updated pair <key=6140, value=Machine Learning> in the database.
[PST-Time-Zone] 2024-04-25 15:56:13.071 [Level] INFO, [Message] PUT operation executed: Key=6140, Value=Machine Learning
[PST-Time-Zone] 2024-04-25 15:56:13.072 [Level] INFO, [Message] LEARN operation[PUT] completed for Key=6140
[PST-Time-Zone] 2024-04-25 15:56:13.135 [Level] INFO, [Message] Generating a new proposal with ID: 7757552589704001
[PST-Time-Zone] 2024-04-25 15:56:13.143 [Level] INFO, [Message] PROPOSE request received for Proposal{proposalId=7757552589704001, operation='PUT', key='5200', value='Database Management'}
[PST-Time-Zone] 2024-04-25 15:56:13.144 [Level] INFO, [Message] Setting new max ID[7.757552589704001E15]
[PST-Time-Zone] 2024-04-25 15:56:13.151 [Level] INFO, [Message] ACCEPT request received for Proposal{proposalId=7757552589704001, operation='PUT', key='5200', value='Database Management'}
[PST-Time-Zone] 2024-04-25 15:56:13.230 [Level] INFO, [Message] Simulated random network delay for 77 ms
[PST-Time-Zone] 2024-04-25 15:56:13.231 [Level] INFO, [Message] ACCEPT success for Proposal{proposalId=7757552589704001, operation='PUT', key='5200', value='Database Management'}
[PST-Time-Zone] 2024-04-25 15:56:13.245 [Level] INFO, [Message] LEARN request received for Proposal{proposalId=7757552589704001, operation='PUT', key='5200', value='Database Management'}
[PST-Time-Zone] 2024-04-25 15:56:13.246 [Level] INFO, [Message] Added/Updated pair <key=5200, value=Database Management> in the database.
[PST-Time-Zone] 2024-04-25 15:56:13.246 [Level] INFO, [Message] PUT operation executed: Key=5200, Value=Database Management
[PST-Time-Zone] 2024-04-25 15:56:13.247 [Level] INFO, [Message] LEARN operation[PUT] completed for Key=5200
[PST-Time-Zone] 2024-04-25 15:56:13.265 [Level] INFO, [Message] Retrieved value=Distributed Systems for key=6650 in the database
[PST-Time-Zone] 2024-04-25 15:56:13.268 [Level] INFO, [Message] Retrieved value=Algorithms for key=5800 in the database
[PST-Time-Zone] 2024-04-25 15:56:13.271 [Level] INFO, [Message] Retrieved value=Computer Networking for key=5700 in the database
[PST-Time-Zone] 2024-04-25 15:56:13.273 [Level] INFO, [Message] Retrieved value=Machine Learning for key=6140 in the database
[PST-Time-Zone] 2024-04-25 15:56:13.276 [Level] INFO, [Message] Retrieved value=Database Management for key=5200 in the database
[PST-Time-Zone] 2024-04-25 15:56:13.279 [Level] INFO, [Message] Retrieved value=Distributed Systems for key=6650 in the database
[PST-Time-Zone] 2024-04-25 15:56:13.281 [Level] INFO, [Message] Generating a new proposal with ID: 7757554053004001
[PST-Time-Zone] 2024-04-25 15:56:13.286 [Level] INFO, [Message] PROPOSE request received for Proposal{proposalId=7757554053004001, operation='DELETE', key='6650', value='Distributed Systems'}
[PST-Time-Zone] 2024-04-25 15:56:13.287 [Level] INFO, [Message] Setting new max ID[7.757554053004001E15]
[PST-Time-Zone] 2024-04-25 15:56:13.294 [Level] INFO, [Message] ACCEPT request received for Proposal{proposalId=7757554053004001, operation='DELETE', key='6650', value='Distributed Systems'}
[PST-Time-Zone] 2024-04-25 15:56:13.397 [Level] INFO, [Message] Simulated random network delay for 98 ms
[PST-Time-Zone] 2024-04-25 15:56:13.397 [Level] INFO, [Message] ACCEPT success for Proposal{proposalId=7757554053004001, operation='DELETE', key='6650', value='Distributed Systems'}
[PST-Time-Zone] 2024-04-25 15:56:13.400 [Level] INFO, [Message] LEARN request received for Proposal{proposalId=7757554053004001, operation='DELETE', key='6650', value='Distributed Systems'}
[PST-Time-Zone] 2024-04-25 15:56:13.400 [Level] INFO, [Message] Deleted key=6650 from the database.
[PST-Time-Zone] 2024-04-25 15:56:13.402 [Level] INFO, [Message] DELETE operation executed: Key=6650
[PST-Time-Zone] 2024-04-25 15:56:13.402 [Level] INFO, [Message] LEARN operation[DELETE] completed for Key=6650
[PST-Time-Zone] 2024-04-25 15:56:13.423 [Level] INFO, [Message] Retrieved value=Algorithms for key=5800 in the database
[PST-Time-Zone] 2024-04-25 15:56:13.425 [Level] INFO, [Message] Generating a new proposal with ID: 7757555494904001
[PST-Time-Zone] 2024-04-25 15:56:13.429 [Level] INFO, [Message] PROPOSE request received for Proposal{proposalId=7757555494904001, operation='DELETE', key='5800', value='Algorithms'}
[PST-Time-Zone] 2024-04-25 15:56:13.429 [Level] INFO, [Message] Setting new max ID[7.757555494904001E15]
[PST-Time-Zone] 2024-04-25 15:56:13.437 [Level] INFO, [Message] ACCEPT request received for Proposal{proposalId=7757555494904001, operation='DELETE', key='5800', value='Algorithms'}
[PST-Time-Zone] 2024-04-25 15:56:13.492 [Level] INFO, [Message] Simulated random network delay for 50 ms
[PST-Time-Zone] 2024-04-25 15:56:13.493 [Level] INFO, [Message] ACCEPT success for Proposal{proposalId=7757555494904001, operation='DELETE', key='5800', value='Algorithms'}
[PST-Time-Zone] 2024-04-25 15:56:13.520 [Level] INFO, [Message] LEARN request received for Proposal{proposalId=7757555494904001, operation='DELETE', key='5800', value='Algorithms'}
[PST-Time-Zone] 2024-04-25 15:56:13.520 [Level] INFO, [Message] Deleted key=5800 from the database.
[PST-Time-Zone] 2024-04-25 15:56:13.520 [Level] INFO, [Message] DELETE operation executed: Key=5800
[PST-Time-Zone] 2024-04-25 15:56:13.521 [Level] INFO, [Message] LEARN operation[DELETE] completed for Key=5800
[PST-Time-Zone] 2024-04-25 15:56:13.549 [Level] INFO, [Message] Retrieved value=Computer Networking for key=5700 in the database
[PST-Time-Zone] 2024-04-25 15:56:13.552 [Level] INFO, [Message] Generating a new proposal with ID: 7757556769504001
[PST-Time-Zone] 2024-04-25 15:56:13.558 [Level] INFO, [Message] PROPOSE request received for Proposal{proposalId=7757556769504001, operation='DELETE', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 15:56:13.559 [Level] INFO, [Message] Setting new max ID[7.757556769504001E15]
[PST-Time-Zone] 2024-04-25 15:56:13.572 [Level] INFO, [Message] ACCEPT request received for Proposal{proposalId=7757556769504001, operation='DELETE', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 15:56:13.573 [Level] INFO, [Message] Simulated random network delay for 59 ms
[PST-Time-Zone] 2024-04-25 15:56:13.592 [Level] INFO, [Message] ACCEPT success for Proposal{proposalId=7757556769504001, operation='DELETE', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 15:56:13.628 [Level] INFO, [Message] LEARN request received for Proposal{proposalId=7757556769504001, operation='DELETE', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 15:56:13.629 [Level] INFO, [Message] Deleted key=5700 from the database.
[PST-Time-Zone] 2024-04-25 15:56:13.629 [Level] INFO, [Message] DELETE operation executed: Key=5700
[PST-Time-Zone] 2024-04-25 15:56:13.630 [Level] INFO, [Message] LEARN operation[DELETE] completed for Key=5700
[PST-Time-Zone] 2024-04-25 15:56:13.656 [Level] INFO, [Message] Retrieved value=Machine Learning for key=6140 in the database
[PST-Time-Zone] 2024-04-25 15:56:13.660 [Level] INFO, [Message] Generating a new proposal with ID: 7757557846304001
[PST-Time-Zone] 2024-04-25 15:56:13.667 [Level] INFO, [Message] PROPOSE request received for Proposal{proposalId=7757557846304001, operation='DELETE', key='6140', value='Machine Learning'}
[PST-Time-Zone] 2024-04-25 15:56:13.667 [Level] INFO, [Message] Setting new max ID[7.757557846304001E15]
[PST-Time-Zone] 2024-04-25 15:56:13.677 [Level] INFO, [Message] ACCEPT request received for Proposal{proposalId=7757557846304001, operation='DELETE', key='6140', value='Machine Learning'}
[PST-Time-Zone] 2024-04-25 15:56:13.742 [Level] INFO, [Message] Simulated random network delay for 61 ms
[PST-Time-Zone] 2024-04-25 15:56:13.742 [Level] INFO, [Message] ACCEPT success for Proposal{proposalId=7757557846304001, operation='DELETE', key='6140', value='Machine Learning'}
[PST-Time-Zone] 2024-04-25 15:56:13.746 [Level] INFO, [Message] LEARN request received for Proposal{proposalId=7757557846304001, operation='DELETE', key='6140', value='Machine Learning'}
[PST-Time-Zone] 2024-04-25 15:56:13.746 [Level] INFO, [Message] Deleted key=6140 from the database.
[PST-Time-Zone] 2024-04-25 15:56:13.746 [Level] INFO, [Message] DELETE operation executed: Key=6140
[PST-Time-Zone] 2024-04-25 15:56:13.746 [Level] INFO, [Message] LEARN operation[DELETE] completed for Key=6140
[PST-Time-Zone] 2024-04-25 15:56:13.762 [Level] INFO, [Message] Retrieved value=Database Management for key=5200 in the database
[PST-Time-Zone] 2024-04-25 15:56:13.764 [Level] INFO, [Message] Generating a new proposal with ID: 7757558883704001
[PST-Time-Zone] 2024-04-25 15:56:13.769 [Level] INFO, [Message] PROPOSE request received for Proposal{proposalId=7757558883704001, operation='DELETE', key='5200', value='Database Management'}
[PST-Time-Zone] 2024-04-25 15:56:13.769 [Level] INFO, [Message] Setting new max ID[7.757558883704001E15]
[PST-Time-Zone] 2024-04-25 15:56:13.777 [Level] INFO, [Message] ACCEPT request received for Proposal{proposalId=7757558883704001, operation='DELETE', key='5200', value='Database Management'}
[PST-Time-Zone] 2024-04-25 15:56:13.788 [Level] INFO, [Message] Simulated random network delay for 9 ms
[PST-Time-Zone] 2024-04-25 15:56:13.788 [Level] INFO, [Message] ACCEPT success for Proposal{proposalId=7757558883704001, operation='DELETE', key='5200', value='Database Management'}
[PST-Time-Zone] 2024-04-25 15:56:13.853 [Level] INFO, [Message] LEARN request received for Proposal{proposalId=7757558883704001, operation='DELETE', key='5200', value='Database Management'}
[PST-Time-Zone] 2024-04-25 15:56:13.854 [Level] INFO, [Message] Deleted key=5200 from the database.
[PST-Time-Zone] 2024-04-25 15:56:13.854 [Level] INFO, [Message] DELETE operation executed: Key=5200
[PST-Time-Zone] 2024-04-25 15:56:13.854 [Level] INFO, [Message] LEARN operation[DELETE] completed for Key=5200
[PST-Time-Zone] 2024-04-25 15:56:13.868 [Level] INFO, [Message] Generating a new proposal with ID: 7757559921204001
[PST-Time-Zone] 2024-04-25 15:56:13.873 [Level] INFO, [Message] PROPOSE request received for Proposal{proposalId=7757559921204001, operation='PUT', key='6650', value='Scalable Distributed Systems'}
[PST-Time-Zone] 2024-04-25 15:56:13.873 [Level] INFO, [Message] Setting new max ID[7.757559921204001E15]
[PST-Time-Zone] 2024-04-25 15:56:13.880 [Level] INFO, [Message] ACCEPT request received for Proposal{proposalId=7757559921204001, operation='PUT', key='6650', value='Scalable Distributed Systems'}
[PST-Time-Zone] 2024-04-25 15:56:13.980 [Level] INFO, [Message] Simulated random network delay for 95 ms
[PST-Time-Zone] 2024-04-25 15:56:13.980 [Level] INFO, [Message] ACCEPT success for Proposal{proposalId=7757559921204001, operation='PUT', key='6650', value='Scalable Distributed Systems'}
[PST-Time-Zone] 2024-04-25 15:56:13.982 [Level] INFO, [Message] LEARN request received for Proposal{proposalId=7757559921204001, operation='PUT', key='6650', value='Scalable Distributed Systems'}
[PST-Time-Zone] 2024-04-25 15:56:13.982 [Level] INFO, [Message] Added/Updated pair <key=6650, value=Scalable Distributed Systems> in the database.
[PST-Time-Zone] 2024-04-25 15:56:13.983 [Level] INFO, [Message] PUT operation executed: Key=6650, Value=Scalable Distributed Systems
[PST-Time-Zone] 2024-04-25 15:56:13.983 [Level] INFO, [Message] LEARN operation[PUT] completed for Key=6650
[PST-Time-Zone] 2024-04-25 15:56:13.997 [Level] INFO, [Message] Generating a new proposal with ID: 7757561215104001
[PST-Time-Zone] 2024-04-25 15:56:13.999 [Level] INFO, [Message] PROPOSE request received for Proposal{proposalId=7757561215104001, operation='PUT', key='5800', value='Algorithms'}
[PST-Time-Zone] 2024-04-25 15:56:14.000 [Level] INFO, [Message] Setting new max ID[7.757561215104001E15]
[PST-Time-Zone] 2024-04-25 15:56:14.005 [Level] INFO, [Message] ACCEPT request received for Proposal{proposalId=7757561215104001, operation='PUT', key='5800', value='Algorithms'}
[PST-Time-Zone] 2024-04-25 15:56:14.080 [Level] INFO, [Message] Simulated random network delay for 71 ms
[PST-Time-Zone] 2024-04-25 15:56:14.080 [Level] INFO, [Message] ACCEPT success for Proposal{proposalId=7757561215104001, operation='PUT', key='5800', value='Algorithms'}
[PST-Time-Zone] 2024-04-25 15:56:14.114 [Level] INFO, [Message] LEARN request received for Proposal{proposalId=7757561215104001, operation='PUT', key='5800', value='Algorithms'}
[PST-Time-Zone] 2024-04-25 15:56:14.115 [Level] INFO, [Message] Added/Updated pair <key=5800, value=Algorithms> in the database.
[PST-Time-Zone] 2024-04-25 15:56:14.115 [Level] INFO, [Message] PUT operation executed: Key=5800, Value=Algorithms
[PST-Time-Zone] 2024-04-25 15:56:14.115 [Level] INFO, [Message] LEARN operation[PUT] completed for Key=5800
[PST-Time-Zone] 2024-04-25 15:56:14.127 [Level] INFO, [Message] Generating a new proposal with ID: 7757562518704001
[PST-Time-Zone] 2024-04-25 15:56:14.131 [Level] INFO, [Message] PROPOSE request received for Proposal{proposalId=7757562518704001, operation='PUT', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 15:56:14.132 [Level] INFO, [Message] Setting new max ID[7.757562518704001E15]
[PST-Time-Zone] 2024-04-25 15:56:14.138 [Level] INFO, [Message] ACCEPT request received for Proposal{proposalId=7757562518704001, operation='PUT', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 15:56:14.239 [Level] INFO, [Message] Simulated random network delay for 98 ms
[PST-Time-Zone] 2024-04-25 15:56:14.240 [Level] INFO, [Message] ACCEPT success for Proposal{proposalId=7757562518704001, operation='PUT', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 15:56:14.242 [Level] INFO, [Message] LEARN request received for Proposal{proposalId=7757562518704001, operation='PUT', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 15:56:14.242 [Level] INFO, [Message] Added/Updated pair <key=5700, value=Computer Networking> in the database.
[PST-Time-Zone] 2024-04-25 15:56:14.242 [Level] INFO, [Message] PUT operation executed: Key=5700, Value=Computer Networking
[PST-Time-Zone] 2024-04-25 15:56:14.242 [Level] INFO, [Message] LEARN operation[PUT] completed for Key=5700
[PST-Time-Zone] 2024-04-25 15:56:14.254 [Level] INFO, [Message] Generating a new proposal with ID: 7757563781104001
[PST-Time-Zone] 2024-04-25 15:56:14.294 [Level] INFO, [Message] PROPOSE request received for Proposal{proposalId=7757563781104001, operation='PUT', key='6140', value='Machine Learning'}
[PST-Time-Zone] 2024-04-25 15:56:14.294 [Level] INFO, [Message] Setting new max ID[7.757563781104001E15]
[PST-Time-Zone] 2024-04-25 15:56:14.354 [Level] INFO, [Message] ACCEPT request received for Proposal{proposalId=7757563781104001, operation='PUT', key='6140', value='Machine Learning'}
[PST-Time-Zone] 2024-04-25 15:56:14.420 [Level] INFO, [Message] Simulated random network delay for 64 ms
[PST-Time-Zone] 2024-04-25 15:56:14.421 [Level] INFO, [Message] ACCEPT success for Proposal{proposalId=7757563781104001, operation='PUT', key='6140', value='Machine Learning'}
[PST-Time-Zone] 2024-04-25 15:56:14.451 [Level] INFO, [Message] LEARN request received for Proposal{proposalId=7757563781104001, operation='PUT', key='6140', value='Machine Learning'}
[PST-Time-Zone] 2024-04-25 15:56:14.451 [Level] INFO, [Message] Added/Updated pair <key=6140, value=Machine Learning> in the database.
[PST-Time-Zone] 2024-04-25 15:56:14.452 [Level] INFO, [Message] PUT operation executed: Key=6140, Value=Machine Learning
[PST-Time-Zone] 2024-04-25 15:56:14.452 [Level] INFO, [Message] LEARN operation[PUT] completed for Key=6140
[PST-Time-Zone] 2024-04-25 15:56:14.465 [Level] INFO, [Message] Generating a new proposal with ID: 7757565894104001
[PST-Time-Zone] 2024-04-25 15:56:14.470 [Level] INFO, [Message] PROPOSE request received for Proposal{proposalId=7757565894104001, operation='PUT', key='5200', value='Database Management'}
[PST-Time-Zone] 2024-04-25 15:56:14.470 [Level] INFO, [Message] Setting new max ID[7.757565894104001E15]
[PST-Time-Zone] 2024-04-25 15:56:14.474 [Level] INFO, [Message] ACCEPT request received for Proposal{proposalId=7757565894104001, operation='PUT', key='5200', value='Database Management'}
[PST-Time-Zone] 2024-04-25 15:56:14.571 [Level] INFO, [Message] Simulated random network delay for 92 ms
[PST-Time-Zone] 2024-04-25 15:56:14.572 [Level] INFO, [Message] ACCEPT success for Proposal{proposalId=7757565894104001, operation='PUT', key='5200', value='Database Management'}
[PST-Time-Zone] 2024-04-25 15:56:14.574 [Level] INFO, [Message] LEARN request received for Proposal{proposalId=7757565894104001, operation='PUT', key='5200', value='Database Management'}
[PST-Time-Zone] 2024-04-25 15:56:14.574 [Level] INFO, [Message] Added/Updated pair <key=5200, value=Database Management> in the database.
[PST-Time-Zone] 2024-04-25 15:56:14.574 [Level] INFO, [Message] PUT operation executed: Key=5200, Value=Database Management
[PST-Time-Zone] 2024-04-25 15:56:14.574 [Level] INFO, [Message] LEARN operation[PUT] completed for Key=5200
```

##### IF error occurred (rare case when Paxos can't reach consensus)

**NOTE**: 
**Since I have simulated random failures (limit to 10%) in the system to reflect real-world scenarios, there's also possibility to see error logs like `[PST-Time-Zone] 2024-04-25 10:53:41.472 [Level] ERROR, [Message] Failed to achieve majority in ACCEPT phase :(` that shows failures in reaching consensus.**

Due to the extensive length of these logs and space limitations in this document, I will just copy and paste the **ERROR** part of the logs here. 

```angular2html
[PST-Time-Zone] 2024-04-25 10:53:40.446 [Level] INFO, [Message] Preload 5 PUTs...
[PST-Time-Zone] 2024-04-25 10:53:40.447 [Level] INFO, [Message] Inserting pair <key=6650, value=Distributed Systems>
[PST-Time-Zone] 2024-04-25 10:53:40.695 [Level] INFO, [Message] Pair <key=6650, value=Distributed Systems> added successfully.
[PST-Time-Zone] 2024-04-25 10:53:41.000 [Level] INFO, [Message] Inserting pair <key=5800, value=Algorithms>
[PST-Time-Zone] 2024-04-25 10:53:41.129 [Level] INFO, [Message] Pair <key=5800, value=Algorithms> added successfully.
[PST-Time-Zone] 2024-04-25 10:53:41.432 [Level] INFO, [Message] Inserting pair <key=5700, value=Computer Networking>
[PST-Time-Zone] 2024-04-25 10:53:41.472 [Level] ERROR, [Message] Failed to achieve majority in ACCEPT phase :(
...
```

**Notice**

❗️ You will also see a super long log on the `coordinator` side that records as below. Due to the extensive length of these logs and space limitations in this document, I will just copy and paste the **ERROR** part of the logs here. 

```angular2html
...
[PST-Time-Zone] 2024-04-25 10:53:41.434 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7576036497204001, operation='PUT', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 10:53:41.435 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-25 10:53:41.442 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-25 10:53:41.452 [Level] INFO, [Message] [2] out of 5 accepts the proposal in ACCEPT phase.
[PST-Time-Zone] 2024-04-25 10:53:41.470 [Level] ERROR, [Message] Failed to achieve majority in ACCEPT phase :(
...
```

In this case, at least 3 servers (5 servers in all) will have ERROR logs like this. Due to the extensive length of these logs and space limitations in this document, I will just copy and paste the **ERROR** part of the logs here. 

```
...
[PST-Time-Zone] 2024-04-25 10:53:40.443 [Level] INFO, [Message] PROPOSE request received for Proposal{proposalId=7576036497204001, operation='PUT', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 10:53:40.551 [Level] INFO, [Message] Proposal accepted with new max ID[7.576036497204001E15]
[PST-Time-Zone] 2024-04-25 10:53:41.004 [Level] INFO, [Message] ACCEPT request received for Proposal{proposalId=7576036497204001, operation='PUT', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 10:53:41.207 [Level] ERROR, [Message] Simulated a failure in ACCEPT operation...
[PST-Time-Zone] 2024-04-25 19:53:41.334 [Level] ERROR, [Message] Simulated RuntimeException occurred in server[4003] during ACCEPT operation.
...
```


#### V. Interact with the server and perform three basic operations.

1. Once the preloading requests have completed, you will see message as below to guide you how to enter the request.

```angular2html
How to Enter Your Request:
Enter 1: GET the value by a certain key
Enter 2: ADD or UPDATE a key-value pair
Enter 3: DELETE an existing key-value pair
Enter 4: EXIT this program
--------------------------------
Please enter a number for your request:
```

2. For example, if you want to add or update a key-value pair as a `PUT` operation, you enter `2`, and the log messages
   indicating whether your operation is successful will be shown as below.

```angular2html
Please enter a number for your request:
2
Enter the key:
6650
Enter the value:
distributed systems
PUT/UPDATE Operation for <key=6650, value=distributed systems> completed successfully!
```

3. You will see new logs on the server & coordinator terminal, which shows how the system uses Paxos consensus to complete this operation successfully.

**SERVER LOG**
```angular2html
[PST-Time-Zone] 2024-04-25 11:16:47.864 [Level] INFO, [Message] Generating a new proposal with ID: 7589900673004001
[PST-Time-Zone] 2024-04-25 11:16:47.873 [Level] INFO, [Message] PROPOSE request received for Proposal{proposalId=7589900673004001, operation='PUT', key='6650', value='distributed systems'}
[PST-Time-Zone] 2024-04-25 11:16:47.873 [Level] INFO, [Message] Proposal accepted with new max ID[7.589900673004001E15]
[PST-Time-Zone] 2024-04-25 11:16:47.880 [Level] INFO, [Message] ACCEPT request received for Proposal{proposalId=7589900673004001, operation='PUT', key='6650', value='distributed systems'}
[PST-Time-Zone] 2024-04-25 11:16:47.880 [Level] INFO, [Message] Simulated random network delay for 17 ms
[PST-Time-Zone] 2024-04-25 11:16:47.901 [Level] INFO, [Message] ACCEPT success for Proposal{proposalId=7589900673004001, operation='PUT', key='6650', value='distributed systems'}
[PST-Time-Zone] 2024-04-25 11:16:47.969 [Level] INFO, [Message] LEARN request received for Proposal{proposalId=7589900673004001, operation='PUT', key='6650', value='distributed systems'}
[PST-Time-Zone] 2024-04-25 11:16:47.970 [Level] INFO, [Message] Added/Updated pair <key=6650, value=distributed systems> in the database.
[PST-Time-Zone] 2024-04-25 11:16:47.970 [Level] INFO, [Message] PUT operation executed: Key=6650, Value=distributed systems
[PST-Time-Zone] 2024-04-25 11:16:47.970 [Level] INFO, [Message] LEARN operation[PUT] completed for Key=6650
``` 

**COORDINATOR LOG**
```angular2html
[PST-Time-Zone] 2024-04-25 11:16:47.868 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7589900673004001, operation='PUT', key='6650', value='distributed systems'}
[PST-Time-Zone] 2024-04-25 11:16:47.868 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-25 11:16:47.878 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-25 11:16:47.969 [Level] INFO, [Message] Initiating LEARN phase...
[PST-Time-Zone] 2024-04-25 11:16:47.978 [Level] INFO, [Message] LEARN phase completed for Proposal{proposalId=7589900673004001, operation='PUT', key='6650', value='distributed systems'}
```

4. Feel free to try `GET` or `DELETE` operations by yourself following the instructions above. 

**NOTE** 
1) To ensure system robustness, inputs are validated for null or empty values. Should you enter an 
invalid input, a prompt will appear: `Key or value must NOT be NULL or EMPTY. Please enter a valid input.` Following 
this, you'll be guided back to instructions for making a request.

2) For data accuracy, the system automatically trims leading and trailing spaces from inputs. For instance, 
a key-value pair entered as <key=   5001 , value=   python > will be stored as <key=5001, value=python> in the database. 
This not only ensures that inadvertent spaces do not affect the storage and retrieval of data but also reduces the 
likelihood of errors or confusion related to unexpected spaces in key or value fields.


## Test

Please note that all screenshots of my testing done on my local environment for tcp and udp protocols are attached to
the folder of `/res`. Feel free to check them out!

Here, I will only copy and paste the log messages as an example.

### Success

#### PUT

```angular2html
How to Enter Your Request:
Enter 1: GET the value by a certain key
Enter 2: ADD or UPDATE a key-value pair
Enter 3: DELETE an existing key-value pair
Enter 4: EXIT this program
--------------------------------
Please enter a number for your request:
2
Enter the key:
6650
Enter the value:
distributed systems
PUT/UPDATE Operation for <key=6650, value=distributed systems> completed successfully!
```

You can also **UPDATE** a key-value pair:

```angular2html
How to Enter Your Request:
Enter 1: GET the value by a certain key
Enter 2: ADD or UPDATE a key-value pair
Enter 3: DELETE an existing key-value pair
Enter 4: EXIT this program
--------------------------------
Please enter a number for your request:
2
Enter the key:
6650
Enter the value:
good course
PUT/UPDATE Operation for <key=6650, value=good course> completed successfully!
```

#### GET

```angular2html
How to Enter Your Request:
Enter 1: GET the value by a certain key
Enter 2: ADD or UPDATE a key-value pair
Enter 3: DELETE an existing key-value pair
Enter 4: EXIT this program
--------------------------------
Please enter a number for your request:
1
Enter the key:
6650
GET Operation for <key=6650> completed successfully! <value=good course>
```

#### DELETE

```angular2html
How to Enter Your Request:
Enter 1: GET the value by a certain key
Enter 2: ADD or UPDATE a key-value pair
Enter 3: DELETE an existing key-value pair
Enter 4: EXIT this program
--------------------------------
Please enter a number for your request:
3
Enter the key:
6650
DELETE Operation for <key=6650, value=good course> completed successfully!
```

#### Concurrent operations from different clients

To verify that my program can correctly handle concurrent operations from different clients, I conducted the tests as below:

1) Client 1 on `port-4001`adds a key-value pair: PUT <key=6650, value=distributed systems>. 
```angular2html
How to Enter Your Request:
Enter 1: GET the value by a certain key
Enter 2: ADD or UPDATE a key-value pair
Enter 3: DELETE an existing key-value pair
Enter 4: EXIT this program
--------------------------------
Please enter a number for your request: 
2
Enter the key: 
6650
Enter the value: 
distributed systems
PUT/UPDATE Operation for <key=6650, value=distributed systems> completed successfully!
```

1) Client 2 on `port-4002` deletes this key-value pair: DELETE <key=6650>
```angular2html
How to Enter Your Request:
Enter 1: GET the value by a certain key
Enter 2: ADD or UPDATE a key-value pair
Enter 3: DELETE an existing key-value pair
Enter 4: EXIT this program
--------------------------------
Please enter a number for your request: 
3
Enter the key: 
6650
DELETE Operation for <key=6650, value=distributed systems> completed successfully!
```

1) Attempting to GET <key=6650> from either Client 1 or Client 2 should result in the key cannot be found in the keyValueStore.
```angular2html
How to Enter Your Request:
Enter 1: GET the value by a certain key
Enter 2: ADD or UPDATE a key-value pair
Enter 3: DELETE an existing key-value pair
Enter 4: EXIT this program
--------------------------------
Please enter a number for your request: 
1
Enter the key: 
6650
Error! Key=6650 is not found in the database.
```

1) Notice that both coordinator and servers logged these PUT/UPDATE and DELETE operations. Due to the extensive length of these logs and space limitations in this document, I will just copy and paste a glimpse of logs here. 

**SERVER LOG** 
```angular2html
[PST-Time-Zone] 2024-04-25 11:21:52.449 [Level] INFO, [Message] Generating a new proposal with ID: 7592946492404002
[PST-Time-Zone] 2024-04-25 11:21:52.466 [Level] INFO, [Message] PROPOSE request received for Proposal{proposalId=7592946492404002, operation='DELETE', key='6650', value='distributed systems'}
[PST-Time-Zone] 2024-04-25 11:21:52.468 [Level] INFO, [Message] Proposal accepted with new max ID[7.592946492404002E15]
[PST-Time-Zone] 2024-04-25 11:21:52.509 [Level] INFO, [Message] ACCEPT request received for Proposal{proposalId=7592946492404002, operation='DELETE', key='6650', value='distributed systems'}
[PST-Time-Zone] 2024-04-25 11:21:52.510 [Level] INFO, [Message] Simulated random network delay for 73 ms
[PST-Time-Zone] 2024-04-25 11:21:52.588 [Level] INFO, [Message] ACCEPT success for Proposal{proposalId=7592946492404002, operation='DELETE', key='6650', value='distributed systems'}
[PST-Time-Zone] 2024-04-25 11:21:52.612 [Level] INFO, [Message] LEARN request received for Proposal{proposalId=7592946492404002, operation='DELETE', key='6650', value='distributed systems'}
[PST-Time-Zone] 2024-04-25 11:21:52.612 [Level] INFO, [Message] Deleted key=6650 from the database.
[PST-Time-Zone] 2024-04-25 11:21:52.612 [Level] INFO, [Message] DELETE operation executed: Key=6650
[PST-Time-Zone] 2024-04-25 11:21:52.612 [Level] INFO, [Message] LEARN operation[DELETE] completed for Key=6650
[PST-Time-Zone] 2024-04-25 11:21:59.196 [Level] ERROR, [Message] Failed to GET: Key=6650 is not found in the database.
```

**COORDINATOR LOG**
```angular2html
[PST-Time-Zone] 2024-04-25 11:21:52.458 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7592946492404002, operation='DELETE', key='6650', value='distributed systems'}
[PST-Time-Zone] 2024-04-25 11:21:52.459 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-25 11:21:52.506 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-25 11:21:52.609 [Level] INFO, [Message] Initiating LEARN phase...
[PST-Time-Zone] 2024-04-25 11:21:52.622 [Level] INFO, [Message] LEARN phase completed for Proposal{proposalId=7592946492404002, operation='DELETE', key='6650', value='distributed systems'}
```

**NOTE**
**Please note that, it's also possible to see an error message if you meet a random failure simulated in the acceptor.**

**COORDINATOR LOG**
```angular2html
[PST-Time-Zone] 2024-04-24 13:53:59.714 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7588909224404002, operation='DELETE', key='6650', value='null'}
[PST-Time-Zone] 2024-04-24 13:53:59.714 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-24 13:53:59.773 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-24 13:53:59.806 [Level] ERROR, [Message] Error occurred when processing ACCEPT responses: java.util.concurrent.ExecutionException: java.lang.RuntimeException: Simulated runtime exception occurred during PROPOSE operation.
[PST-Time-Zone] 2024-04-24 13:53:59.806 [Level] ERROR, [Message] Failed to achieve majority in ACCEPT phase :(
```


### Failure

#### PUT

When you tend to put key-value pair in a invalid format in PUT request, the client side will show you guidance:

```angular2html
How to Enter Your Request:
Enter 1: GET the value by a certain key
Enter 2: ADD or UPDATE a key-value pair
Enter 3: DELETE an existing key-value pair
Enter 4: EXIT this program
--------------------------------
Please enter a number for your request:
2
Enter the key:
6650
Enter the value:

Key or value must NOT be NULL or EMPTY. Please enter a valid input.
```

The client-side will show a log ERROR as well:
```angular2html
[PST-Time-Zone] 2024-04-24 14:02:51.330 [Level] ERROR, [Message] Error: Key and value must not be null or empty after being trimmed.
```

#### GET

1) When you try to retrieve a key that not exists:

```angular2html
How to Enter Your Request:
Enter 1: GET the value by a certain key
Enter 2: ADD or UPDATE a key-value pair
Enter 3: DELETE an existing key-value pair
Enter 4: EXIT this program
--------------------------------
Please enter a number for your request:
1
Enter the key:
6650
Error! Key=6650 is not found in the database.
```

The server-side will show a log ERROR as well:
```angular2html
[PST-Time-Zone] 2024-04-24 14:04:36.059 [Level] ERROR, [Message] Key=6650 is not found in the database.
```

2) When your try to get a value by a invalid key in GET request, the client side will show you guidance:
```angular2html
How to Enter Your Request:
    Enter 1: GET the value by a certain key
Enter 2: ADD or UPDATE a key-value pair
Enter 3: DELETE an existing key-value pair
Enter 4: EXIT this program
--------------------------------
Please enter a number for your request: 
1
Enter the key: 

Key or value must NOT be NULL or EMPTY. Please enter a valid input.
```

#### DELETE

1) When you delete a key that does not exist:

```angular2html
How to Enter Your Request:
Enter 1: GET the value by a certain key
Enter 2: ADD or UPDATE a key-value pair
Enter 3: DELETE an existing key-value pair
Enter 4: EXIT this program
--------------------------------
Please enter a number for your request:
3
Enter the key:
6650
Error! Key=6650 is not found or has already been deleted from the database.
```
The server-side will show a log ERROR as well:
```angular2html
[PST-Time-Zone] 2024-03-19 17:59:51.142 [Level] ERROR, [Message] Key=6650 is not found in the database.
```
2) When your try to delete a value by a invalid key in DELETE request, the client side will show you guidance:

```angular2html
How to Enter Your Request:
    Enter 1: GET the value by a certain key
Enter 2: ADD or UPDATE a key-value pair
Enter 3: DELETE an existing key-value pair
Enter 4: EXIT this program
--------------------------------
Please enter a number for your request: 
3
Enter the key: 
 
Key or value must NOT be NULL or EMPTY. Please enter a valid input.
```

#### Server unresponsive/timeout failure

When the server fails to respond, the system employs a robust fault tolerance strategy by integrating a timeout mechanism and the Paxos consensus algorithm. 
This design ensures system resilience during failures.

To evaluate the effectiveness of the mechanism, I conducted tests simulating scenarios where the network delay exceeded the predefined threshold for acceptors. These tests demonstrated that the application can gracefully handle timeout exceptions by preventing indefinite hang-ups. Despite these simulated delays causing timeouts, the client efficiently completed all preloading operations, as evidenced by the log entries confirming successful insertions of key-value pairs.

**CLIENT LOG**
Though one server meets timeout failure, the client is still able to perform the operation as the coordinator successfully achieves consensus.

```angular2html
[PST-Time-Zone] 2024-04-25 18:39:31.444 [Level] INFO, [Message] Preload 5 PUTs...
[PST-Time-Zone] 2024-04-25 18:39:31.445 [Level] INFO, [Message] Inserting pair <key=6650, value=Distributed Systems>
[PST-Time-Zone] 2024-04-25 18:39:31.602 [Level] INFO, [Message] Pair <key=6650, value=Distributed Systems> added successfully.
[PST-Time-Zone] 2024-04-25 18:39:31.602 [Level] INFO, [Message] Inserting pair <key=5800, value=Algorithms>
[PST-Time-Zone] 2024-04-25 18:39:31.718 [Level] INFO, [Message] Pair <key=5800, value=Algorithms> added successfully.
[PST-Time-Zone] 2024-04-25 18:39:31.718 [Level] INFO, [Message] Inserting pair <key=5700, value=Computer Networking>
[PST-Time-Zone] 2024-04-25 18:39:31.901 [Level] INFO, [Message] Pair <key=5700, value=Computer Networking> added successfully.
[PST-Time-Zone] 2024-04-25 18:39:31.902 [Level] INFO, [Message] Inserting pair <key=6140, value=Machine Learning>
[PST-Time-Zone] 2024-04-25 18:39:32.027 [Level] INFO, [Message] Pair <key=6140, value=Machine Learning> added successfully.
[PST-Time-Zone] 2024-04-25 18:39:32.028 [Level] INFO, [Message] Inserting pair <key=5200, value=Database Management>
[PST-Time-Zone] 2024-04-25 18:39:32.145 [Level] INFO, [Message] Pair <key=5200, value=Database Management> added successfully.
```

**SERVER LOG**

Though meeting timeout failure, the server is still able to perform the operation as the coordinator successfully achieves consensus.

```angular2html
[PST-Time-Zone] 2024-04-25 18:39:32.868 [Level] INFO, [Message] Generating a new proposal with ID: 7855546736304002
[PST-Time-Zone] 2024-04-25 18:39:32.871 [Level] INFO, [Message] PROPOSE request received for Proposal{proposalId=7855546736304002, operation='PUT', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 18:39:32.871 [Level] INFO, [Message] Setting new max ID[7.855546736304002E15]
[PST-Time-Zone] 2024-04-25 18:39:32.873 [Level] INFO, [Message] ACCEPT request received for Proposal{proposalId=7855546736304002, operation='PUT', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 18:39:32.873 [Level] ERROR, [Message] Simulated random network delay for [99 ms] exceeds the threshold[100 ms]
[PST-Time-Zone] 2024-04-25 18:39:32.874 [Level] ERROR, [Message] Simulated TimeoutException occurred in server[4002] during ACCEPT operation.
[PST-Time-Zone] 2024-04-25 18:39:32.976 [Level] INFO, [Message] LEARN request received for Proposal{proposalId=7855546736304002, operation='PUT', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 18:39:32.976 [Level] INFO, [Message] Added/Updated pair <key=5700, value=Computer Networking> in the database.
[PST-Time-Zone] 2024-04-25 18:39:32.976 [Level] INFO, [Message] PUT operation executed: Key=5700, Value=Computer Networking
[PST-Time-Zone] 2024-04-25 18:39:32.977 [Level] INFO, [Message] LEARN operation[PUT] completed for Key=5700
```

**COORDINATOR LOG**

Though the server meets timeout failure, the coordinator still successfully achieves consensus, thanks to Paxos algorithm!

```angular2html
[PST-Time-Zone] 2024-04-25 18:39:32.869 [Level] INFO, [Message] Received execution request for Proposal{proposalId=7855546736304002, operation='PUT', key='5700', value='Computer Networking'}
[PST-Time-Zone] 2024-04-25 18:39:32.870 [Level] INFO, [Message] Initiating PREPARE phase...
[PST-Time-Zone] 2024-04-25 18:39:32.872 [Level] INFO, [Message] Initiating ACCEPT phase...
[PST-Time-Zone] 2024-04-25 18:39:32.970 [Level] INFO, [Message] [4] out of 5 accepts the proposal in ACCEPT phase.
[PST-Time-Zone] 2024-04-25 18:39:32.971 [Level] INFO, [Message] Succeed to achieve majority in ACCEPT phase :)
[PST-Time-Zone] 2024-04-25 18:39:32.971 [Level] INFO, [Message] Initiating LEARN phase...
[PST-Time-Zone] 2024-04-25 18:39:32.996 [Level] INFO, [Message] LEARN phase completed for Proposal{proposalId=7855546736304002, operation='PUT', key='5700', value='Computer Networking'}
```

## Limitations and Future Iterations

Despite the progress made, there are several areas waiting for future development. For example, although my current design can meet project 4's requirements, I did not implement the mechanism that allows Acceptor to restart and handle the missing requests in the failure scenarios. Therefore, my next goal is to work on the extra-credit part, that is to improve the system by adding thread timeouts and restarts for Acceptor threads. This iteration is really important so the system can recover smoothly from failures without disrupting ongoing operations — a goal I couldn't fully achieve within the project timeline due to time constraints. Apart from that, I'll work on enhancing message handling to reduce communication delays and incorporate more extensive testing to simulate various failure scenarios. These upgrades will prepare the system to handle more complex situations, like dynamic cluster configurations and advanced recovery tactics, which can ultimate make the Key-Value Store more robust and capable of meeting modern application demands.
