package coordinator;

import java.util.ArrayList;
import java.util.List;

/**
 * This class provides a registry of servers participating in the Paxos
 * algorithm.
 */
public class ServerRegistry {

  /**
   * Retrieves the names of servers registered for Paxos algorithm.
   *
   * @return A list of server names.
   */
  public static List<String> getRegisteredServerNames() {
    List<String> serverNames = new ArrayList<>();
    // hard code a list of server names
    serverNames.add("rpc-server-4001");
    serverNames.add("rpc-server-4002");
    serverNames.add("rpc-server-4003");
    serverNames.add("rpc-server-4004");
    serverNames.add("rpc-server-4005");
    return serverNames;
  }
}
