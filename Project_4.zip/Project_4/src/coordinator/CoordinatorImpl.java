package coordinator;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import api.Coordinator;
import api.KeyValueResponse;
import consensus.Paxos;
import consensus.Promise;
import consensus.Proposal;

/**
 * Implementation of the Coordinator role in the Paxos consensus algorithm.
 * This class manages the coordination of transaction operations across multiple
 * servers, ensuring consistency and reliability in the distributed environment.
 * It supports communication between proposers and acceptors to achieve
 * consensus on proposals.
 */
public class CoordinatorImpl extends UnicastRemoteObject implements Coordinator {

  // thread pool for handling asynchronous tasks
  private final ExecutorService executor;
  // number of acceptances required to reach majority (>= 50%)
  private final int majorityThreshold;

  /**
   * Constructor for CoordinatorServiceImpl initializing thread pool and majority
   * threshold.
   * 
   * @throws RemoteException if RMI operation fails
   */
  protected CoordinatorImpl() throws RemoteException {
    super();
    this.executor = Executors.newFixedThreadPool(ServerRegistry.getRegisteredServerNames().size() + 1);
    // if there are 5 acceptors, then to achieve majority you should have 3 votes
    this.majorityThreshold = CoordinatorApp.acceptorStubs.size() / 2;
  }

  /**
   * Sends prepare requests to all acceptors and awaits promises.
   * A prepare request asks acceptors to promise not to accept any earlier
   * proposals.
   *
   * @param proposal the proposal to prepare
   * @return true if a majority of acceptors promised
   */
  private boolean sendPrepare(Proposal proposal) {
    int promisedNodes = 0;
    List<Future<Promise>> prepareFutures = new ArrayList<>();

    // asynchronously send prepare requests to each acceptor and store future promises
    for (Paxos stub : CoordinatorApp.acceptorStubs) {
      try {
        Future<Promise> future = executor.submit(() -> stub.propose(proposal));
        prepareFutures.add(future);
      } catch (Exception e) {
        CoordinatorLogger.error(String.format("Error occurred when sending PREPARE responses: %s", e));
      }
    }

    // wait for all futures to complete and count how many promises got back
    try {
      for (Future<Promise> future : prepareFutures) {
        Promise result = future.get();
        // only increment count if a valid promise is received (status code 200)
        if (result.getStatus().equals("200")) {
          promisedNodes++;
        }
      }
    } catch (InterruptedException | ExecutionException e) {
      CoordinatorLogger.error(String.format("Error occurred when processing PREPARE responses: %s", e));
    }

    // if the majority threshold  met, then return the outcome
    // CoordinatorLogger.info(String.format("[%s] out of 5 send back promise in PREPARE phase.", promisedNodes));
    if (promisedNodes > majorityThreshold) {
      return true;
    } else {
      CoordinatorLogger.error("Failed to achieve majority in PREPARE phase :(");
      return false;
    }
  }

  /**
   * Sends accept requests to all acceptors who promised and awaits their
   * acknowledgments.
   * An accept request is sent only after a majority of acceptors have promised.
   * 
   * @param proposal the proposal to accept
   * @return true if a majority of acceptors accepted the proposal
   */
  private boolean sendAccept(Proposal proposal) {
    int acceptedNodes = 0;
    List<Future<Boolean>> acceptFutures = new ArrayList<>();

    // asynchronously send accept requests to each acceptor and store future promises
    for (Paxos stub : CoordinatorApp.acceptorStubs) {
      Future<Boolean> future = executor.submit(() -> stub.accept(proposal));
      acceptFutures.add(future);
    }

    // wait for all futures to complete and count how many accepts got back
    try {
      for (Future<Boolean> future : acceptFutures) {
        Boolean result = future.get();
        // only increment count if acceptor accepts the proposal
        if (result != null && result.equals(Boolean.TRUE)) {
          acceptedNodes++;
        }
      }
    } catch (InterruptedException | ExecutionException e) {
      CoordinatorLogger.error(String.format("Error occurred when processing ACCEPT responses: %s", e));
    }

    // if meet the majority threshold, return the outcome
    CoordinatorLogger.info(String.format("[%s] out of 5 accepts the proposal in ACCEPT phase.", acceptedNodes));
    if (acceptedNodes > majorityThreshold) {
      CoordinatorLogger.info("Succeed to achieve majority in ACCEPT phase :)");
      return true;
    } else {
      CoordinatorLogger.error("Failed to achieve majority in ACCEPT phase :(");
      return false;
    }
  }

  /**
   * Informs all acceptors to commit the proposal.
   * The learn phase is triggered after a successful accept phase.
   * 
   * @param proposal the proposal to be learned and committed by all acceptors
   */
  private void sendLearn(Proposal proposal) throws RemoteException {
    for (Paxos stub : CoordinatorApp.acceptorStubs) {
      stub.learn(proposal);
    }
    CoordinatorLogger.info("LEARN phase completed for " + proposal);
  }

  /**
   * Executes the Paxos algorithm to reach consensus on a given proposal.
   * Consists 3 phases: prepare, accept, and learn.
   * 
   * @param proposal the proposal for which consensus is to be reached
   * @return the response detailing the outcome of the execution
   * @throws RemoteException if RMI communication fails
   */
  @Override
  public KeyValueResponse execute(Proposal proposal) throws RemoteException {
    KeyValueResponse response = new KeyValueResponse();
    response.setOperation(proposal.getOperation());
    CoordinatorLogger.info("Received execution request for " + proposal);

    // Stage 1: Prepare
    CoordinatorLogger.info("Initiating PREPARE phase...");
    boolean prepareSuccess = sendPrepare(proposal);
    if (!prepareSuccess) {
      response.setSuccess(false);
      response.setErrorMsg("Failed to achieve majority in PREPARE phase :(");
      return response;
    }

    // Stage 2: Accept
    CoordinatorLogger.info("Initiating ACCEPT phase...");
    boolean acceptSuccess = sendAccept(proposal);
    if (!acceptSuccess) {
      response.setSuccess(false);
      response.setErrorMsg("Failed to achieve majority in ACCEPT phase :(");
      return response;
    }

    // Stage 3: Learn
    CoordinatorLogger.info("Initiating LEARN phase...");
    sendLearn(proposal);

    response.setSuccess(true);
    return response;
  }
}
