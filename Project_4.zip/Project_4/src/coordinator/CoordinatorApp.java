package coordinator;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;
import java.util.ArrayList;

import api.Coordinator;
import api.KeyValueRpc;
import consensus.Paxos;


/**
 * CoordinatorApp is the main class for the Coordinator App in a distributed system.
 * It initializes and manages RMI interactions between clients and servers.
 * It acts as a mediator for communication and consensus operations using the Paxos algorithm.
 */
public class CoordinatorApp extends CoordinatorImpl {

    public static List<KeyValueRpc> keyValueServerStubs;
    public static List<Paxos> acceptorStubs;

    /**
     * Constructs a CoordinatorApp instance, initializes the RMI registry,
     * and binds the coordinator service to it.
     *
     * @param host the hostname on which the registry is to run
     * @param port   the port number on which the RMI registry is created and listens for incoming connections.
     * @throws RemoteException if a remote communication error occurs
     */
    protected CoordinatorApp(String host, int port) throws RemoteException {
        super();
        try {
            Coordinator coordinatorService = this;

            String bindingName = "coordinator";
            String registryURL = "//" + host + ":" + port + "/" + bindingName;

            // attempt to get the registry; if not found, create it
            Registry registry;
            try {
                registry = LocateRegistry.getRegistry(host, port);
                registry.list(); // This will throw an exception if the registry does not exist
            } catch (RemoteException e) {
                registry = LocateRegistry.createRegistry(port); // Create the registry if it does not exist
                CoordinatorLogger.info(String.format("RMI registry created on port[%s] ", port));
            }

            // bind the stub in the registry
            registry.rebind(bindingName, coordinatorService);

            CoordinatorLogger.info(
                    String.format("Coordinator[%s] is ready at URL[%s]...", bindingName, registryURL));

        } catch (RemoteException e) {
            CoordinatorLogger.error(String.format("Error occurred while setting up the coordinator.", e));
            throw e;
        }
    }

    /**
     * Main method to run the CoordinatorApp.
     * Connects to server instances and initializes the coordinator.
     *
     * @param args Command line arguments are not used.
     */
    public static void main(String[] args) {
        if (args.length < 2) {
            CoordinatorLogger.info(
                    "Invalid Arguments. Usage: java -cp coordinator.jar coordinator.CoordinatorApp <host> <port> " + 
                    "e.g. `java -cp coordinator.jar coordinator.CoordinatorApp localhost 1099`");
            return;
        }
        String host = args[0];
        int portNum = Integer.parseInt(args[1]);

        // if (args.length < 1) {
        //     CoordinatorLogger.info(
        //             "Invalid Arguments. Usage: java server.ServerApp <port> " + 
        //             "e.g. `java -cp coordinator.jar coordinator.CoordinatorApp 1099`");
        //     return;
        // }
        // int portNum = Integer.parseInt(args[0]);

        try {
            keyValueServerStubs = new ArrayList<>();
            acceptorStubs = new ArrayList<>();
            List<String> registeredServerNames = ServerRegistry.getRegisteredServerNames();
            initializeStubs(registeredServerNames);
            new CoordinatorApp(host, portNum);
        } catch (RemoteException e) {
            CoordinatorLogger.error("Error while setting up the coordinator: " + e.getMessage());
            System.exit(1);
        }
    }

    /**
     * Initializes KeyValue and Paxos stubs for each registered server.
     * Logs the registration status during the registration process.
     *
     * @param registeredServerNames A list of server names registered in the RMI registry.
     */
    private static void initializeStubs(List<String> registeredServerNames) {
        int counter = 1;
        for (String serverName : registeredServerNames) {
            String port = extractPort(serverName);
            String url = "//localhost:" + port + "/" + serverName;
            try {
                KeyValueRpc keyValueStub = (KeyValueRpc) Naming.lookup(url);
                Paxos paxosStub = (Paxos) Naming.lookup(url);
                keyValueServerStubs.add(keyValueStub);
                acceptorStubs.add(paxosStub);
                CoordinatorLogger.info(String.format("Server[%s] at URL[%s] successfully registered.", serverName, url));
                CoordinatorLogger.info(String.format("[%s] server(s) have successfully connected to Coordinator.", counter));
                counter++;
            } catch (NotBoundException e) {
                CoordinatorLogger.error(String.format("Server[%s] not found in the registry: %s", serverName, e));
            } catch (RemoteException | MalformedURLException e) {
                CoordinatorLogger.error(String.format("Failed to lookup server[%s]: %s", serverName, e));
            }
        }
    }

    /**
     * Extracts the port number from the server's registry name.
     *
     * @param registryName The name of the registry entry for the server.
     * @return The port number as a string.
     */
    private static String extractPort(String registryName) {
        // since serverRegistry name has format "rpc-server-4001"
        String[] parts = registryName.split("-");
        String port = parts[2]; 
        return port;
    }
}