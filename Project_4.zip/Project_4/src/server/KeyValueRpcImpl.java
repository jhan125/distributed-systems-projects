package server;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Random;
import java.io.IOException;
import java.lang.RuntimeException;
import java.util.concurrent.TimeoutException;

import api.Coordinator;
import api.KeyValueResponse;
import api.KeyValueRpc;
import consensus.Paxos;
import consensus.Promise;
import consensus.Proposal;

import static server.ServerApp.portNum;

/**
 * Implementation of the KeyValueRpc and Paxos interfaces to handle key-value
 * storage operations with Paxos-based consensus for distributed systems.
 * This class implemented the key Paxos roles: Proposers, Acceptors, and
 * Learners.
 * It ensures thread-safe operations on key-value store and handles remote
 * method invocation.
 */
public class KeyValueRpcImpl extends UnicastRemoteObject implements KeyValueRpc, Paxos {

  private Coordinator coordinator;
  private double maxProposalId;

  protected KeyValueRpcImpl() throws RemoteException {
    super();
  }

  /**
   * Initializes a connection with the coordinator by looking up its RMI registry
   * entry.
   */
  private void initCoordinatorConnection() throws RemoteException {
    try {
      coordinator = (Coordinator) Naming.lookup("//localhost:1099/coordinator");
      ServerLogger.info("Connection established successfully with the coordinator.");
    } catch (NotBoundException e) {
      ServerLogger.error("Failed to connect: Coordinator is not bound in the RMI registry.");
    } catch (MalformedURLException e) {
      ServerLogger.error("Failed to connect: Coordinator URL may be malformed.");
    }
  }

  @Override
  public KeyValueResponse get(String key) throws RemoteException {
    if (key == null || key.trim().isEmpty()) {
      throw new IllegalArgumentException("Key must not be null or empty after being trimmed.");
    }
    key = key.trim();
    String value = KeyValueStore.getInstance().get(key);
    KeyValueResponse response = new KeyValueResponse();
    response.setOperation("GET");
    if (value == null) {
      response.setErrorMsg(String.format("Key=%s not found in the database.", key));
      response.setSuccess(false);
    } else {
      response.setSuccess(true);
      response.setValue(value);
    }
    return response;
  }

  @Override
  public KeyValueResponse put(String key, String value) throws RemoteException, IllegalStateException {
    if (coordinator == null) {
      // throw new IllegalStateException("Failed to initialize coordinator
      // connection.");
      initCoordinatorConnection();
    }
    if (key == null || key.trim().isEmpty() || value == null || value.trim().isEmpty()) {
      throw new IllegalArgumentException(
          "Key and value must not be null or empty after being trimmed.");
    }
    // Proceed with the operation if the input is valid
    key = key.trim();
    Proposal generatedProposal = Proposal.generateProposal("PUT", key, value);
    return coordinator.execute(generatedProposal);
  }

  @Override
  public KeyValueResponse delete(String key) throws RemoteException {
    if (coordinator == null) {
      initCoordinatorConnection();
    }
    if (key == null || key.trim().isEmpty()) {
      throw new IllegalArgumentException("Key must not be null or empty after being trimmed.");
    }
    // Proceed with the operation if the input is valid
    key = key.trim();
    // check if key exists in the database
    if (!get(key).isSuccess()) {
      KeyValueResponse response = new KeyValueResponse();
      response.setOperation("DELETE");
      response.setErrorMsg(String.format("Key=%s is not found or has already been deleted from the database.", key));
      return response;
    }
    String value = get(key).getValue();
    Proposal generatedProposal = Proposal.generateProposal("DELETE", key, value);
    return coordinator.execute(generatedProposal);
  }

  @Override
  public Promise propose(Proposal proposal) throws RemoteException, IOException, TimeoutException, RuntimeException {
    ServerLogger.info(String.format("PROPOSE request received for %s", proposal));

    /******************************************************************/
    // /* simulate random failure (limit to 10%) by throwing random exceptions */
    // if (new Random().nextInt(100) < 10) {
    // ServerLogger.info("Simulated a random failure in PROPOSE operation.");
    // // Simulating random exceptions
    // int exceptionType = new Random().nextInt(3); // Choosing from 3 different
    // exception types
    // switch (exceptionType) {
    // case 0:
    // throw new IOException("Simulated IOException occurred during PROPOSE
    // operation.");
    // case 1:
    // throw new TimeoutException("Simulated TimeoutException occurred during
    // PROPOSE operation.");
    // default:
    // throw new RuntimeException("Simulated runtime exception occurred during
    // PROPOSE operation.");
    // }
    // }
    /******************************************************************/

    /******************************************************************/
    /* simulate network delays (< 0.1s) */
    // int randomDelay = new Random().nextInt(100);
    // ServerLogger.info(String.format("Simulated random network delay for %s ms",
    // randomDelay));
    // try {
    // Thread.sleep(randomDelay);
    // } catch (InterruptedException e) {
    // Thread.currentThread().interrupt();
    // ServerLogger.error("PROPOSE operation was interrupted during random delay.");
    // }
    /******************************************************************/

    Promise response = new Promise();
    if (proposal.getProposalId() > this.maxProposalId) {
      this.maxProposalId = proposal.getProposalId();
      ServerLogger.info(String.format("Setting new max ID[%s]", this.maxProposalId));
      response.setStatus("200");
    } else {
      response.setStatus("500");
      ServerLogger.error(
          String.format("Proposal rejected: proposal ID[%s] is not higher than max ID[%s]",
              proposal.getProposalId(), this.maxProposalId));
    }

    return response;
  }

  @Override
  public Boolean accept(Proposal proposal) throws RemoteException, IOException, TimeoutException, RuntimeException {
    ServerLogger.info(String.format("ACCEPT request received for %s", proposal));

    // work solution
    // simulate random failure (limit to 10%) without throwing exceptions
    // if (new Random().nextInt(100) < 10) {
    //   ServerLogger.error("Simulated a random failure in ACCEPT operation...");
    //   return Boolean.FALSE; // return failure status instead of throwing an exception
    // }

    // // simulate network delays (< 0.1s)
    // int randomDelay = new Random().nextInt(100);
    // try {
    //   Thread.sleep(randomDelay);
    //   ServerLogger.info(String.format("Simulated random network delay for %s ms", randomDelay));
    // } catch (InterruptedException e) {
    //   ServerLogger.error("ACCEPT operation was interrupted during random delay.");
    //   return Boolean.FALSE; // Return failure status if interrupted
    // }

    /**********************************************************************************************************************************/
    /* simulate random failure (limit to 5%) by throwing random exceptions */
    if (new Random().nextInt(100) < 5) {
      ServerLogger.error("Simulated a failure in ACCEPT operation...");
      // Simulating random exceptions
      int exceptionType = new Random().nextInt(2); // Choosing a random exception to thrown from 2 different exception types
      switch (exceptionType) {
        case 0:
          ServerLogger.error(String.format("Simulated IOException occurred in server[%s] during ACCEPT operation.", portNum));
          break;
        default:
          ServerLogger.error(String.format("Simulated RuntimeException occurred in server[%s] during ACCEPT operation.", portNum));
          break;
      }
    }

    /* simulate network delays (< 0.1s) */
    int randomDelay = new Random().nextInt(100);

    // set excessive delay to test timeout // 
    // randomDelay = 1000;

    /**********************************************************************************************************************************/
    /* simulate random operational timeout (limit to 5%) */
    if (randomDelay > 95) { // 5% chance of operational timeout
      ServerLogger.error(String.format("Simulated random network delay for [%s ms] exceeds the threshold[%s ms]", randomDelay, 100));
      ServerLogger.error(String.format("Simulated TimeoutException occurred in server[%s] during ACCEPT operation.", portNum));
      return Boolean.FALSE; // simulate a timeout response
    }

    try {
      Thread.sleep(randomDelay);
      ServerLogger.info(String.format("Simulated random network delay for %s ms", randomDelay));
    } catch (InterruptedException e) {
      ServerLogger.error("ACCEPT operation was interrupted during random delay.");
    }

    // only accept when incoming proposal ID matches maxProposalId maintained by the
    // server
    if (proposal.getProposalId() != this.maxProposalId) {
      ServerLogger.error(String.format("ACCEPT rejected: proposal ID[%s] does not match max ID[%s]",
          proposal.getProposalId(), this.maxProposalId));
      return Boolean.FALSE;
    } else {
      ServerLogger.info(String.format("ACCEPT success for %s", proposal));
      return Boolean.TRUE;
    }
  }

  @Override
  public void learn(Proposal proposal) throws RemoteException {
    ServerLogger.info(String.format("LEARN request received for %s", proposal));

    // trim input for better user interaction
    if (proposal.getKey() == null || proposal.getKey().trim().isEmpty()) {
      throw new IllegalArgumentException(
          "Key must not be null or empty after being trimmed.");
    }

    String key = proposal.getKey().trim();
    String value = (proposal.getValue() == null) ? "" : proposal.getValue().trim(); // Safe trim for value
    String operation = proposal.getOperation();

    if (operation.equals("PUT")) {
      KeyValueStore.getInstance().put(key, value);
      ServerLogger.info("PUT operation executed: Key=" + key + ", Value=" + value);
    } else if (operation.equals("DELETE")) {
      KeyValueStore.getInstance().delete(key);
      ServerLogger.info("DELETE operation executed: Key=" + key);
    }

    ServerLogger.info(String.format("LEARN operation[%s] completed for Key=%s", operation, key));
  }
}
