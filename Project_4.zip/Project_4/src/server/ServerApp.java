package server;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import api.KeyValueRpc;

/**
 * The ServerApp class initializes an RMI server instance which binds a remote
 * service to the RMI registry.
 * It allows clients to perform remote operations via the KeyValueRpc interface.
 */
public class ServerApp extends KeyValueRpcImpl {

    // record the application start time for logging and simulation
    public static long appStartTime = System.currentTimeMillis();
    // record the server port for creating unique proposal id
    public static int portNum;

    /**
     * Constructs a ServerApp instance which binds a KeyValueRpc stub to the RMI
     * registry.
     *
     * @param host the hostname on which the registry is to run
     * @param port the port number on which the registry listens
     * @throws RemoteException if a remote communication error occurs
     */
    protected ServerApp(String host, int port) throws RemoteException {
        try {
            KeyValueRpc stub = new KeyValueRpcImpl();

            portNum = port;
            String bindingName = "rpc-server-" + port;
            String registryURL = "//" + host + ":" + port + "/" + bindingName;

            // attempt to get the registry; if not found, create it
            Registry registry;
            try {
                registry = LocateRegistry.getRegistry(host, port);
                registry.list(); // This will throw an exception if the registry does not exist
            } catch (RemoteException e) {
                registry = LocateRegistry.createRegistry(port); // Create the registry if it does not exist
                ServerLogger.info(String.format("RMI registry created on port[%s] ", port));
            }

            // bind the stub in the registry
            Naming.rebind(registryURL, stub);

            ServerLogger.info(
                    String.format("Server[%s] is ready at URL[%s]...", bindingName, registryURL));
        } catch (RemoteException | MalformedURLException e) {
            ServerLogger.error("Error occurred while setting up the server: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * The main method is the entry point of the server application.
     *
     * @param args Command line arguments containing host and port
     * @throws RemoteException if a remote communication error occurs
     */
    public static void main(String[] args) throws RemoteException {
        if (args.length < 2) {
            ServerLogger.info(
                    "Invalid Arguments. Usage: java -cp server.jar server.ServerApp <host> <port> " + 
                    "e.g. `java -cp server.jar server.ServerApp localhost 4001`");
            return;
        }
        String host = args[0];
        int portNum = Integer.parseInt(args[1]);
        new ServerApp(host, portNum);
    }
}