package consensus;

import java.io.Serializable;

/**
 * Represents a promise as part of the Paxos consensus algorithm.
 * This class encapsulates a response from an acceptor in the prepare phase of the Paxos protocol.
 * A promise shows whether an acceptor agrees to reject any proposals numbered less than
 * the one included in the prepare request it responded to.
 * This object is serializable to allow for transmission over a network in a distributed system.
 */
public class Promise implements Serializable {

  private static final long serialVersionUID = 1L;
  // status code of the promise ("200" for OK, "500" for error)
  private String status;
  // the value previously accepted by the acceptor
  private String previousAcceptedValue;

  /**
     * Constructs an empty Promise, typically for use before setting specific properties.
     */
  public Promise() {
  }

   /**
     * Constructs a Promise with a specific status and the last accepted value.
     * 
     * @param status The status of the promise, typically a code like "200" for a successful promise.
     * @param previousAcceptedValue The last value accepted by the acceptor, if any; otherwise, null.
     */
  public Promise(String status, String previousAcceptedValue) {
    this.status = status;
    this.previousAcceptedValue = previousAcceptedValue;
  }

  /**
     * Sets the status of the promise.
     * 
     * @param status The status code to set, indicating the outcome of the prepare request.
     */
  public void setStatus(String status) {
    this.status = status;
  }

  /**
     * Returns the status of the promise.
     * 
     * @return A string representing the status code of the promise.
     */
  public String getStatus() {
    return status;
  }

  /**
     * Sets the previously accepted value associated with this promise.
     * 
     * @param previousAcceptedValue The value to set, reflecting the last value accepted by the acceptor.
     */
    public void setPreviousAcceptedValue(String previousAcceptedValue) {
      this.previousAcceptedValue = previousAcceptedValue;
  }

  /**
   * Returns the previously accepted value, if any, associated with this promise.
   * 
   * @return A string representing the previously accepted value, or null if there was none.
   */
  public String getPreviousAcceptedValue() {
      return previousAcceptedValue;
  }
}