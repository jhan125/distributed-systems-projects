package consensus;

import java.io.Serializable;

import server.ServerLogger;
import static server.ServerApp.portNum;

/**
 * This class represents a proposal in a distributed consensus algorithm.
 * Each proposal includes a unique proposal ID, an operation, a key, and a
 * value.
 */
public class Proposal implements Serializable {

  private long proposalId;
  private String operation;
  private String key;
  private String value;

  /**
   * Constructs a new Proposal object with the specified proposal ID, operation,
   * key, and value.
   *
   * @param proposalId The unique ID of the proposal.
   * @param operation  The operation associated with the proposal.
   * @param key        The key associated with the proposal.
   * @param value      The value associated with the proposal.
   */
  public Proposal(long proposalId, String operation, String key, String value) {
    this.proposalId = proposalId;
    this.operation = operation;
    this.key = key;
    this.value = value;
  }

  /**
   * Retrieves the proposal ID.
   *
   * @return The proposal ID.
   */
  public long getProposalId() {
    return proposalId;
  }

  /**
   * Retrieves the operation associated with the proposal.
   *
   * @return The operation associated with the proposal.
   */
  public String getOperation() {
    return operation;
  }

  /**
   * Retrieves the key associated with the proposal.
   *
   * @return The key associated with the proposal.
   */
  public String getKey() {
    return key;
  }

  /**
   * Retrieves the value associated with the proposal.
   *
   * @return The value associated with the proposal.
   */
  public String getValue() {
    return value;
  }

  /**
   * Generates a new proposal object with a unique proposal ID based on elapsed
   * time since application start.
   * This method ensures that each proposal has a unique ID that increases as time
   * progresses.
   *
   * @param operation The operation associated with the proposal.
   * @param key       The key associated with the proposal.
   * @param value     The value associated with the proposal.
   * @return A new Proposal object with a unique proposal ID.
   */
  public static synchronized Proposal generateProposal(String operation, String key, String value) {

    // to make proposal id unique across concurrent requests
    // combine timestamp counter and the server port number so it's unique
    // e.g. so concurrent requests have different ids '12345.4001', '12345.4002'

    long uniqueTime = System.nanoTime();
    long baseTime = uniqueTime / 10000; // Reduce the size to manage the number within a reasonable range.

    long proposalID = baseTime * 100000 + portNum;

    ServerLogger.info(String.format("Generating a new proposal with ID: %s", proposalID));

    return new Proposal(proposalID, operation, key, value);
  }

  @Override
  public String toString() {
    return String.format("Proposal{proposalId=%d, operation='%s', key='%s', value='%s'}",
        proposalId, operation, key, value);
  }
}