package consensus;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.io.IOException;
import java.lang.RuntimeException;
import java.util.concurrent.TimeoutException;


/**
 * Interface provides operations to initiate different stages
 * of the paxos algorithm.
 */
public interface Paxos extends Remote {

  /**
   * Sends a propose/prepare request to the server. 
   * Server returns a positive acknowledgement if n > maxId of the server.
   * 
   * @param proposal proposal
   * @return promise containing the result
   * @throws RemoteException if RPC communication fails
   * @throws IOException if there's simulated random failure
   * @throws TimeoutException if there's simulated random failure
   * @throws RuntimeException if there's simulated random failure
   */
  Promise propose(Proposal proposal) throws RemoteException, IOException, TimeoutException, RuntimeException;

  /**
   * Sends an accept request to the server. 
   * Server returns a positive acknowledgement if n == maxId of the server.
   * 
   * @param proposal proposal
   * @return boolean result
   * @throws RemoteException if RPC communication fails
   * @throws IOException if there's simulated random failure
   * @throws TimeoutException if there's simulated random failure
   * @throws RuntimeException if there's simulated random failure
   */
  Boolean accept(Proposal proposal) throws RemoteException, IOException, TimeoutException, RuntimeException;


  /**
   * Sends a learn message for the execution of user specified operation.
   * 
   * @param proposal proposal
   * @throws RemoteException if RPC communication fails
   */
  void learn(Proposal proposal) throws RemoteException;
}