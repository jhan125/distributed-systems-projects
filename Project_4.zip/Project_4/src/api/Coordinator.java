package api;

import java.rmi.Remote;
import java.rmi.RemoteException;

import consensus.Proposal;

/**
 * Defines the contract for a coordinator in the Paxos consensus algorithm.
 * This interface provides the mechanism for initiating the consensus process on a given proposal 
 * across distributed components. It is implemented by a remote object in an RMI environment.
 */
public interface Coordinator extends Remote {

  /**
   * Executes a distributed consensus process on the given proposal using the Paxos algorithm.
   * This method manages the sequence of steps in the Paxos protocol: prepare, accept, and learn.
   * It ensures that the proposed change (if agreed upon by a majority) is consistently applied across all participants.
   *
   * @param proposal A proposal containing the operation type, key, value, and a unique identifier.
   *                 The proposal object encapsulates the action to be agreed upon by the consensus algorithm.
   * @return The result of the operation execution, including success status, 
   *                 potential error messages, and the operation's output.
   * @throws RemoteException If a remote communication error occurs during the consensus process.
   */
  KeyValueResponse execute(Proposal proposal) throws RemoteException;
}
