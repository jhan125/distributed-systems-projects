# Project 3: Replicated Multi-threaded Key-Value Stores using RPC and 2PC Protocol


## Project Overview

This project aims to enhance the a single-instance Key-Value Store Server I achieved in Project 2. 

Requirements include:
- introduce replication across five servers, so the system can increase bandwidth and ensure high availability. 
- ensure consistent data access and update operations (GET, PUT, DELETE) across replicas. 
- implement a two-phase commit (2PC) protocol for data consistency during PUT and DELETE operations. 
- include timeouts in the 2PC protocol for robustness, despite not expecting server failures. 
- use a client to perform preload operations (at least 5 of each operation: 5 PUTs, 5 GETs, 5 DELETEs).
- write well-structured and commented Java code for manageability and future use.

## System Architecture

The system implements a Key-Value Store to support consistency across five replicated servers, managed by a coordinating server that initiates 2PC protocol. As a type of atomic commitment protocol used in distributed systems to ensure that all participants in a transaction either commit to the transaction successfully or abort and roll back, the implementation of 2PC protocol maintains the system's consistency. 

The process involves 2 phases: "prepare" phase 1 and "commit" phase 2. In the prepare phase, a coordinator process asks all participants (or nodes) if they can commit. If all participants agree, the coordinator proceeds to the second phase, where it instructs all nodes to commit the transaction. If any participant votes 'no', the transaction is aborted. This protocol improves system resilience and data reliability. Each coordinator and participant operates on distinct ports, thus facilitating clear communication within the distributed environment. 

The system architecture includes 3 main components: the coordinator, the replica servers(participants), and the client. 

### Coordinator

Coordinator is responsible for coordinating the replicas/participants by a two-phase commit (2PC) protocol to synchronize PUT and DELETE operations, so transactions maintain consistency and atomicity.

### Participants/Replica servers 

Participants/Replica servers are responsible for hosting replicated instances of the key-value store, handling client requests for data operations. For PUT and DELETE operations, they participate in the 2PC process for data consistency. They also serve GET requests directly to clients.

### Clients 

Clients are capable to interact with any of the five replicas for operations like GET, PUT, and DELETE. Because of 2PC protocol and coordinator's help, they receive consistent data across replicas. 


## Project Structure

- **`src/`**: Contains all source code for the project.
- **`src/server/`**: Includes specific code for the server-side application, such as `Server` class that sets up the server instance, connecting to the coordinator and establishing RMI services, `ServerApp` as the entry point for the server application, `KeyValueStore` for implementing the thread-safe storage for key-value pairs, `KeyValueRpcImpl` that implements the KeyValueRpc interface for handling RPC requests from clients, and `ServerLogger` for logging server-side operations. The `Dockerfile` is for creating a containerized version of the server application.
- **`src/client/`**: Includes specific code for the client-side application, such as `Client` interface for client callbacks, `ClientApp` class as the entry point for the client application, handling user input and initiating requests to the server, and `ClientLogger`  for logging client-side operations. 
- **`src/api/`**: Includes interfaces and shared data models for facilitating RPC between the different components of the system, such as `KeyValueRpc` interface that defines the methods available for client-server communication and `TransactionService` interface that outlines the methods used for coordinating transactions across multiple servers.
- **`src/coordinator/`**: Includes the classes required for the transaction coordinator's functionality,such as `Coordinator` interface that handles transaction coordination logic, `CoordinatorApp` as the main class for the coordinator application, and `CoordinatorLogger` for logging coordinator-side operations. The `Dockerfile` and `Manifest_coordinator.txt` are used for containerization and specifying the main class for JAR packaging, respectively.
- **`src/protocol/`**: Includes shared enums and classes that define the protocol used between clients, servers, and the coordinator, such as `OperationType` for the type of operations (e.g., PUT, GET, DELETE), and `TransactionMessage` for encapsulating a transaction message's details.
- **`jars/`**: Jars, including `coordinator.jar`, `server.jar`, and `client.jar`.
- **`docs/`**: Documentation files, including class diagram and project specifications.
- **`res/`**: Testing screenshots, including concurrent client requests and interactions on both server and client
  sides.

```
.
├── ExecutiveSummary.md
├── README.md
├── docs
│   ├── Project1_Description.md
│   ├── Project2_Description.md
│   └── Project3_Description.md
├── jars
│   ├── client.jar
│   ├── coordinator.jar
│   └── server.jar
├── res
│   ├── testClientInvalidInput
│   │   ├── client-enter-empty-key.png
│   │   ├── client-enter-invalid-operation.png
│   │   ├── client-enter-null-value.png
│   │   └── client-select-invalid-server.png
│   ├── testMultiClientsRequests
│   │   ├── client1-PUT-server[4].png
│   │   ├── client2-GET-server[2].png
│   │   ├── coordinator-logs.png
│   │   ├── server[2]-PUT-GET-logs.png
│   │   └── server[4]-PUT-logs.png
│   ├── testOperationsFail
│   │   ├── test-DELETE-fail
│   │   │   ├── client-DELETE-fail.png
│   │   │   ├── coordinator-DELETE-logs.png
│   │   │   ├── server[0]-DELETE-abort.png
│   │   │   ├── server[1]-DELETE-abort.png
│   │   │   ├── server[2]-DELETE-abort.png
│   │   │   ├── server[3]-DELETE-abort.png
│   │   │   └── server[4]-DELETE-abort.png
│   │   └── test-GET-fail
│   │       ├── client-GET-fail-server[2].png
│   │       └── server[2]-GET-fail-log.png
│   ├── testOperationsSuccess
│   │   ├── test-DELETE-success
│   │   │   ├── client-DELETE-server[1].png
│   │   │   ├── coordinator-DELETE-logs.png
│   │   │   ├── server[0]-DELETE-commit.png
│   │   │   ├── server[1]-DELETE-commit.png
│   │   │   ├── server[2]-DELETE-commit.png
│   │   │   ├── server[3]-DELETE-commit.png
│   │   │   └── server[4]-DELETE-commit.png
│   │   ├── test-GET-success
│   │   │   ├── client-GET-sucess-server[0].png
│   │   │   └── server[0]-GET-sucess-logs.png
│   │   └── test-PUT-success
│   │       ├── client-PUT-success-server[4].png
│   │       ├── coordinator-PUT-logs.png
│   │       ├── server[0]-PUT-commit.png
│   │       ├── server[1]-PUT-commit.png
│   │       ├── server[2]-PUT-commit.png
│   │       ├── server[3]-PUT-commit.png
│   │       └── server[4]-PUT-commit.png
│   ├── testPreload
│   │   ├── client-preload-logs.png
│   │   ├── coordinator-preload-glimpse.png
│   │   ├── server[0]-preload-glimpse.png
│   │   ├── server[1]-preload-glimpse.png
│   │   ├── server[2]-preload-glimpse.png
│   │   ├── server[3]-preload-glimpse.png
│   │   └── server[4]-preload-glimpse.png
│   ├── testSetup
│   │   ├── client-start.png
│   │   ├── coordinator_start.png
│   │   ├── participant1-start.png
│   │   ├── participant2-start.png
│   │   ├── participant3-start.png
│   │   ├── participant4-start.png
│   │   └── participant5-start.png
│   └── testTimeout
│       ├── client-preload-timeout.png
│       └── client-request-timeout.png
└── src
    ├── api
    │   ├── KeyValueRpc.java
    │   └── TransactionService.java
    ├── client
    │   ├── Client.java
    │   ├── ClientApp.java
    │   └── ClientLogger.java
    ├── coordinator
    │   ├── Coordinator.java
    │   ├── CoordinatorApp.java
    │   ├── CoordinatorImpl.java
    │   └── CoordinatorLogger.java
    ├── protocol
    │   ├── OperationType.java
    │   └── TransactionMessage.java
    └── server
        ├── KeyValueRpcImpl.java
        ├── KeyValueStore.java
        ├── Server.java
        ├── ServerApp.java
        └── ServerLogger.java

22 directories, 74 files
```

## Design Considerations

1. **Extended RMI for Distributed System**: In Project 2, I used Java`RMI` framework to abstract the complexity of network programming, thus meeting the requirement to transition from socket-based communication to a more streamlined, object-oriented approach. In this project, I extended the use of RMI to inter-server communication, thus meeting the requirement to enable efficient coordination for 2PC protocol among the replicated servers.

2. **Used Two-Phase Commit Protocol for Consistency**: In this project, I implemented a 2PC protocol across server replicas(participants) so there's strong consistency for transactions, which means all or none of the replicas commit a change. I also designed a dedicated transaction coordinator, operating as a separate entity, to manage the prepare and commit/abort phases across all participant servers. 
   
3. **Used a Centralized Transaction Coordinator**: As mentioned Section 2, in this project, I designed a centralized transaction coordinator to manage the 2PC protocol across server replicas. This is robust to handle transactions by gathering consensus from replicas(participant servers) and directing whether to commit or rollback changes.
   
4. **Detected Failure and Logged for Recovery**: As mentioned in Section 2, in this project, I also designed mechanisms to detect server failures. This includes timeout mechanisms for 2PC protocol, logging every necessary transaction state, and handling partial failures among replicas.
   
5. **Utilized UUIDs for Unique Identification**: In this project, I used UUID(Universally Unique Identifiers) to give the coordinator, each participant servers, each client, and each individual transaction a unique UUID. This enables to track transactions across the network. It also facilitates debugging and monitoring. If there's a need to recover from failures, such precise identifications of transaction states and associated components will also be super helpful.

6. **Handled Asynchronous and Concurrent Requests**: In this project, I made careful design on the server side so it can incorporate multi-threading to handle incoming client requests and inter-server communication concurrently. This ensures that the system can process multiple operations simultaneously without bottlenecks, thereby improving throughput and responsiveness.
   
7. **Managed Key-Value Pair Access with Mutex Locks for Thread-safety**: In Project 2, my design chose to use `ReentrantLock` to safeguard critical sections during write operations (especially the put and delete methods). In this project, my design is consistent in utilizing `ReentrantLock` so the replica updates during the commit phase of 2PC are mutually exclusive. In this case, transactions keep atomicity and data consistency across replicas in a multi-threaded environment.

8. **Scalable and Configurable RMI Registry Management**: In this project, I decided to use `command-line arguments` for setting up and managing RMI registry. This allows users to set up port numbers for the coordinator, replica servers, and clients with their preference.
   
9. **Graceful Handling of System Failures and Timeouts**: In Project 1 and Project 2, I used timeout mechanisms that effectively handles the scenarios where the server is slow to respond or entirely unresponsive. In this project, I refined the timeout mechanisms and failure handling strategies to account for the complexities of distributed transactions. This includes strategies for aborting transactions in case of failures, timeouts, or lack of consensus among replicas, thus ensuring the system can recover to a consistent state.

10. **Logging and Monitoring for Distributed Transactions**: In Project 1 and Project 2, I used logging mechanisms for both server and client sides. In this project, I enhanced the logging mechanisms to cover distributed transaction flows so developers like me can easier debug and monitor the system behavior. To achieve this, I included logs on the coordinator side as well so there are detailed logs for each phase of the 2PC protocol, decisions made by the coordinator, and the final outcome of transactions.

## How to Run This Project

### Step-by-Step Instructions on TCP Connection

#### I. Set up Coordinator

1. Enter the root directory of this project then go to the `/jars` folder that includes `coordinator.jar`, `server.jar`, and `client.jar`.

```angular2html
cd jars
```

2. Open `Terminal-1` , run the command argument in the terminal with a port number for coordinator.

```angular2html
java -jar coordinator.jar <coordinator-port>
```

An example would be:
```angular2html
java -jar coordinator.jar 1099
```

3. If you see the log message similar as below (Timestamp would vary), this means the coordinator has been set up successfully.

```angular2html
[PST-Time-Zone] 2024-04-04 14:49:54.626 [Level] INFO, [Message] Coordinator is ready at host[shoutings-mbp.lan] port[1099]: 
```

**NOTE**: If you're on Unix/Linux/macOS, you can use `lsof -i :1099` to see if any process is using port 1099, then use `kill <PID>` to stop it.


#### II. Set up Server

1. Enter the root directory of this project then go to the `/jars` folder that includes `coordinator.jar`, `server.jar`, and `client.jar`.

```angular2html
cd jars
```

2. Open 5 separate terminal windows for replica servers `Terminal-2` `Terminal-3` `Terminal-4` `Terminal-5` `Terminal-6`, then run the command arguments in correct order in each terminal.

**NOTE**: 

Whenever you want to start a new server, you need to open a new terminal window and enter `cd jars` before entering the command.

If you're on Unix/Linux/macOS, use `lsof -i :4001` to see if any process is using port 4001, then use `kill <PID>` to stop it.

```angular2html
java -jar server.jar <coordinator-hostname> <coordinator-port> <server-port>
```

An example would be:
```angular2html
java -jar server.jar localhost 1099 4001 
java -jar server.jar localhost 1099 4002
java -jar server.jar localhost 1099 4003
java -jar server.jar localhost 1099 4004
java -jar server.jar localhost 1099 4005
```

3. If you see the log message on each server side similar as below (Timestamp would vary), this means the servers have been set up successfully.
   
```angular2html
[PST-Time-Zone] 2024-04-04 15:04:10.716 [Level] INFO, [Message] Server[654c7361-d467-442a-b108-ea328b51dd54] is ready at port[4001]
```
```angular2html
[PST-Time-Zone] 2024-04-04 15:07:40.243 [Level] INFO, [Message] Server[b7375e55-32ed-44b2-8da2-25318dde55eb] is ready at port[4002]
```
```angular2html
[PST-Time-Zone] 2024-04-04 15:07:48.895 [Level] INFO, [Message] Server[01dbf1aa-0b67-4fad-9428-4238291b2dff] is ready at port[4003]
```
```angular2html
[PST-Time-Zone] 2024-04-04 15:07:55.324 [Level] INFO, [Message] Server[9517f3be-027f-4f04-a650-3cc93c20664f] is ready at port[4004]
```
```angular2html
[PST-Time-Zone] 2024-04-04 15:08:03.561 [Level] INFO, [Message] Server[c241ce68-ed9e-49c3-89a3-3a7c93eac1d3] is ready at port[4005]
```

4. You should also see the log message on the coordinator side that indicates this successful connection from participant server to coordinator.
```angular2html
[PST-Time-Zone] 2024-04-04 15:04:03.525 [Level] INFO, [Message] Coordinator is ready at host[shoutings-mbp.lan] port[1099]: 
[PST-Time-Zone] 2024-04-04 15:04:10.794 [Level] INFO, [Message] Server[654c7361-d467-442a-b108-ea328b51dd54] at host[shoutings-mbp.lan]:port[4001] successfully registered.
[PST-Time-Zone] 2024-04-04 15:04:10.795 [Level] INFO, [Message] 1 server(s) have successfully connected to Coordinator.
[PST-Time-Zone] 2024-04-04 15:07:40.271 [Level] INFO, [Message] Server[b7375e55-32ed-44b2-8da2-25318dde55eb] at host[shoutings-mbp.lan]:port[4002] successfully registered.
[PST-Time-Zone] 2024-04-04 15:07:40.271 [Level] INFO, [Message] 2 server(s) have successfully connected to Coordinator.
[PST-Time-Zone] 2024-04-04 15:07:48.919 [Level] INFO, [Message] Server[01dbf1aa-0b67-4fad-9428-4238291b2dff] at host[shoutings-mbp.lan]:port[4003] successfully registered.
[PST-Time-Zone] 2024-04-04 15:07:48.919 [Level] INFO, [Message] 3 server(s) have successfully connected to Coordinator.
[PST-Time-Zone] 2024-04-04 15:07:55.347 [Level] INFO, [Message] Server[9517f3be-027f-4f04-a650-3cc93c20664f] at host[shoutings-mbp.lan]:port[4004] successfully registered.
[PST-Time-Zone] 2024-04-04 15:07:55.347 [Level] INFO, [Message] 4 server(s) have successfully connected to Coordinator.
[PST-Time-Zone] 2024-04-04 15:08:03.583 [Level] INFO, [Message] Server[c241ce68-ed9e-49c3-89a3-3a7c93eac1d3] at host[shoutings-mbp.lan]:port[4005] successfully registered.
[PST-Time-Zone] 2024-04-04 15:08:03.583 [Level] INFO, [Message] 5 server(s) have successfully connected to Coordinator.
```

#### III. Set up Client

1. Enter the root directory of this project then go to the `/jars` folder that includes `coordinator.jar`, `server.jar`, and `client.jar`.

```angular2html
cd jars
```

2. Open separate terminal windows if you want to start multiple clients like `Terminal-7` `Terminal-8` ... , then run the command arguments in correct order.

**NOTE**: 

Whenever you want to start a new client, you need to open a new terminal window and enter `cd jars` before entering the command.

If you're on Unix/Linux/macOS, use `lsof -i :4010` to see if any process is using port 4010, then use `kill <PID>` to stop it.

```angular2html
java -jar client.jar <server1-hostname> <server1-port> <server2-hostname> <server2-port> <server3-hostname> <server3-port> <server4-hostname> <server4-port> <server5-hostname> <server5-port> <client-port>
```

An example would be:
```angular2html
java -jar client.jar localhost 4001 localhost 4002 localhost 4003 localhost 4004 localhost 4005 4010
```

You can also start more clients like:
```angular2html
java -jar client.jar localhost 4001 localhost 4002 localhost 4003 localhost 4004 localhost 4005 4011
java -jar client.jar localhost 4001 localhost 4002 localhost 4003 localhost 4004 localhost 4005 4012
java -jar client.jar localhost 4001 localhost 4002 localhost 4003 localhost 4004 localhost 4005 4013
...
```

3. If you see the log message on the client side similar as below (Timestamp would vary), this means the client has been set up successfully.

```angular2html
[PST-Time-Zone] 2024-04-04 15:12:50.730 [Level] INFO, [Message] Client started with ID[868c2e48-7034-4973-8a92-28e3a88d395a]
[PST-Time-Zone] 2024-04-04 15:12:50.883 [Level] INFO, [Message] Connected to server[0] with serverId[654c7361-d467-442a-b108-ea328b51dd54]
[PST-Time-Zone] 2024-04-04 15:12:50.894 [Level] INFO, [Message] Connected to server[1] with serverId[b7375e55-32ed-44b2-8da2-25318dde55eb]
[PST-Time-Zone] 2024-04-04 15:12:50.905 [Level] INFO, [Message] Connected to server[2] with serverId[01dbf1aa-0b67-4fad-9428-4238291b2dff]
[PST-Time-Zone] 2024-04-04 15:12:50.930 [Level] INFO, [Message] Connected to server[3] with serverId[9517f3be-027f-4f04-a650-3cc93c20664f]
[PST-Time-Zone] 2024-04-04 15:12:50.970 [Level] INFO, [Message] Connected to server[4] with serverId[c241ce68-ed9e-49c3-89a3-3a7c93eac1d3]
```

#### IV. Client Preload Operations

Per project requirement, after successfully connects to the 5 replica servers, the client side will automatically preload operations for 5 PUTs, 5 GETs, 5 DELETEs, and then 5 PUTs. So after you successfully set up the client, you will first see the log messages on the client side as below.

```angular2html
[PST-Time-Zone] 2024-04-05 12:53:25.586 [Level] INFO, [Message] Client started with ID[75370cb1-7729-4e40-9dd1-eecd930fd384]
[PST-Time-Zone] 2024-04-05 12:53:25.716 [Level] INFO, [Message] Connected to server[0] with serverId[39ddee70-e62c-402d-84bf-f872e7c1a80f]
[PST-Time-Zone] 2024-04-05 12:53:25.727 [Level] INFO, [Message] Connected to server[1] with serverId[04b5a2f4-df87-4234-be9d-3b3fc85636b9]
[PST-Time-Zone] 2024-04-05 12:53:25.740 [Level] INFO, [Message] Connected to server[2] with serverId[fe988be1-9d9b-4aaf-a0ad-941e98886688]
[PST-Time-Zone] 2024-04-05 12:53:25.747 [Level] INFO, [Message] Connected to server[3] with serverId[70206384-8bb0-4e78-8fd4-8f0295d12e99]
[PST-Time-Zone] 2024-04-05 12:53:25.758 [Level] INFO, [Message] Connected to server[4] with serverId[8d7b2084-9c45-4345-8a03-79df2717b366]
[PST-Time-Zone] 2024-04-05 12:53:25.759 [Level] INFO, [Message] Per project requirement, preload operations to any server from [0,1,2,3,4]. 
[PST-Time-Zone] 2024-04-05 12:53:25.759 [Level] INFO, [Message] Preload 5 PUTs to any server from [0,1,2,3,4].
[PST-Time-Zone] 2024-04-05 12:53:27.662 [Level] INFO, [Message] Received response from server[3]: <key=6650, value=Scalable Distributed Systems> has been successfully stored.
[PST-Time-Zone] 2024-04-05 12:53:30.670 [Level] INFO, [Message] Received response from server[3]: <key=5800, value=Algorithms> has been successfully stored.
[PST-Time-Zone] 2024-04-05 12:53:34.681 [Level] INFO, [Message] Received response from server[3]: <key=5700, value=Computer Networking> has been successfully stored.
[PST-Time-Zone] 2024-04-05 12:53:37.689 [Level] INFO, [Message] Received response from server[2]: <key=6140, value=Machine Learning> has been successfully stored.
[PST-Time-Zone] 2024-04-05 12:53:41.700 [Level] INFO, [Message] Received response from server[1]: <key=5200, value=Database Management> has been successfully stored.
[PST-Time-Zone] 2024-04-05 12:53:43.359 [Level] INFO, [Message] Preload 5 GETs to any server from [0,1,2,3,4].
[PST-Time-Zone] 2024-04-05 12:53:43.364 [Level] INFO, [Message] Received response from server[3]: value=Scalable Distributed Systems
[PST-Time-Zone] 2024-04-05 12:53:43.366 [Level] INFO, [Message] Received response from server[0]: value=Algorithms
[PST-Time-Zone] 2024-04-05 12:53:43.369 [Level] INFO, [Message] Received response from server[1]: value=Computer Networking
[PST-Time-Zone] 2024-04-05 12:53:43.371 [Level] INFO, [Message] Received response from server[0]: value=Machine Learning
[PST-Time-Zone] 2024-04-05 12:53:43.372 [Level] INFO, [Message] Received response from server[3]: value=Database Management
[PST-Time-Zone] 2024-04-05 12:53:43.372 [Level] INFO, [Message] Preload 5 DELETEs to any server from [0,1,2,3,4].
[PST-Time-Zone] 2024-04-05 12:53:44.707 [Level] INFO, [Message] Received response from server[2]: [key=6650] has been successfully deleted.
[PST-Time-Zone] 2024-04-05 12:53:48.719 [Level] INFO, [Message] Received response from server[3]: [key=5800] has been successfully deleted.
[PST-Time-Zone] 2024-04-05 12:53:51.726 [Level] INFO, [Message] Received response from server[3]: [key=5700] has been successfully deleted.
[PST-Time-Zone] 2024-04-05 12:53:55.738 [Level] INFO, [Message] Received response from server[3]: [key=6140] has been successfully deleted.
[PST-Time-Zone] 2024-04-05 12:53:58.748 [Level] INFO, [Message] Received response from server[0]: [key=5200] has been successfully deleted.
[PST-Time-Zone] 2024-04-05 12:54:00.948 [Level] INFO, [Message] Preload 5 PUTs to any server from [0,1,2,3,4].
[PST-Time-Zone] 2024-04-05 12:54:02.759 [Level] INFO, [Message] Received response from server[3]: <key=6650, value=Scalable Distributed Systems> has been successfully stored.
[PST-Time-Zone] 2024-04-05 12:54:05.769 [Level] INFO, [Message] Received response from server[1]: <key=5800, value=Algorithms> has been successfully stored.
[PST-Time-Zone] 2024-04-05 12:54:09.782 [Level] INFO, [Message] Received response from server[1]: <key=5700, value=Computer Networking> has been successfully stored.
[PST-Time-Zone] 2024-04-05 12:54:12.787 [Level] INFO, [Message] Received response from server[0]: <key=6140, value=Machine Learning> has been successfully stored.
[PST-Time-Zone] 2024-04-05 12:54:16.799 [Level] INFO, [Message] Received response from server[2]: <key=5200, value=Database Management> has been successfully stored.
[PST-Time-Zone] 2024-04-05 12:54:18.527 [Level] INFO, [Message] Preload operations completed.
```

**Notice**

❗️ You will also see a super long log on the `coordinator` side that records as below. 

As required for 2PC protocol, these logs record the state of transactions and uses to coordinate the recovery process in case of failures. They includes detailed and necessary information like 
- when a new transaction begins.
- when the coordinator sends out requests to participants to vote on whether they can commit the transaction.
- responses (vote to commit or abort) from each participant for each transaction.
- final decision of the coordinator based on the votes from participants (If all vote to commit, the decision is to commit; if any vote to abort, the decision is to abort.)
- logs of receiving acknowledgments from participants upon successfully completing the commit or abort instructions.
- any timeouts or failures encountered during communication with participants.

```angular2html
[PST-Time-Zone] 2024-04-05 12:53:25.770 [Level] INFO, [Message] PREPARE for transaction on Server[70206384-8bb0-4e78-8fd4-8f0295d12e99]: Message{messageId=8805edc1-bde4-41f1-af93-880baef6165b, type=PUT, key='6650', value='Scalable Distributed Systems', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:25.774 [Level] INFO, [Message] Server[39ddee70-e62c-402d-84bf-f872e7c1a80f] ACCEPT the transaction: Message{messageId=8805edc1-bde4-41f1-af93-880baef6165b, type=PUT, key='6650', value='Scalable Distributed Systems', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:25.778 [Level] INFO, [Message] Server[70206384-8bb0-4e78-8fd4-8f0295d12e99] ACCEPT the transaction: Message{messageId=8805edc1-bde4-41f1-af93-880baef6165b, type=PUT, key='6650', value='Scalable Distributed Systems', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:25.782 [Level] INFO, [Message] Server[fe988be1-9d9b-4aaf-a0ad-941e98886688] ACCEPT the transaction: Message{messageId=8805edc1-bde4-41f1-af93-880baef6165b, type=PUT, key='6650', value='Scalable Distributed Systems', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:25.788 [Level] INFO, [Message] Server[8d7b2084-9c45-4345-8a03-79df2717b366] ACCEPT the transaction: Message{messageId=8805edc1-bde4-41f1-af93-880baef6165b, type=PUT, key='6650', value='Scalable Distributed Systems', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:25.793 [Level] INFO, [Message] Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9] ACCEPT the transaction: Message{messageId=8805edc1-bde4-41f1-af93-880baef6165b, type=PUT, key='6650', value='Scalable Distributed Systems', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:26.779 [Level] INFO, [Message] Received ack COMMIT from Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:26.779 [Level] INFO, [Message] Synchronizing: Message{messageId=8805edc1-bde4-41f1-af93-880baef6165b, type=PUT, key='6650', value='Scalable Distributed Systems', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:26.780 [Level] INFO, [Message] Sent COMMIT to Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:26.783 [Level] INFO, [Message] Received ack COMMIT from Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:26.826 [Level] INFO, [Message] Sent COMMIT to Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:26.838 [Level] INFO, [Message] Received ack COMMIT from Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:26.839 [Level] INFO, [Message] Sent COMMIT to Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:26.843 [Level] INFO, [Message] Received ack COMMIT from Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:26.846 [Level] INFO, [Message] Sent COMMIT to Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:26.855 [Level] INFO, [Message] Received ack COMMIT from Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:53:26.857 [Level] INFO, [Message] Sent COMMIT to Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:53:28.781 [Level] INFO, [Message] All servers ACK. PUT transaction successfully synchronized.
[PST-Time-Zone] 2024-04-05 12:53:29.296 [Level] INFO, [Message] PREPARE for transaction on Server[70206384-8bb0-4e78-8fd4-8f0295d12e99]: Message{messageId=5696cea9-c53f-4a0b-b84b-1a8215d40e5d, type=PUT, key='5800', value='Algorithms', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:29.298 [Level] INFO, [Message] Server[39ddee70-e62c-402d-84bf-f872e7c1a80f] ACCEPT the transaction: Message{messageId=5696cea9-c53f-4a0b-b84b-1a8215d40e5d, type=PUT, key='5800', value='Algorithms', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:29.300 [Level] INFO, [Message] Server[70206384-8bb0-4e78-8fd4-8f0295d12e99] ACCEPT the transaction: Message{messageId=5696cea9-c53f-4a0b-b84b-1a8215d40e5d, type=PUT, key='5800', value='Algorithms', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:29.302 [Level] INFO, [Message] Server[fe988be1-9d9b-4aaf-a0ad-941e98886688] ACCEPT the transaction: Message{messageId=5696cea9-c53f-4a0b-b84b-1a8215d40e5d, type=PUT, key='5800', value='Algorithms', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:29.304 [Level] INFO, [Message] Server[8d7b2084-9c45-4345-8a03-79df2717b366] ACCEPT the transaction: Message{messageId=5696cea9-c53f-4a0b-b84b-1a8215d40e5d, type=PUT, key='5800', value='Algorithms', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:29.305 [Level] INFO, [Message] Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9] ACCEPT the transaction: Message{messageId=5696cea9-c53f-4a0b-b84b-1a8215d40e5d, type=PUT, key='5800', value='Algorithms', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:30.303 [Level] INFO, [Message] Received ack COMMIT from Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:30.303 [Level] INFO, [Message] Synchronizing: Message{messageId=5696cea9-c53f-4a0b-b84b-1a8215d40e5d, type=PUT, key='5800', value='Algorithms', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:30.304 [Level] INFO, [Message] Sent COMMIT to Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:30.305 [Level] INFO, [Message] Received ack COMMIT from Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:30.311 [Level] INFO, [Message] Sent COMMIT to Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:30.312 [Level] INFO, [Message] Received ack COMMIT from Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:30.312 [Level] INFO, [Message] Sent COMMIT to Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:30.313 [Level] INFO, [Message] Received ack COMMIT from Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:30.314 [Level] INFO, [Message] Sent COMMIT to Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:30.315 [Level] INFO, [Message] Received ack COMMIT from Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:53:30.315 [Level] INFO, [Message] Sent COMMIT to Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:53:32.307 [Level] INFO, [Message] All servers ACK. PUT transaction successfully synchronized.
[PST-Time-Zone] 2024-04-05 12:53:32.813 [Level] INFO, [Message] PREPARE for transaction on Server[70206384-8bb0-4e78-8fd4-8f0295d12e99]: Message{messageId=362c693c-e3e4-4024-9ce4-4bfc33af0250, type=PUT, key='5700', value='Computer Networking', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:32.815 [Level] INFO, [Message] Server[39ddee70-e62c-402d-84bf-f872e7c1a80f] ACCEPT the transaction: Message{messageId=362c693c-e3e4-4024-9ce4-4bfc33af0250, type=PUT, key='5700', value='Computer Networking', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:32.817 [Level] INFO, [Message] Server[70206384-8bb0-4e78-8fd4-8f0295d12e99] ACCEPT the transaction: Message{messageId=362c693c-e3e4-4024-9ce4-4bfc33af0250, type=PUT, key='5700', value='Computer Networking', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:32.818 [Level] INFO, [Message] Server[fe988be1-9d9b-4aaf-a0ad-941e98886688] ACCEPT the transaction: Message{messageId=362c693c-e3e4-4024-9ce4-4bfc33af0250, type=PUT, key='5700', value='Computer Networking', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:32.820 [Level] INFO, [Message] Server[8d7b2084-9c45-4345-8a03-79df2717b366] ACCEPT the transaction: Message{messageId=362c693c-e3e4-4024-9ce4-4bfc33af0250, type=PUT, key='5700', value='Computer Networking', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:32.822 [Level] INFO, [Message] Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9] ACCEPT the transaction: Message{messageId=362c693c-e3e4-4024-9ce4-4bfc33af0250, type=PUT, key='5700', value='Computer Networking', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:33.818 [Level] INFO, [Message] Received ack COMMIT from Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:33.818 [Level] INFO, [Message] Synchronizing: Message{messageId=362c693c-e3e4-4024-9ce4-4bfc33af0250, type=PUT, key='5700', value='Computer Networking', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:33.818 [Level] INFO, [Message] Sent COMMIT to Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:33.819 [Level] INFO, [Message] Received ack COMMIT from Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:33.822 [Level] INFO, [Message] Sent COMMIT to Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:33.822 [Level] INFO, [Message] Received ack COMMIT from Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:33.823 [Level] INFO, [Message] Sent COMMIT to Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:33.824 [Level] INFO, [Message] Received ack COMMIT from Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:33.824 [Level] INFO, [Message] Sent COMMIT to Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:33.825 [Level] INFO, [Message] Received ack COMMIT from Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:53:33.826 [Level] INFO, [Message] Sent COMMIT to Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:53:35.822 [Level] INFO, [Message] All servers ACK. PUT transaction successfully synchronized.
[PST-Time-Zone] 2024-04-05 12:53:36.327 [Level] INFO, [Message] PREPARE for transaction on Server[fe988be1-9d9b-4aaf-a0ad-941e98886688]: Message{messageId=2c18c6fc-b94c-4b6f-8478-605abacf5081, type=PUT, key='6140', value='Machine Learning', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:36.330 [Level] INFO, [Message] Server[39ddee70-e62c-402d-84bf-f872e7c1a80f] ACCEPT the transaction: Message{messageId=2c18c6fc-b94c-4b6f-8478-605abacf5081, type=PUT, key='6140', value='Machine Learning', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:36.332 [Level] INFO, [Message] Server[70206384-8bb0-4e78-8fd4-8f0295d12e99] ACCEPT the transaction: Message{messageId=2c18c6fc-b94c-4b6f-8478-605abacf5081, type=PUT, key='6140', value='Machine Learning', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:36.335 [Level] INFO, [Message] Server[fe988be1-9d9b-4aaf-a0ad-941e98886688] ACCEPT the transaction: Message{messageId=2c18c6fc-b94c-4b6f-8478-605abacf5081, type=PUT, key='6140', value='Machine Learning', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:36.337 [Level] INFO, [Message] Server[8d7b2084-9c45-4345-8a03-79df2717b366] ACCEPT the transaction: Message{messageId=2c18c6fc-b94c-4b6f-8478-605abacf5081, type=PUT, key='6140', value='Machine Learning', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:36.338 [Level] INFO, [Message] Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9] ACCEPT the transaction: Message{messageId=2c18c6fc-b94c-4b6f-8478-605abacf5081, type=PUT, key='6140', value='Machine Learning', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:37.332 [Level] INFO, [Message] Received ack COMMIT from Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:37.332 [Level] INFO, [Message] Synchronizing: Message{messageId=2c18c6fc-b94c-4b6f-8478-605abacf5081, type=PUT, key='6140', value='Machine Learning', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:37.333 [Level] INFO, [Message] Sent COMMIT to Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:37.335 [Level] INFO, [Message] Received ack COMMIT from Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:37.336 [Level] INFO, [Message] Sent COMMIT to Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:37.337 [Level] INFO, [Message] Received ack COMMIT from Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:37.348 [Level] INFO, [Message] Sent COMMIT to Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:37.349 [Level] INFO, [Message] Received ack COMMIT from Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:37.349 [Level] INFO, [Message] Sent COMMIT to Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:37.350 [Level] INFO, [Message] Received ack COMMIT from Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:53:37.350 [Level] INFO, [Message] Sent COMMIT to Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:53:39.340 [Level] INFO, [Message] All servers ACK. PUT transaction successfully synchronized.
[PST-Time-Zone] 2024-04-05 12:53:39.849 [Level] INFO, [Message] PREPARE for transaction on Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9]: Message{messageId=e0641bb6-836a-4e54-9936-f4019c1b30ab, type=PUT, key='5200', value='Database Management', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:39.850 [Level] INFO, [Message] Server[39ddee70-e62c-402d-84bf-f872e7c1a80f] ACCEPT the transaction: Message{messageId=e0641bb6-836a-4e54-9936-f4019c1b30ab, type=PUT, key='5200', value='Database Management', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:39.852 [Level] INFO, [Message] Server[70206384-8bb0-4e78-8fd4-8f0295d12e99] ACCEPT the transaction: Message{messageId=e0641bb6-836a-4e54-9936-f4019c1b30ab, type=PUT, key='5200', value='Database Management', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:39.853 [Level] INFO, [Message] Server[fe988be1-9d9b-4aaf-a0ad-941e98886688] ACCEPT the transaction: Message{messageId=e0641bb6-836a-4e54-9936-f4019c1b30ab, type=PUT, key='5200', value='Database Management', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:39.855 [Level] INFO, [Message] Server[8d7b2084-9c45-4345-8a03-79df2717b366] ACCEPT the transaction: Message{messageId=e0641bb6-836a-4e54-9936-f4019c1b30ab, type=PUT, key='5200', value='Database Management', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:39.857 [Level] INFO, [Message] Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9] ACCEPT the transaction: Message{messageId=e0641bb6-836a-4e54-9936-f4019c1b30ab, type=PUT, key='5200', value='Database Management', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:40.853 [Level] INFO, [Message] Received ack COMMIT from Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:40.853 [Level] INFO, [Message] Synchronizing: Message{messageId=e0641bb6-836a-4e54-9936-f4019c1b30ab, type=PUT, key='5200', value='Database Management', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:40.855 [Level] INFO, [Message] Sent COMMIT to Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:40.856 [Level] INFO, [Message] Received ack COMMIT from Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:40.857 [Level] INFO, [Message] Sent COMMIT to Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:40.858 [Level] INFO, [Message] Received ack COMMIT from Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:40.859 [Level] INFO, [Message] Sent COMMIT to Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:40.860 [Level] INFO, [Message] Received ack COMMIT from Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:40.861 [Level] INFO, [Message] Sent COMMIT to Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:40.862 [Level] INFO, [Message] Received ack COMMIT from Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:53:40.873 [Level] INFO, [Message] Sent COMMIT to Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:53:42.857 [Level] INFO, [Message] All servers ACK. PUT transaction successfully synchronized.
[PST-Time-Zone] 2024-04-05 12:53:43.375 [Level] INFO, [Message] PREPARE for transaction on Server[fe988be1-9d9b-4aaf-a0ad-941e98886688]: Message{messageId=e2d5bbea-0274-4628-a3df-db609359e883, type=DELETE, key='6650', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:43.376 [Level] INFO, [Message] Server[39ddee70-e62c-402d-84bf-f872e7c1a80f] ACCEPT the transaction: Message{messageId=e2d5bbea-0274-4628-a3df-db609359e883, type=DELETE, key='6650', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:43.378 [Level] INFO, [Message] Server[70206384-8bb0-4e78-8fd4-8f0295d12e99] ACCEPT the transaction: Message{messageId=e2d5bbea-0274-4628-a3df-db609359e883, type=DELETE, key='6650', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:43.379 [Level] INFO, [Message] Server[fe988be1-9d9b-4aaf-a0ad-941e98886688] ACCEPT the transaction: Message{messageId=e2d5bbea-0274-4628-a3df-db609359e883, type=DELETE, key='6650', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:43.382 [Level] INFO, [Message] Server[8d7b2084-9c45-4345-8a03-79df2717b366] ACCEPT the transaction: Message{messageId=e2d5bbea-0274-4628-a3df-db609359e883, type=DELETE, key='6650', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:43.383 [Level] INFO, [Message] Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9] ACCEPT the transaction: Message{messageId=e2d5bbea-0274-4628-a3df-db609359e883, type=DELETE, key='6650', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:44.382 [Level] INFO, [Message] Received ack COMMIT from Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:44.382 [Level] INFO, [Message] Synchronizing: Message{messageId=e2d5bbea-0274-4628-a3df-db609359e883, type=DELETE, key='6650', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:44.383 [Level] INFO, [Message] Sent COMMIT to Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:44.384 [Level] INFO, [Message] Received ack COMMIT from Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:44.385 [Level] INFO, [Message] Sent COMMIT to Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:44.388 [Level] INFO, [Message] Received ack COMMIT from Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:44.393 [Level] INFO, [Message] Sent COMMIT to Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:44.394 [Level] INFO, [Message] Received ack COMMIT from Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:44.395 [Level] INFO, [Message] Sent COMMIT to Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:44.396 [Level] INFO, [Message] Received ack COMMIT from Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:53:44.397 [Level] INFO, [Message] Sent COMMIT to Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:53:46.388 [Level] INFO, [Message] All servers ACK. DELETE transaction successfully synchronized.
[PST-Time-Zone] 2024-04-05 12:53:46.889 [Level] INFO, [Message] PREPARE for transaction on Server[70206384-8bb0-4e78-8fd4-8f0295d12e99]: Message{messageId=ebbc6a57-df0e-46dd-b400-f2ffedee3527, type=DELETE, key='5800', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:46.890 [Level] INFO, [Message] Server[39ddee70-e62c-402d-84bf-f872e7c1a80f] ACCEPT the transaction: Message{messageId=ebbc6a57-df0e-46dd-b400-f2ffedee3527, type=DELETE, key='5800', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:46.892 [Level] INFO, [Message] Server[70206384-8bb0-4e78-8fd4-8f0295d12e99] ACCEPT the transaction: Message{messageId=ebbc6a57-df0e-46dd-b400-f2ffedee3527, type=DELETE, key='5800', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:46.895 [Level] INFO, [Message] Server[fe988be1-9d9b-4aaf-a0ad-941e98886688] ACCEPT the transaction: Message{messageId=ebbc6a57-df0e-46dd-b400-f2ffedee3527, type=DELETE, key='5800', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:46.899 [Level] INFO, [Message] Server[8d7b2084-9c45-4345-8a03-79df2717b366] ACCEPT the transaction: Message{messageId=ebbc6a57-df0e-46dd-b400-f2ffedee3527, type=DELETE, key='5800', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:46.902 [Level] INFO, [Message] Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9] ACCEPT the transaction: Message{messageId=ebbc6a57-df0e-46dd-b400-f2ffedee3527, type=DELETE, key='5800', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:47.893 [Level] INFO, [Message] Received ack COMMIT from Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:47.893 [Level] INFO, [Message] Synchronizing: Message{messageId=ebbc6a57-df0e-46dd-b400-f2ffedee3527, type=DELETE, key='5800', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:47.894 [Level] INFO, [Message] Sent COMMIT to Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:47.895 [Level] INFO, [Message] Received ack COMMIT from Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:47.899 [Level] INFO, [Message] Sent COMMIT to Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:47.900 [Level] INFO, [Message] Received ack COMMIT from Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:47.901 [Level] INFO, [Message] Sent COMMIT to Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:47.902 [Level] INFO, [Message] Received ack COMMIT from Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:47.902 [Level] INFO, [Message] Sent COMMIT to Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:47.903 [Level] INFO, [Message] Received ack COMMIT from Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:53:47.904 [Level] INFO, [Message] Sent COMMIT to Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:53:49.897 [Level] INFO, [Message] All servers ACK. DELETE transaction successfully synchronized.
[PST-Time-Zone] 2024-04-05 12:53:50.405 [Level] INFO, [Message] PREPARE for transaction on Server[70206384-8bb0-4e78-8fd4-8f0295d12e99]: Message{messageId=b18e83d5-a5a5-460a-a158-918fffec588c, type=DELETE, key='5700', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:50.407 [Level] INFO, [Message] Server[39ddee70-e62c-402d-84bf-f872e7c1a80f] ACCEPT the transaction: Message{messageId=b18e83d5-a5a5-460a-a158-918fffec588c, type=DELETE, key='5700', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:50.409 [Level] INFO, [Message] Server[70206384-8bb0-4e78-8fd4-8f0295d12e99] ACCEPT the transaction: Message{messageId=b18e83d5-a5a5-460a-a158-918fffec588c, type=DELETE, key='5700', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:50.411 [Level] INFO, [Message] Server[fe988be1-9d9b-4aaf-a0ad-941e98886688] ACCEPT the transaction: Message{messageId=b18e83d5-a5a5-460a-a158-918fffec588c, type=DELETE, key='5700', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:50.412 [Level] INFO, [Message] Server[8d7b2084-9c45-4345-8a03-79df2717b366] ACCEPT the transaction: Message{messageId=b18e83d5-a5a5-460a-a158-918fffec588c, type=DELETE, key='5700', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:50.414 [Level] INFO, [Message] Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9] ACCEPT the transaction: Message{messageId=b18e83d5-a5a5-460a-a158-918fffec588c, type=DELETE, key='5700', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:51.413 [Level] INFO, [Message] Received ack COMMIT from Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:51.413 [Level] INFO, [Message] Synchronizing: Message{messageId=b18e83d5-a5a5-460a-a158-918fffec588c, type=DELETE, key='5700', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:51.414 [Level] INFO, [Message] Sent COMMIT to Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:51.415 [Level] INFO, [Message] Received ack COMMIT from Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:51.421 [Level] INFO, [Message] Sent COMMIT to Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:51.422 [Level] INFO, [Message] Received ack COMMIT from Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:51.423 [Level] INFO, [Message] Sent COMMIT to Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:51.424 [Level] INFO, [Message] Received ack COMMIT from Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:51.424 [Level] INFO, [Message] Sent COMMIT to Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:51.425 [Level] INFO, [Message] Received ack COMMIT from Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:53:51.426 [Level] INFO, [Message] Sent COMMIT to Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:53:53.417 [Level] INFO, [Message] All servers ACK. DELETE transaction successfully synchronized.
[PST-Time-Zone] 2024-04-05 12:53:53.922 [Level] INFO, [Message] PREPARE for transaction on Server[70206384-8bb0-4e78-8fd4-8f0295d12e99]: Message{messageId=ada31cae-faf9-402d-b05b-3870fab0a27e, type=DELETE, key='6140', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:53.924 [Level] INFO, [Message] Server[39ddee70-e62c-402d-84bf-f872e7c1a80f] ACCEPT the transaction: Message{messageId=ada31cae-faf9-402d-b05b-3870fab0a27e, type=DELETE, key='6140', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:53.925 [Level] INFO, [Message] Server[70206384-8bb0-4e78-8fd4-8f0295d12e99] ACCEPT the transaction: Message{messageId=ada31cae-faf9-402d-b05b-3870fab0a27e, type=DELETE, key='6140', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:53.927 [Level] INFO, [Message] Server[fe988be1-9d9b-4aaf-a0ad-941e98886688] ACCEPT the transaction: Message{messageId=ada31cae-faf9-402d-b05b-3870fab0a27e, type=DELETE, key='6140', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:53.929 [Level] INFO, [Message] Server[8d7b2084-9c45-4345-8a03-79df2717b366] ACCEPT the transaction: Message{messageId=ada31cae-faf9-402d-b05b-3870fab0a27e, type=DELETE, key='6140', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:53.931 [Level] INFO, [Message] Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9] ACCEPT the transaction: Message{messageId=ada31cae-faf9-402d-b05b-3870fab0a27e, type=DELETE, key='6140', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:54.927 [Level] INFO, [Message] Received ack COMMIT from Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:54.928 [Level] INFO, [Message] Synchronizing: Message{messageId=ada31cae-faf9-402d-b05b-3870fab0a27e, type=DELETE, key='6140', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:54.928 [Level] INFO, [Message] Sent COMMIT to Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:54.930 [Level] INFO, [Message] Received ack COMMIT from Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:54.934 [Level] INFO, [Message] Sent COMMIT to Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:54.935 [Level] INFO, [Message] Received ack COMMIT from Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:54.936 [Level] INFO, [Message] Sent COMMIT to Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:54.937 [Level] INFO, [Message] Received ack COMMIT from Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:54.938 [Level] INFO, [Message] Sent COMMIT to Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:54.938 [Level] INFO, [Message] Received ack COMMIT from Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:53:54.939 [Level] INFO, [Message] Sent COMMIT to Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:53:56.931 [Level] INFO, [Message] All servers ACK. DELETE transaction successfully synchronized.
[PST-Time-Zone] 2024-04-05 12:53:57.435 [Level] INFO, [Message] PREPARE for transaction on Server[39ddee70-e62c-402d-84bf-f872e7c1a80f]: Message{messageId=17179d0c-3848-46e4-bee2-62200a836fac, type=DELETE, key='5200', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:57.438 [Level] INFO, [Message] Server[39ddee70-e62c-402d-84bf-f872e7c1a80f] ACCEPT the transaction: Message{messageId=17179d0c-3848-46e4-bee2-62200a836fac, type=DELETE, key='5200', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:57.439 [Level] INFO, [Message] Server[70206384-8bb0-4e78-8fd4-8f0295d12e99] ACCEPT the transaction: Message{messageId=17179d0c-3848-46e4-bee2-62200a836fac, type=DELETE, key='5200', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:57.441 [Level] INFO, [Message] Server[fe988be1-9d9b-4aaf-a0ad-941e98886688] ACCEPT the transaction: Message{messageId=17179d0c-3848-46e4-bee2-62200a836fac, type=DELETE, key='5200', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:57.442 [Level] INFO, [Message] Server[8d7b2084-9c45-4345-8a03-79df2717b366] ACCEPT the transaction: Message{messageId=17179d0c-3848-46e4-bee2-62200a836fac, type=DELETE, key='5200', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:57.443 [Level] INFO, [Message] Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9] ACCEPT the transaction: Message{messageId=17179d0c-3848-46e4-bee2-62200a836fac, type=DELETE, key='5200', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:53:58.444 [Level] INFO, [Message] Received ack COMMIT from Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:58.444 [Level] INFO, [Message] Synchronizing: Message{messageId=17179d0c-3848-46e4-bee2-62200a836fac, type=DELETE, key='5200', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:58.456 [Level] INFO, [Message] Sent COMMIT to Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:53:58.457 [Level] INFO, [Message] Received ack COMMIT from Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:58.457 [Level] INFO, [Message] Sent COMMIT to Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:53:58.458 [Level] INFO, [Message] Received ack COMMIT from Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:58.458 [Level] INFO, [Message] Sent COMMIT to Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:53:58.459 [Level] INFO, [Message] Received ack COMMIT from Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:58.460 [Level] INFO, [Message] Sent COMMIT to Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:53:58.460 [Level] INFO, [Message] Received ack COMMIT from Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:53:58.461 [Level] INFO, [Message] Sent COMMIT to Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:54:00.447 [Level] INFO, [Message] All servers ACK. DELETE transaction successfully synchronized.
[PST-Time-Zone] 2024-04-05 12:54:00.953 [Level] INFO, [Message] PREPARE for transaction on Server[70206384-8bb0-4e78-8fd4-8f0295d12e99]: Message{messageId=9b4acb6d-88d5-4380-8146-b78e2d51a00f, type=PUT, key='6650', value='Scalable Distributed Systems', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:00.955 [Level] INFO, [Message] Server[39ddee70-e62c-402d-84bf-f872e7c1a80f] ACCEPT the transaction: Message{messageId=9b4acb6d-88d5-4380-8146-b78e2d51a00f, type=PUT, key='6650', value='Scalable Distributed Systems', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:00.957 [Level] INFO, [Message] Server[70206384-8bb0-4e78-8fd4-8f0295d12e99] ACCEPT the transaction: Message{messageId=9b4acb6d-88d5-4380-8146-b78e2d51a00f, type=PUT, key='6650', value='Scalable Distributed Systems', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:00.958 [Level] INFO, [Message] Server[fe988be1-9d9b-4aaf-a0ad-941e98886688] ACCEPT the transaction: Message{messageId=9b4acb6d-88d5-4380-8146-b78e2d51a00f, type=PUT, key='6650', value='Scalable Distributed Systems', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:00.960 [Level] INFO, [Message] Server[8d7b2084-9c45-4345-8a03-79df2717b366] ACCEPT the transaction: Message{messageId=9b4acb6d-88d5-4380-8146-b78e2d51a00f, type=PUT, key='6650', value='Scalable Distributed Systems', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:00.961 [Level] INFO, [Message] Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9] ACCEPT the transaction: Message{messageId=9b4acb6d-88d5-4380-8146-b78e2d51a00f, type=PUT, key='6650', value='Scalable Distributed Systems', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:01.959 [Level] INFO, [Message] Received ack COMMIT from Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:54:01.959 [Level] INFO, [Message] Synchronizing: Message{messageId=9b4acb6d-88d5-4380-8146-b78e2d51a00f, type=PUT, key='6650', value='Scalable Distributed Systems', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:01.960 [Level] INFO, [Message] Sent COMMIT to Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:54:01.961 [Level] INFO, [Message] Received ack COMMIT from Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:54:01.967 [Level] INFO, [Message] Sent COMMIT to Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:54:01.968 [Level] INFO, [Message] Received ack COMMIT from Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:54:01.969 [Level] INFO, [Message] Sent COMMIT to Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:54:01.969 [Level] INFO, [Message] Received ack COMMIT from Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:54:01.970 [Level] INFO, [Message] Sent COMMIT to Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:54:01.971 [Level] INFO, [Message] Received ack COMMIT from Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:54:01.971 [Level] INFO, [Message] Sent COMMIT to Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:54:03.961 [Level] INFO, [Message] All servers ACK. PUT transaction successfully synchronized.
[PST-Time-Zone] 2024-04-05 12:54:04.465 [Level] INFO, [Message] PREPARE for transaction on Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9]: Message{messageId=91000bd8-291c-402c-bbb1-c1c45e951b91, type=PUT, key='5800', value='Algorithms', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:04.467 [Level] INFO, [Message] Server[39ddee70-e62c-402d-84bf-f872e7c1a80f] ACCEPT the transaction: Message{messageId=91000bd8-291c-402c-bbb1-c1c45e951b91, type=PUT, key='5800', value='Algorithms', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:04.468 [Level] INFO, [Message] Server[70206384-8bb0-4e78-8fd4-8f0295d12e99] ACCEPT the transaction: Message{messageId=91000bd8-291c-402c-bbb1-c1c45e951b91, type=PUT, key='5800', value='Algorithms', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:04.470 [Level] INFO, [Message] Server[fe988be1-9d9b-4aaf-a0ad-941e98886688] ACCEPT the transaction: Message{messageId=91000bd8-291c-402c-bbb1-c1c45e951b91, type=PUT, key='5800', value='Algorithms', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:04.472 [Level] INFO, [Message] Server[8d7b2084-9c45-4345-8a03-79df2717b366] ACCEPT the transaction: Message{messageId=91000bd8-291c-402c-bbb1-c1c45e951b91, type=PUT, key='5800', value='Algorithms', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:04.475 [Level] INFO, [Message] Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9] ACCEPT the transaction: Message{messageId=91000bd8-291c-402c-bbb1-c1c45e951b91, type=PUT, key='5800', value='Algorithms', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:05.472 [Level] INFO, [Message] Received ack COMMIT from Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:54:05.472 [Level] INFO, [Message] Synchronizing: Message{messageId=91000bd8-291c-402c-bbb1-c1c45e951b91, type=PUT, key='5800', value='Algorithms', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:05.473 [Level] INFO, [Message] Sent COMMIT to Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:54:05.474 [Level] INFO, [Message] Received ack COMMIT from Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:54:05.474 [Level] INFO, [Message] Sent COMMIT to Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:54:05.475 [Level] INFO, [Message] Received ack COMMIT from Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:54:05.476 [Level] INFO, [Message] Sent COMMIT to Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:54:05.477 [Level] INFO, [Message] Received ack COMMIT from Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:54:05.477 [Level] INFO, [Message] Sent COMMIT to Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:54:05.478 [Level] INFO, [Message] Received ack COMMIT from Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:54:05.481 [Level] INFO, [Message] Sent COMMIT to Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:54:07.476 [Level] INFO, [Message] All servers ACK. PUT transaction successfully synchronized.
[PST-Time-Zone] 2024-04-05 12:54:07.981 [Level] INFO, [Message] PREPARE for transaction on Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9]: Message{messageId=7bd90546-3c51-4de8-a92a-7223621816f0, type=PUT, key='5700', value='Computer Networking', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:07.983 [Level] INFO, [Message] Server[39ddee70-e62c-402d-84bf-f872e7c1a80f] ACCEPT the transaction: Message{messageId=7bd90546-3c51-4de8-a92a-7223621816f0, type=PUT, key='5700', value='Computer Networking', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:07.985 [Level] INFO, [Message] Server[70206384-8bb0-4e78-8fd4-8f0295d12e99] ACCEPT the transaction: Message{messageId=7bd90546-3c51-4de8-a92a-7223621816f0, type=PUT, key='5700', value='Computer Networking', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:07.986 [Level] INFO, [Message] Server[fe988be1-9d9b-4aaf-a0ad-941e98886688] ACCEPT the transaction: Message{messageId=7bd90546-3c51-4de8-a92a-7223621816f0, type=PUT, key='5700', value='Computer Networking', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:07.988 [Level] INFO, [Message] Server[8d7b2084-9c45-4345-8a03-79df2717b366] ACCEPT the transaction: Message{messageId=7bd90546-3c51-4de8-a92a-7223621816f0, type=PUT, key='5700', value='Computer Networking', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:07.989 [Level] INFO, [Message] Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9] ACCEPT the transaction: Message{messageId=7bd90546-3c51-4de8-a92a-7223621816f0, type=PUT, key='5700', value='Computer Networking', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:08.989 [Level] INFO, [Message] Received ack COMMIT from Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:54:08.989 [Level] INFO, [Message] Synchronizing: Message{messageId=7bd90546-3c51-4de8-a92a-7223621816f0, type=PUT, key='5700', value='Computer Networking', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:08.990 [Level] INFO, [Message] Sent COMMIT to Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:54:08.991 [Level] INFO, [Message] Received ack COMMIT from Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:54:08.992 [Level] INFO, [Message] Sent COMMIT to Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:54:08.993 [Level] INFO, [Message] Received ack COMMIT from Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:54:08.994 [Level] INFO, [Message] Sent COMMIT to Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:54:08.995 [Level] INFO, [Message] Received ack COMMIT from Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:54:08.996 [Level] INFO, [Message] Sent COMMIT to Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:54:08.997 [Level] INFO, [Message] Received ack COMMIT from Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:54:09.001 [Level] INFO, [Message] Sent COMMIT to Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:54:10.991 [Level] INFO, [Message] All servers ACK. PUT transaction successfully synchronized.
[PST-Time-Zone] 2024-04-05 12:54:11.492 [Level] INFO, [Message] PREPARE for transaction on Server[39ddee70-e62c-402d-84bf-f872e7c1a80f]: Message{messageId=2f582f66-3616-48ca-a2f8-602955dbcbf7, type=PUT, key='6140', value='Machine Learning', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:11.493 [Level] INFO, [Message] Server[39ddee70-e62c-402d-84bf-f872e7c1a80f] ACCEPT the transaction: Message{messageId=2f582f66-3616-48ca-a2f8-602955dbcbf7, type=PUT, key='6140', value='Machine Learning', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:11.495 [Level] INFO, [Message] Server[70206384-8bb0-4e78-8fd4-8f0295d12e99] ACCEPT the transaction: Message{messageId=2f582f66-3616-48ca-a2f8-602955dbcbf7, type=PUT, key='6140', value='Machine Learning', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:11.496 [Level] INFO, [Message] Server[fe988be1-9d9b-4aaf-a0ad-941e98886688] ACCEPT the transaction: Message{messageId=2f582f66-3616-48ca-a2f8-602955dbcbf7, type=PUT, key='6140', value='Machine Learning', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:11.497 [Level] INFO, [Message] Server[8d7b2084-9c45-4345-8a03-79df2717b366] ACCEPT the transaction: Message{messageId=2f582f66-3616-48ca-a2f8-602955dbcbf7, type=PUT, key='6140', value='Machine Learning', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:11.499 [Level] INFO, [Message] Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9] ACCEPT the transaction: Message{messageId=2f582f66-3616-48ca-a2f8-602955dbcbf7, type=PUT, key='6140', value='Machine Learning', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:12.496 [Level] INFO, [Message] Received ack COMMIT from Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:54:12.496 [Level] INFO, [Message] Synchronizing: Message{messageId=2f582f66-3616-48ca-a2f8-602955dbcbf7, type=PUT, key='6140', value='Machine Learning', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:12.500 [Level] INFO, [Message] Sent COMMIT to Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:54:12.501 [Level] INFO, [Message] Received ack COMMIT from Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:54:12.502 [Level] INFO, [Message] Sent COMMIT to Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:54:12.503 [Level] INFO, [Message] Received ack COMMIT from Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:54:12.503 [Level] INFO, [Message] Sent COMMIT to Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:54:12.504 [Level] INFO, [Message] Received ack COMMIT from Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:54:12.505 [Level] INFO, [Message] Sent COMMIT to Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:54:12.506 [Level] INFO, [Message] Received ack COMMIT from Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:54:12.507 [Level] INFO, [Message] Sent COMMIT to Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:54:14.499 [Level] INFO, [Message] All servers ACK. PUT transaction successfully synchronized.
[PST-Time-Zone] 2024-04-05 12:54:15.015 [Level] INFO, [Message] PREPARE for transaction on Server[fe988be1-9d9b-4aaf-a0ad-941e98886688]: Message{messageId=21fbe37b-209c-43c3-b626-40a08236e2cf, type=PUT, key='5200', value='Database Management', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:15.016 [Level] INFO, [Message] Server[39ddee70-e62c-402d-84bf-f872e7c1a80f] ACCEPT the transaction: Message{messageId=21fbe37b-209c-43c3-b626-40a08236e2cf, type=PUT, key='5200', value='Database Management', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:15.017 [Level] INFO, [Message] Server[70206384-8bb0-4e78-8fd4-8f0295d12e99] ACCEPT the transaction: Message{messageId=21fbe37b-209c-43c3-b626-40a08236e2cf, type=PUT, key='5200', value='Database Management', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:15.019 [Level] INFO, [Message] Server[fe988be1-9d9b-4aaf-a0ad-941e98886688] ACCEPT the transaction: Message{messageId=21fbe37b-209c-43c3-b626-40a08236e2cf, type=PUT, key='5200', value='Database Management', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:15.021 [Level] INFO, [Message] Server[8d7b2084-9c45-4345-8a03-79df2717b366] ACCEPT the transaction: Message{messageId=21fbe37b-209c-43c3-b626-40a08236e2cf, type=PUT, key='5200', value='Database Management', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:15.022 [Level] INFO, [Message] Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9] ACCEPT the transaction: Message{messageId=21fbe37b-209c-43c3-b626-40a08236e2cf, type=PUT, key='5200', value='Database Management', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}.
[PST-Time-Zone] 2024-04-05 12:54:16.021 [Level] INFO, [Message] Received ack COMMIT from Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:54:16.021 [Level] INFO, [Message] Synchronizing: Message{messageId=21fbe37b-209c-43c3-b626-40a08236e2cf, type=PUT, key='5200', value='Database Management', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:16.022 [Level] INFO, [Message] Sent COMMIT to Server[39ddee70-e62c-402d-84bf-f872e7c1a80f].
[PST-Time-Zone] 2024-04-05 12:54:16.023 [Level] INFO, [Message] Received ack COMMIT from Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:54:16.024 [Level] INFO, [Message] Sent COMMIT to Server[70206384-8bb0-4e78-8fd4-8f0295d12e99].
[PST-Time-Zone] 2024-04-05 12:54:16.025 [Level] INFO, [Message] Received ack COMMIT from Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:54:16.032 [Level] INFO, [Message] Sent COMMIT to Server[fe988be1-9d9b-4aaf-a0ad-941e98886688].
[PST-Time-Zone] 2024-04-05 12:54:16.033 [Level] INFO, [Message] Received ack COMMIT from Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:54:16.033 [Level] INFO, [Message] Sent COMMIT to Server[8d7b2084-9c45-4345-8a03-79df2717b366].
[PST-Time-Zone] 2024-04-05 12:54:16.034 [Level] INFO, [Message] Received ack COMMIT from Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:54:16.034 [Level] INFO, [Message] Sent COMMIT to Server[04b5a2f4-df87-4234-be9d-3b3fc85636b9].
[PST-Time-Zone] 2024-04-05 12:54:18.025 [Level] INFO, [Message] All servers ACK. PUT transaction successfully synchronized.
```

❗️ You can also check the logs on the `server` side as each participant server will log information of their part in the transaction so they can recover their state in case of failure.
For example, `server[0]` at port `4001` has a log as below. It includes information like:
- when it receives a request to prepare for a transaction from the coordinator.
- its decision to commit or abort based on the current state.
- final decision (commit or abort) received from the coordinator.
- his actions  to commit or abort the transaction.
- when he sends an acknowledgment back to the coordinator after completing the commit or abort actions.

```angular2html
[PST-Time-Zone] 2024-04-05 12:53:25.772 [Level] INFO, [Message] PREPARE: Message{messageId=8805edc1-bde4-41f1-af93-880baef6165b, type=PUT, key='6650', value='Scalable Distributed Systems', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:25.772 [Level] INFO, [Message] Vote for COMMIT
[PST-Time-Zone] 2024-04-05 12:53:26.779 [Level] INFO, [Message] COMMITTED: Message{messageId=8805edc1-bde4-41f1-af93-880baef6165b, type=PUT, key='6650', value='Scalable Distributed Systems', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:26.780 [Level] INFO, [Message] Added/Updated pair <key=6650, value=Scalable Distributed Systems>.
[PST-Time-Zone] 2024-04-05 12:53:29.297 [Level] INFO, [Message] PREPARE: Message{messageId=5696cea9-c53f-4a0b-b84b-1a8215d40e5d, type=PUT, key='5800', value='Algorithms', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:29.297 [Level] INFO, [Message] Vote for COMMIT
[PST-Time-Zone] 2024-04-05 12:53:30.304 [Level] INFO, [Message] COMMITTED: Message{messageId=5696cea9-c53f-4a0b-b84b-1a8215d40e5d, type=PUT, key='5800', value='Algorithms', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:30.304 [Level] INFO, [Message] Added/Updated pair <key=5800, value=Algorithms>.
[PST-Time-Zone] 2024-04-05 12:53:32.814 [Level] INFO, [Message] PREPARE: Message{messageId=362c693c-e3e4-4024-9ce4-4bfc33af0250, type=PUT, key='5700', value='Computer Networking', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:32.814 [Level] INFO, [Message] Vote for COMMIT
[PST-Time-Zone] 2024-04-05 12:53:33.818 [Level] INFO, [Message] COMMITTED: Message{messageId=362c693c-e3e4-4024-9ce4-4bfc33af0250, type=PUT, key='5700', value='Computer Networking', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:33.818 [Level] INFO, [Message] Added/Updated pair <key=5700, value=Computer Networking>.
[PST-Time-Zone] 2024-04-05 12:53:36.328 [Level] INFO, [Message] PREPARE: Message{messageId=2c18c6fc-b94c-4b6f-8478-605abacf5081, type=PUT, key='6140', value='Machine Learning', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:36.328 [Level] INFO, [Message] Vote for COMMIT
[PST-Time-Zone] 2024-04-05 12:53:37.333 [Level] INFO, [Message] COMMITTED: Message{messageId=2c18c6fc-b94c-4b6f-8478-605abacf5081, type=PUT, key='6140', value='Machine Learning', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:37.333 [Level] INFO, [Message] Added/Updated pair <key=6140, value=Machine Learning>.
[PST-Time-Zone] 2024-04-05 12:53:39.850 [Level] INFO, [Message] PREPARE: Message{messageId=e0641bb6-836a-4e54-9936-f4019c1b30ab, type=PUT, key='5200', value='Database Management', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:39.850 [Level] INFO, [Message] Vote for COMMIT
[PST-Time-Zone] 2024-04-05 12:53:40.853 [Level] INFO, [Message] COMMITTED: Message{messageId=e0641bb6-836a-4e54-9936-f4019c1b30ab, type=PUT, key='5200', value='Database Management', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:40.853 [Level] INFO, [Message] Added/Updated pair <key=5200, value=Database Management>.
[PST-Time-Zone] 2024-04-05 12:53:43.366 [Level] INFO, [Message] Received GET request from client[75370cb1-7729-4e40-9dd1-eecd930fd384] with [key=5800]
[PST-Time-Zone] 2024-04-05 12:53:43.366 [Level] INFO, [Message] Sent response for GET request to client[75370cb1-7729-4e40-9dd1-eecd930fd384] with [key=5800] [value=Algorithms]
[PST-Time-Zone] 2024-04-05 12:53:43.370 [Level] INFO, [Message] Received GET request from client[75370cb1-7729-4e40-9dd1-eecd930fd384] with [key=6140]
[PST-Time-Zone] 2024-04-05 12:53:43.370 [Level] INFO, [Message] Sent response for GET request to client[75370cb1-7729-4e40-9dd1-eecd930fd384] with [key=6140] [value=Machine Learning]
[PST-Time-Zone] 2024-04-05 12:53:43.376 [Level] INFO, [Message] PREPARE: Message{messageId=e2d5bbea-0274-4628-a3df-db609359e883, type=DELETE, key='6650', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:43.376 [Level] INFO, [Message] Vote for COMMIT
[PST-Time-Zone] 2024-04-05 12:53:44.383 [Level] INFO, [Message] COMMITTED: Message{messageId=e2d5bbea-0274-4628-a3df-db609359e883, type=DELETE, key='6650', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:44.383 [Level] INFO, [Message] Deleted key=6650.
[PST-Time-Zone] 2024-04-05 12:53:46.889 [Level] INFO, [Message] PREPARE: Message{messageId=ebbc6a57-df0e-46dd-b400-f2ffedee3527, type=DELETE, key='5800', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:46.890 [Level] INFO, [Message] Vote for COMMIT
[PST-Time-Zone] 2024-04-05 12:53:47.893 [Level] INFO, [Message] COMMITTED: Message{messageId=ebbc6a57-df0e-46dd-b400-f2ffedee3527, type=DELETE, key='5800', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:47.894 [Level] INFO, [Message] Deleted key=5800.
[PST-Time-Zone] 2024-04-05 12:53:50.406 [Level] INFO, [Message] PREPARE: Message{messageId=b18e83d5-a5a5-460a-a158-918fffec588c, type=DELETE, key='5700', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:50.407 [Level] INFO, [Message] Vote for COMMIT
[PST-Time-Zone] 2024-04-05 12:53:51.414 [Level] INFO, [Message] COMMITTED: Message{messageId=b18e83d5-a5a5-460a-a158-918fffec588c, type=DELETE, key='5700', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:51.414 [Level] INFO, [Message] Deleted key=5700.
[PST-Time-Zone] 2024-04-05 12:53:53.923 [Level] INFO, [Message] PREPARE: Message{messageId=ada31cae-faf9-402d-b05b-3870fab0a27e, type=DELETE, key='6140', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:53.924 [Level] INFO, [Message] Vote for COMMIT
[PST-Time-Zone] 2024-04-05 12:53:54.928 [Level] INFO, [Message] COMMITTED: Message{messageId=ada31cae-faf9-402d-b05b-3870fab0a27e, type=DELETE, key='6140', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:54.928 [Level] INFO, [Message] Deleted key=6140.
[PST-Time-Zone] 2024-04-05 12:53:57.435 [Level] INFO, [Message] Received DELETE request from client[75370cb1-7729-4e40-9dd1-eecd930fd384] with [key=5200]
[PST-Time-Zone] 2024-04-05 12:53:57.436 [Level] INFO, [Message] PREPARE: Message{messageId=17179d0c-3848-46e4-bee2-62200a836fac, type=DELETE, key='5200', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:57.436 [Level] INFO, [Message] Vote for COMMIT
[PST-Time-Zone] 2024-04-05 12:53:58.444 [Level] INFO, [Message] COMMITTED: Message{messageId=17179d0c-3848-46e4-bee2-62200a836fac, type=DELETE, key='5200', value='', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:53:58.444 [Level] INFO, [Message] Deleted key=5200.
[PST-Time-Zone] 2024-04-05 12:53:58.456 [Level] INFO, [Message] Sent response: [key=5200] has been successfully deleted.
[PST-Time-Zone] 2024-04-05 12:54:00.954 [Level] INFO, [Message] PREPARE: Message{messageId=9b4acb6d-88d5-4380-8146-b78e2d51a00f, type=PUT, key='6650', value='Scalable Distributed Systems', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:00.954 [Level] INFO, [Message] Vote for COMMIT
[PST-Time-Zone] 2024-04-05 12:54:01.959 [Level] INFO, [Message] COMMITTED: Message{messageId=9b4acb6d-88d5-4380-8146-b78e2d51a00f, type=PUT, key='6650', value='Scalable Distributed Systems', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:01.960 [Level] INFO, [Message] Added/Updated pair <key=6650, value=Scalable Distributed Systems>.
[PST-Time-Zone] 2024-04-05 12:54:04.466 [Level] INFO, [Message] PREPARE: Message{messageId=91000bd8-291c-402c-bbb1-c1c45e951b91, type=PUT, key='5800', value='Algorithms', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:04.466 [Level] INFO, [Message] Vote for COMMIT
[PST-Time-Zone] 2024-04-05 12:54:05.472 [Level] INFO, [Message] COMMITTED: Message{messageId=91000bd8-291c-402c-bbb1-c1c45e951b91, type=PUT, key='5800', value='Algorithms', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:05.472 [Level] INFO, [Message] Added/Updated pair <key=5800, value=Algorithms>.
[PST-Time-Zone] 2024-04-05 12:54:07.982 [Level] INFO, [Message] PREPARE: Message{messageId=7bd90546-3c51-4de8-a92a-7223621816f0, type=PUT, key='5700', value='Computer Networking', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:07.982 [Level] INFO, [Message] Vote for COMMIT
[PST-Time-Zone] 2024-04-05 12:54:08.990 [Level] INFO, [Message] COMMITTED: Message{messageId=7bd90546-3c51-4de8-a92a-7223621816f0, type=PUT, key='5700', value='Computer Networking', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:08.990 [Level] INFO, [Message] Added/Updated pair <key=5700, value=Computer Networking>.
[PST-Time-Zone] 2024-04-05 12:54:11.491 [Level] INFO, [Message] Received PUT request from client[75370cb1-7729-4e40-9dd1-eecd930fd384] with <key=6140, value=Machine Learning>
[PST-Time-Zone] 2024-04-05 12:54:11.493 [Level] INFO, [Message] PREPARE: Message{messageId=2f582f66-3616-48ca-a2f8-602955dbcbf7, type=PUT, key='6140', value='Machine Learning', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:11.493 [Level] INFO, [Message] Vote for COMMIT
[PST-Time-Zone] 2024-04-05 12:54:12.496 [Level] INFO, [Message] COMMITTED: Message{messageId=2f582f66-3616-48ca-a2f8-602955dbcbf7, type=PUT, key='6140', value='Machine Learning', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:12.496 [Level] INFO, [Message] Added/Updated pair <key=6140, value=Machine Learning>.
[PST-Time-Zone] 2024-04-05 12:54:12.500 [Level] INFO, [Message] Sent response: <key=6140, value=Machine Learning> has been successfully stored.
[PST-Time-Zone] 2024-04-05 12:54:15.015 [Level] INFO, [Message] PREPARE: Message{messageId=21fbe37b-209c-43c3-b626-40a08236e2cf, type=PUT, key='5200', value='Database Management', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:15.015 [Level] INFO, [Message] Vote for COMMIT
[PST-Time-Zone] 2024-04-05 12:54:16.022 [Level] INFO, [Message] COMMITTED: Message{messageId=21fbe37b-209c-43c3-b626-40a08236e2cf, type=PUT, key='5200', value='Database Management', clientId=75370cb1-7729-4e40-9dd1-eecd930fd384}
[PST-Time-Zone] 2024-04-05 12:54:16.022 [Level] INFO, [Message] Added/Updated pair <key=5200, value=Database Management>.
```

#### V. Interact with any replica server and perform three basic operations.

1. Once the preloading requests have completed, you will see message as below to guide you how to interact with the server. **You get to choose a number from 0-4 to interact with any replica server.**

```angular2html
5 servers are now available: [0, 1, 2, 3, 4]
----------------------------------------
Want to INTERACT with Server?
Enter a number from [0, 1, 2, 3, 4] to interact with any server.
If you want to exit, just enter [exit].
-----------------------------------------
Please enter a server number for the interaction: 
```

2. For example, if you want to interact with server[1], just enter `1` and you will see messages as below to guide you how to enter the request. This part is the same as Project 2.

```angular2html
Please enter a server number for the interaction: 
1
----------------------------------------
How to Enter Your Request:
Enter 1: GET the value by a certain key
Enter 2: ADD or UPDATE a key-value pair
Enter 3: DELETE an existing key-value pair
Enter 4: EXIT this program
-----------------------------------------
Please enter a number for your request: 
```

3. If you want to add a key-value pair as a `PUT` operation, just enter `2` and follow the instructions to put the key-value pair. The log messages will indicate whether your operation is successful as below. This part is also the same as Project 2.

```angular2html
Please enter a number for your request: 
2
Enter the key:
6650
Enter the value:
distributed systems
[PST-Time-Zone] 2024-04-04 15:34:53.022 [Level] INFO, [Message] Sent PUT request for <key=6650, value=distributed systems> to server[1]
[PST-Time-Zone] 2024-04-04 15:34:54.027 [Level] INFO, [Message] Received response from server[1]: <key=6650, value=distributed systems> has been successfully stored.
```

4. You will see new logs on the `coordinator` terminal about how coordinator coordinated this operation in the 2PC protocol.

```angular2html
[PST-Time-Zone] 2024-04-04 15:34:52.822 [Level] INFO, [Message] PREPARE for transaction on Server[b7375e55-32ed-44b2-8da2-25318dde55eb]: Message{messageId=98422aa1-7444-4786-b22c-0b83d8e454e8, type=PUT, key='6650', value='distributed systems', clientId=868c2e48-7034-4973-8a92-28e3a88d395a}
[PST-Time-Zone] 2024-04-04 15:34:52.846 [Level] INFO, [Message] Server[b7375e55-32ed-44b2-8da2-25318dde55eb] ACCEPT the transaction: Message{messageId=98422aa1-7444-4786-b22c-0b83d8e454e8, type=PUT, key='6650', value='distributed systems', clientId=868c2e48-7034-4973-8a92-28e3a88d395a}.
[PST-Time-Zone] 2024-04-04 15:34:52.886 [Level] INFO, [Message] Server[654c7361-d467-442a-b108-ea328b51dd54] ACCEPT the transaction: Message{messageId=98422aa1-7444-4786-b22c-0b83d8e454e8, type=PUT, key='6650', value='distributed systems', clientId=868c2e48-7034-4973-8a92-28e3a88d395a}.
[PST-Time-Zone] 2024-04-04 15:34:52.933 [Level] INFO, [Message] Server[01dbf1aa-0b67-4fad-9428-4238291b2dff] ACCEPT the transaction: Message{messageId=98422aa1-7444-4786-b22c-0b83d8e454e8, type=PUT, key='6650', value='distributed systems', clientId=868c2e48-7034-4973-8a92-28e3a88d395a}.
[PST-Time-Zone] 2024-04-04 15:34:52.956 [Level] INFO, [Message] Server[c241ce68-ed9e-49c3-89a3-3a7c93eac1d3] ACCEPT the transaction: Message{messageId=98422aa1-7444-4786-b22c-0b83d8e454e8, type=PUT, key='6650', value='distributed systems', clientId=868c2e48-7034-4973-8a92-28e3a88d395a}.
[PST-Time-Zone] 2024-04-04 15:34:53.005 [Level] INFO, [Message] Server[9517f3be-027f-4f04-a650-3cc93c20664f] ACCEPT the transaction: Message{messageId=98422aa1-7444-4786-b22c-0b83d8e454e8, type=PUT, key='6650', value='distributed systems', clientId=868c2e48-7034-4973-8a92-28e3a88d395a}.
[PST-Time-Zone] 2024-04-04 15:34:53.858 [Level] INFO, [Message] Received ack COMMIT from Server[b7375e55-32ed-44b2-8da2-25318dde55eb].
[PST-Time-Zone] 2024-04-04 15:34:53.858 [Level] INFO, [Message]  synchronization: Message{messageId=98422aa1-7444-4786-b22c-0b83d8e454e8, type=PUT, key='6650', value='distributed systems', clientId=868c2e48-7034-4973-8a92-28e3a88d395a}
[PST-Time-Zone] 2024-04-04 15:34:53.904 [Level] INFO, [Message] Sent COMMIT to Server[b7375e55-32ed-44b2-8da2-25318dde55eb].
[PST-Time-Zone] 2024-04-04 15:34:53.908 [Level] INFO, [Message] Received ack COMMIT from Server[654c7361-d467-442a-b108-ea328b51dd54].
[PST-Time-Zone] 2024-04-04 15:34:53.912 [Level] INFO, [Message] Sent COMMIT to Server[654c7361-d467-442a-b108-ea328b51dd54].
[PST-Time-Zone] 2024-04-04 15:34:53.916 [Level] INFO, [Message] Received ack COMMIT from Server[01dbf1aa-0b67-4fad-9428-4238291b2dff].
[PST-Time-Zone] 2024-04-04 15:34:53.919 [Level] INFO, [Message] Sent COMMIT to Server[01dbf1aa-0b67-4fad-9428-4238291b2dff].
[PST-Time-Zone] 2024-04-04 15:34:53.925 [Level] INFO, [Message] Received ack COMMIT from Server[c241ce68-ed9e-49c3-89a3-3a7c93eac1d3].
[PST-Time-Zone] 2024-04-04 15:34:53.930 [Level] INFO, [Message] Sent COMMIT to Server[c241ce68-ed9e-49c3-89a3-3a7c93eac1d3].
[PST-Time-Zone] 2024-04-04 15:34:53.936 [Level] INFO, [Message] Received ack COMMIT from Server[9517f3be-027f-4f04-a650-3cc93c20664f].
[PST-Time-Zone] 2024-04-04 15:34:53.938 [Level] INFO, [Message] Sent COMMIT to Server[9517f3be-027f-4f04-a650-3cc93c20664f].
[PST-Time-Zone] 2024-04-04 15:34:55.865 [Level] INFO, [Message] All servers ACK. Operation [PUT] successfully synchronized.
``` 

5. You can also check server[1] on how it works in this transaction based on 2PC protocol.

```angular2html
[PST-Time-Zone] 2024-04-04 15:34:52.774 [Level] INFO, [Message] Received PUT request from client[868c2e48-7034-4973-8a92-28e3a88d395a] with <key=6650, value=distributed systems>
[PST-Time-Zone] 2024-04-04 15:34:52.839 [Level] INFO, [Message] PREPARE: Message{messageId=98422aa1-7444-4786-b22c-0b83d8e454e8, type=PUT, key='6650', value='distributed systems', clientId=868c2e48-7034-4973-8a92-28e3a88d395a}
[PST-Time-Zone] 2024-04-04 15:34:52.840 [Level] INFO, [Message] Vote for COMMIT
[PST-Time-Zone] 2024-04-04 15:34:53.859 [Level] INFO, [Message] COMMITTED: Message{messageId=98422aa1-7444-4786-b22c-0b83d8e454e8, type=PUT, key='6650', value='distributed systems', clientId=868c2e48-7034-4973-8a92-28e3a88d395a}
[PST-Time-Zone] 2024-04-04 15:34:53.861 [Level] INFO, [Message] Added/Updated pair <key=6650, value=distributed systems>.
[PST-Time-Zone] 2024-04-04 15:34:53.903 [Level] INFO, [Message] Sent response: <key=6650, value=distributed systems> has been successfully stored.
```

6. Feel free to try `GET` or `DELETE` operations by yourself following the instructions above. 

**Note:** 
1) To ensure system robustness, inputs are validated for null or empty values. Should you enter an 
invalid input, a prompt will appear: `Key or value must NOT be NULL or EMPTY. Please enter a valid input.` Following this, you'll be guided back to instructions for making a request.

2) For data accuracy, the system automatically trims leading and trailing spaces from inputs. For instance, a key-value pair entered as <key=   5001 , value=   python > will be stored as <key=5001, value=python> in the database. This not only ensures that inadvertent spaces do not affect the storage and retrieval of data but also reduces the likelihood of errors or confusion related to unexpected spaces in key or value fields.
   
3) For user convenience, the system automatically guides the user for how to interact with server and how to enter a request. For example, if user chooses server`9` to interact with, system will show instruction messages like `Invalid input. Please enter 0 or 1 or 2 or 3 or 4 to select a server.` then user may try to interact and perform request again.


## Test

Please note that all screenshots of my testing done on my local laptop for **multiple clients with any of the 5 replica servers** are attached to the folder of `/res`. Feel free to check them out!

Here, I will only copy and paste the log messages as an example.

### Success

#### PUT

```angular2html
5 servers are now available: [0, 1, 2, 3, 4]
----------------------------------------
Want to INTERACT with Server?
Enter a number from [0, 1, 2, 3, 4] to interact with any server.
If you want to exit, just enter [exit].
-----------------------------------------
Please enter a server number for the interaction: 
1
----------------------------------------
How to Enter Your Request:
Enter 1: GET the value by a certain key
Enter 2: ADD or UPDATE a key-value pair
Enter 3: DELETE an existing key-value pair
Enter 4: EXIT this program
-----------------------------------------
Please enter a number for your request: 
2
Enter the key:
6650
Enter the value:
distributed systems
[PST-Time-Zone] 2024-04-04 15:34:53.022 [Level] INFO, [Message] Sent PUT request for <key=6650, value=distributed systems> to server[1]
[PST-Time-Zone] 2024-04-04 15:34:54.027 [Level] INFO, [Message] Received response from server[1]: <key=6650, value=distributed systems> has been successfully stored.
```

You can also **UPDATE** a key-value pair to any server:

```angular2html
5 servers are now available: [0, 1, 2, 3, 4]
----------------------------------------
Want to INTERACT with Server?
Enter a number from [0, 1, 2, 3, 4] to interact with any server.
If you want to exit, just enter [exit].
-----------------------------------------
Please enter a server number for the interaction: 
0
----------------------------------------
How to Enter Your Request:
Enter 1: GET the value by a certain key
Enter 2: ADD or UPDATE a key-value pair
Enter 3: DELETE an existing key-value pair
Enter 4: EXIT this program
-----------------------------------------
Please enter a number for your request: 
2
Enter the key:
6650
Enter the value:
Good Course
[PST-Time-Zone] 2024-04-04 15:59:25.938 [Level] INFO, [Message] Sent PUT request for <key=6650, value=Good Course> to server[0]
[PST-Time-Zone] 2024-04-04 15:59:27.352 [Level] INFO, [Message] Received response from server[0]: <key=6650, value=Good Course> has been successfully stored.
```

#### GET

```angular2html
5 servers are now available: [0, 1, 2, 3, 4]
----------------------------------------
Want to INTERACT with Server?
Enter a number from [0, 1, 2, 3, 4] to interact with any server.
If you want to exit, just enter [exit].
-----------------------------------------
Please enter a server number for the interaction: 
2
----------------------------------------
How to Enter Your Request:
Enter 1: GET the value by a certain key
Enter 2: ADD or UPDATE a key-value pair
Enter 3: DELETE an existing key-value pair
Enter 4: EXIT this program
-----------------------------------------
Please enter a number for your request: 
1
Enter the key:
6650
[PST-Time-Zone] 2024-04-04 15:59:59.621 [Level] INFO, [Message] Sent GET request for key=6650 to server[2]
[PST-Time-Zone] 2024-04-04 15:59:59.626 [Level] INFO, [Message] Received response from server[2]: Good Course
```

#### DELETE

```angular2html
5 servers are now available: [0, 1, 2, 3, 4]
----------------------------------------
Want to INTERACT with Server?
Enter a number from [0, 1, 2, 3, 4] to interact with any server.
If you want to exit, just enter [exit].
-----------------------------------------
Please enter a server number for the interaction: 
4
----------------------------------------
How to Enter Your Request:
Enter 1: GET the value by a certain key
Enter 2: ADD or UPDATE a key-value pair
Enter 3: DELETE an existing key-value pair
Enter 4: EXIT this program
-----------------------------------------
Please enter a number for your request: 
3
Enter the key:
6650
[PST-Time-Zone] 2024-04-04 16:02:08.501 [Level] INFO, [Message] Sent DELETE request for key=6650 to server[4]
[PST-Time-Zone] 2024-04-04 16:02:10.041 [Level] INFO, [Message] Received response from server[4]: [key=6650] has been successfully deleted.
```

#### Concurrent Operations

To verify that my program can correctly handle concurrent operations from different clients, I conducted the tests as below:

1) `client-1` on `port-4010` adds a key-value pair to `server[3]`:
   
```angular2html
[PST-Time-Zone] 2024-04-04 16:09:28.964 [Level] INFO, [Message] Sent PUT request for <key=6650, value=distributed systems> to server[3]
[PST-Time-Zone] 2024-04-04 16:09:30.880 [Level] INFO, [Message] Received response from server[3]: <key=6650, value=distributed systems> has been successfully stored.
```
2) `client-2` on `port-4011` deletes a key-value pair to `server[4]`:

```angular2html
[PST-Time-Zone] 2024-04-04 16:10:36.747 [Level] INFO, [Message] Sent DELETE request for key=6650 to server[4]
[PST-Time-Zone] 2024-04-04 16:10:38.108 [Level] INFO, [Message] Received response from server[4]: [key=6650] has been successfully deleted.
```

3) Attempting to GET <key=6650> from any of the replica servers on any client should result in the same response that `key is not found or has already been deleted from database.`
   
```angular2html
[PST-Time-Zone] 2024-04-04 16:11:30.205 [Level] INFO, [Message] Sent GET request for key=6650 to server[0]
[PST-Time-Zone] 2024-04-04 16:11:30.240 [Level] INFO, [Message] Received response from server[0]: [key=6650] is not found or has already been deleted from the database.
```

1) Notice that both coordinator and servers logged these transactions. Due to the extensive length of these logs and space limitations in this document, I will not copy and paste the full log details here. 


### Failure

#### GET

When you try to retrieve a key that not exists:

```angular2html
[PST-Time-Zone] 2024-04-04 16:16:26.424 [Level] INFO, [Message] Sent GET request for key=haha to server[1]
[PST-Time-Zone] 2024-04-04 16:16:26.471 [Level] INFO, [Message] Received response from server[1]: [key=haha] is not found or has already been deleted from the database.
```
The `server` side will show logs as below:

```angular2html
[PST-Time-Zone] 2024-04-04 16:16:26.448 [Level] INFO, [Message] Received GET request from client[dc9d5aa2-e915-4c92-85dc-152308a82ae2] with [key=haha]
[PST-Time-Zone] 2024-04-04 16:16:26.468 [Level] INFO, [Message] Sent response for GET request to client[dc9d5aa2-e915-4c92-85dc-152308a82ae2]: [key=haha] is not found or has already been deleted from the database.
```

Please note that, since `GET` is a read-only operation, the `coordinator` side will not need to synchronize this transaction data. 


#### DELETE

When you delete a key that does not exist by interacting with `server[0]`:
```angular2html
[PST-Time-Zone] 2024-04-04 16:53:25.786 [Level] INFO, [Message] Sent DELETE request for key=haha to server[0]
[PST-Time-Zone] 2024-04-04 16:53:27.305 [Level] INFO, [Message] Received response from server[0]: The operation for key='haha' was aborted and did not change the database.
```

The specific server `server[0]` will show logs as below:
```angular2html
[PST-Time-Zone] 2024-04-04 16:53:25.750 [Level] INFO, [Message] Received DELETE request from client[2b52ca11-45c9-4973-bd14-89a89a000e1e] with [key=haha]
[PST-Time-Zone] 2024-04-04 16:53:25.764 [Level] INFO, [Message] PREPARE: Message{messageId=0071eacb-4fe5-40b3-a928-713a8e61e7ca, type=DELETE, key='haha', value='null', clientId=2b52ca11-45c9-4973-bd14-89a89a000e1e}
[PST-Time-Zone] 2024-04-04 16:53:25.765 [Level] INFO, [Message] Vote for ABORT due to DELETE request for non-existent key.
[PST-Time-Zone] 2024-04-04 16:53:26.799 [Level] INFO, [Message] ABORT: Message{messageId=0071eacb-4fe5-40b3-a928-713a8e61e7ca, type=DELETE, key='haha', value='null', clientId=2b52ca11-45c9-4973-bd14-89a89a000e1e}
[PST-Time-Zone] 2024-04-04 16:53:26.818 [Level] INFO, [Message] Transaction aborted. No changes were made.
[PST-Time-Zone] 2024-04-04 16:53:26.904 [Level] INFO, [Message] Sent response: The operation for key='haha' was aborted and did not change the database.
```

The `coordinator` will also log the 2PC protocol for this transaction:
```angular2html
[PST-Time-Zone] 2024-04-04 16:53:25.753 [Level] INFO, [Message] PREPARE for transaction on Server[0ddcd287-9162-4d46-afc2-d6b72cf641ea]: Message{messageId=0071eacb-4fe5-40b3-a928-713a8e61e7ca, type=DELETE, key='haha', value='null', clientId=2b52ca11-45c9-4973-bd14-89a89a000e1e}
[PST-Time-Zone] 2024-04-04 16:53:25.760 [Level] INFO, [Message] Server[0ebffb4a-aab4-4950-8cc4-c5b316e3138a] REJECT the transaction: Message{messageId=0071eacb-4fe5-40b3-a928-713a8e61e7ca, type=DELETE, key='haha', value='null', clientId=2b52ca11-45c9-4973-bd14-89a89a000e1e}.
[PST-Time-Zone] 2024-04-04 16:53:25.767 [Level] INFO, [Message] Server[0ddcd287-9162-4d46-afc2-d6b72cf641ea] REJECT the transaction: Message{messageId=0071eacb-4fe5-40b3-a928-713a8e61e7ca, type=DELETE, key='haha', value='null', clientId=2b52ca11-45c9-4973-bd14-89a89a000e1e}.
[PST-Time-Zone] 2024-04-04 16:53:25.773 [Level] INFO, [Message] Server[e2040e3c-287d-4bdb-8147-bba3d2e3e2d7] REJECT the transaction: Message{messageId=0071eacb-4fe5-40b3-a928-713a8e61e7ca, type=DELETE, key='haha', value='null', clientId=2b52ca11-45c9-4973-bd14-89a89a000e1e}.
[PST-Time-Zone] 2024-04-04 16:53:25.779 [Level] INFO, [Message] Server[4e330558-a1f3-4bf1-8780-1dcd1ebfa37c] REJECT the transaction: Message{messageId=0071eacb-4fe5-40b3-a928-713a8e61e7ca, type=DELETE, key='haha', value='null', clientId=2b52ca11-45c9-4973-bd14-89a89a000e1e}.
[PST-Time-Zone] 2024-04-04 16:53:25.785 [Level] INFO, [Message] Server[593110b7-f11b-4c95-a79f-e67d2a3e578a] REJECT the transaction: Message{messageId=0071eacb-4fe5-40b3-a928-713a8e61e7ca, type=DELETE, key='haha', value='null', clientId=2b52ca11-45c9-4973-bd14-89a89a000e1e}.
[PST-Time-Zone] 2024-04-04 16:53:26.779 [Level] INFO, [Message] Received ACK ABORT from Server[0ebffb4a-aab4-4950-8cc4-c5b316e3138a].
[PST-Time-Zone] 2024-04-04 16:53:26.779 [Level] INFO, [Message] Synchronizing: Message{messageId=0071eacb-4fe5-40b3-a928-713a8e61e7ca, type=DELETE, key='haha', value='null', clientId=2b52ca11-45c9-4973-bd14-89a89a000e1e}
[PST-Time-Zone] 2024-04-04 16:53:26.785 [Level] INFO, [Message] Sent ABORT to Server[0ebffb4a-aab4-4950-8cc4-c5b316e3138a].
[PST-Time-Zone] 2024-04-04 16:53:26.817 [Level] INFO, [Message] Received ACK ABORT from Server[0ddcd287-9162-4d46-afc2-d6b72cf641ea].
[PST-Time-Zone] 2024-04-04 16:53:26.905 [Level] INFO, [Message] Sent ABORT to Server[0ddcd287-9162-4d46-afc2-d6b72cf641ea].
[PST-Time-Zone] 2024-04-04 16:53:26.928 [Level] INFO, [Message] Received ACK ABORT from Server[e2040e3c-287d-4bdb-8147-bba3d2e3e2d7].
[PST-Time-Zone] 2024-04-04 16:53:26.931 [Level] INFO, [Message] Sent ABORT to Server[e2040e3c-287d-4bdb-8147-bba3d2e3e2d7].
[PST-Time-Zone] 2024-04-04 16:53:26.952 [Level] INFO, [Message] Received ACK ABORT from Server[4e330558-a1f3-4bf1-8780-1dcd1ebfa37c].
[PST-Time-Zone] 2024-04-04 16:53:26.955 [Level] INFO, [Message] Sent ABORT to Server[4e330558-a1f3-4bf1-8780-1dcd1ebfa37c].
[PST-Time-Zone] 2024-04-04 16:53:26.976 [Level] INFO, [Message] Received ACK ABORT from Server[593110b7-f11b-4c95-a79f-e67d2a3e578a].
[PST-Time-Zone] 2024-04-04 16:53:26.981 [Level] INFO, [Message] Sent ABORT to Server[593110b7-f11b-4c95-a79f-e67d2a3e578a].
[PST-Time-Zone] 2024-04-04 16:53:28.785 [Level] INFO, [Message] All servers ACK. DELETE transaction successfully synchronized.
```

#### Server unresponsive/timeout failure

When the server is not responsive, the client is robust to server failure by using a timeout mechanism to deal with it.

To test for timeouts in client-server communication in this Java RMI environment, I simulated the scenarios where the server takes longer to respond than the client is willing to wait. Through this timeout failure test, my application shows it can gracefully handle situations where a service is unresponsive or slow, preventing it from hanging indefinitely.

To achieve this goal, I first set system properties to define the timeout duration for remote method calls before the RMI client starts the lookup or invokes methods on the remote object.

To test this scenario, I first modified the server to intentionally delay responses for certain requests by adding a `Thread.sleep()` call in the server's `KeyValueRpcImpl` class. I also modified the `monitorResponsesAndTimeouts()` method in `ClientApp` so when response is not received within a specified timeout period, the ClientLogger logs a timeout error.

Since the delay exceeds the timeout I've configured, the client encountered a RemoteException then exited.

In this test, the client shows logs as below:
```angular2html
[PST-Time-Zone] 2024-04-04 21:16:10.355 [Level] INFO, [Message] Sent DELETE request for key=6650 to server[0]
[PST-Time-Zone] 2024-04-04 21:16:11.359 [Level] ERROR, [Message] TIMEOUT because client cannot receive response for the request: Message{messageId=9cd6f083-4689-4510-8e07-dd9eeb0721fe, type=DELETE, key='6650', value='null', clientId=d71e3a07-f498-4344-874d-678e91b6b47c}
```

## Limitations and Future Iterations

Despite the progress made, there are several areas waiting for future development. For example, although my current design can meet the project 3's requirements, as Dr. Saripalli mentioned in his lecture, 2PC protocols are not fault tolerant. That means if one of the replica servers stops working, it can cause problems. Therefore, my next goal is to build Project 4 with the use of Paxos Algorithm so servers can agree on changes even if some of them are having issues. This will make the key value store more reliable, because it can keep running smoothly no matter what happens. I'll also be adding new components to the system, like Proposers, Acceptors, and Learners as describe in Lamport papers, each with a special job in deciding how to safely make changes. This is a more complicated job for me, so I need more careful designs. I believe this future iteration will help me further understand how system behaves under conditions of network latency, partial failures, and load distribution across different servers.
