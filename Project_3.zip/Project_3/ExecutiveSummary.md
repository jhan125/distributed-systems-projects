# Executive Summary

## Assignment Overview

This assignment asks us to enhance the a single-instance Key-Value Store Server in Project 2. 
Requirements and goals include:
- replicate key value store server across 5 distinct servers, so the system can increase bandwidth and ensure high availability. 
- make sure the data access and update operations (GET, PUT, DELETE) across replicas are consistent. 
- implement a two-phase commit (2PC) protocol for data consistency during PUT and DELETE operations. 
- include timeouts in 2PC protocol for robustness, despite not expecting server failures. 
- use a client to perform preload operations (at least 5 of each operation: 5 PUTs, 5 GETs, 5 DELETEs).
- write well-structured and commented Java code.

## Technical Impression

My first impression of this project is that I should extend the key-value store from Project 2 and made it more powerful and reliable by spreading it across five different servers. I also need to use 2PC protocol to make sure when client want to save or delete something in the store, all five servers need agree to make the change at the same time. To achieve these goals, I made several design considerations and implemented them accordingly. First, I extended JavaRMI I used in Project 2 for inter-server communication, thus enabling the coordination for 2PC protocol among the replicated servers. Second, I implemented a 2PC protocol with the help of a coordinator as a separate entity, so it can manage the prepare and commit/abort phases across all server replicas(participants). Third, I used several mechanisms to detect server failures such as timeout for the 2PC protocol, logging every necessary transaction state, and handling failures among replicas. Fourth, I used UUIDs to give the coordinator, each participant server, each client, and each individual transaction a unique UUID so system can track transactions across the network. Moreover, I kept Project 2's design of `ReentrantLock` so the updates during the commit phase of 2PC are mutually exclusive. Last but not least, I decided to use command-line arguments for setting up and managing RMI registry so users can easily set up port numbers for the coordinator, replica servers, and clients with their preference. Clear step-by-step instructions and test cases were also well documented in the [README](./README.md) file.

Looking ahead, I want to make the system even stronger. As Dr. Saripalli mentioned in his lecture, 2PC protocols are not fault tolerant. That means if one of the replica servers stops working, it can cause problems. Therefore, my next goal is to build Project 4 with the use of Paxos Algorithm so servers can agree on changes even if some of them are having issues. This will make the key value store more reliable, because it can keep running smoothly no matter what happens. I'll also be adding new components to the system, like Proposers, Acceptors, and Learners as describe in Lamport papers, each with a special job in deciding how to safely make changes. This is a more complicated job for me, so I need more careful designs. I believe this future iteration will help me further understand how system behaves under conditions of network latency, partial failures, and load distribution across different servers.