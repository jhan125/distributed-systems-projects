package coordinator;

import api.KeyValueRpc;
import api.TransactionService;
import server.KeyValueStore;
import protocol.TransactionMessage;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * Implementation of the Coordinator role in a distributed transaction system. This class
 * manages the coordination of transaction operations across multiple servers, ensuring
 * consistency and reliability in the distributed environment. It supports operations for
 * initiating transaction preparations, collecting votes for transaction outcomes, and
 * handling server registrations and crash recovery.
 */
public class CoordinatorImpl extends UnicastRemoteObject implements TransactionService {

    // key: participant servers' IDs, value: server's respective RPC interfaces for communication
    private final Map<String, KeyValueRpc> participantConnections;

    // all participant servers' IDs that have crashed and may require data synchronization upon recovery
    private final Set<String> crashedServers;

    // key: participant servers' IDs, value: their vote (accept or reject) on the transaction
    private final Map<String, Boolean> voteResponseCollector;

    // participant server IDs that have acknowledged the completion of the transaction phase (commit or abort)
    private final Set<String> transactionAckCollector;

    // store transaction data, used for data recovery in case of server crashes
    private final KeyValueStore transactionDataCache;

    // thread pool for timeout handling and sync data with crash servers
    private final Executor executor;

    // if the initial response for a transaction has been received, used for timeout management
    private boolean hasReceivedInitialResponse = false;

    // if the initial acknowledgment for a transaction completion has been received
    private boolean hasReceivedInitialAck = false;

    /**
     * Constructs a CoordinatorImp instance, initializing collections for server management and transaction handling.
     * 
     * @throws RemoteException if a remote communication error occurs
     */
    protected CoordinatorImpl() throws RemoteException {
        this.participantConnections = new HashMap<>();
        this.crashedServers = new HashSet<>();
        this.voteResponseCollector = new HashMap<>();
        this.transactionAckCollector = new HashSet<>();
        this.transactionDataCache = new KeyValueStore();
        this.executor = Executors.newFixedThreadPool(10);
    }

    @Override
    public void prepare(String serverId, TransactionMessage message) throws RemoteException {
        CoordinatorLogger.info(String.format("PREPARE for transaction on Server[%s]: %s", serverId, message));
        // Send the message to all participants
        participantConnections.forEach((key, value) -> {
            try {
                value.prepare(message);
            } catch (RemoteException e) {
                CoordinatorLogger.error(String.format("Connection error with Server[%s] during PREPARE phase. Attempting reconnection.", key));
            }
        });
    }

    @Override
    public void accept(String serverId, TransactionMessage message) throws RemoteException {
        CoordinatorLogger.info(String.format("Server[%s] ACCEPT the transaction: %s.", serverId, message));
        voteResponseCollector.put(serverId, true);
        analyzeTransactionResult(message);
    }

    @Override
    public void reject(String serverId, TransactionMessage message) throws RemoteException {
        CoordinatorLogger.info(String.format("Server[%s] REJECT the transaction: %s.", serverId, message));
        voteResponseCollector.put(serverId, false);
        analyzeTransactionResult(message);
    }

    @Override
    public void acknowledgeCommit(String serverId, TransactionMessage message) throws RemoteException {
        CoordinatorLogger.info(String.format("Received ack COMMIT from Server[%s].", serverId));
        transactionAckCollector.add(serverId);
        analyzeAcknowledgments(message);
    }

    @Override
    public void acknowledgeAbort(String serverId, TransactionMessage message) throws RemoteException {
        CoordinatorLogger.info(String.format("Received ACK ABORT from Server[%s].", serverId));
        transactionAckCollector.add(serverId);
        analyzeAcknowledgments(message);
    }

    @Override
    public void registerServer(String serverId, String ip, int port) throws RemoteException {
        try {
            KeyValueRpc server = (KeyValueRpc) Naming.lookup("rmi://" + ip + ":" + port + "/Service");
            // add the server to the server info
            participantConnections.put(serverId, server);
            CoordinatorLogger.info(String.format("Server[%s] at host[%s]:port[%d] successfully registered.", serverId, ip, port));
            CoordinatorLogger.info(String.format("%d server(s) have successfully connected to Coordinator.", participantConnections.size()));

            executor.execute(() -> {
                // if the server is presented on the crash server set and reconnected with the coordinator
                // start data recovery
                boolean containsKey = crashedServers.contains(serverId);
                if (containsKey) {
                    CoordinatorLogger.info(String.format("Server[%s] reconnected. Synchronizing data...", serverId));
                    try {
                        Thread.sleep(5000); // wait for connection to be stable
                        // sync data with the server
                        server.synchronizeData(transactionDataCache.getKeyValStore());
                        CoordinatorLogger.info(String.format("Data synchronization complete for Server[%s].", serverId));
                        crashedServers.remove(serverId);
                    } catch (RemoteException e) {
                        CoordinatorLogger.error(String.format("Synchronization failed for Server[%s] due to connection loss.", serverId));
                    } catch (InterruptedException e) {
                        CoordinatorLogger.error("Data synchronization thread interrupted." + e.getMessage());
                    }
                }
            });
        } catch (NotBoundException | MalformedURLException e) {
            CoordinatorLogger.error(String.format("Registration failed for unknown Server[%s] at host[%s]:port[%d].", serverId, ip, port));
        }
    }

    /**
     * Analyzes vote responses from all participating servers to determine if any server voted to abort the transaction.
     * It clears the vote response collector after analysis for reuse in future transactions.
     *
     * @return true if any server voted to abort, indicating the transaction should be aborted.
     */
    private boolean analyzeVotes() {
        // determine if there is a false in the response map
        boolean voteAbort = voteResponseCollector.containsValue(false);
        // clear the collector for next time use
        voteResponseCollector.clear();
        return voteAbort;
    }

    /**
     * Handles the analysis and final decision-making of a transaction based on the responses (acknowledgments) 
     * from participant servers. If responses from all servers are not received within a specified timeout, 
     * identifies unresponsive servers and decides on the transaction accordingly.
     *
     * @param message The transaction message containing details about the operation to be analyzed.
     */
    private void analyzeTransactionResult(TransactionMessage message) {
        // when received the first response of commit or abort from one server
        // start timing
        // if we cannot receive responses from all server, then timeout
        // continue to the transaction
        String operationInfo = message.getType().toString(); // Example, adjust based on your implementation
        if (!hasReceivedInitialResponse) {
            // set the response lock when first response arrive
            hasReceivedInitialResponse = true;
            executor.execute(() -> {
                try {
                    // timeout for 1 second
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    CoordinatorLogger.info("Collection of responses from participant servers was interrupted.");
                }

                 // Identify unresponsive servers after waiting for responses
                Set<String> unresponsiveServers = identifyUnresponsiveServers(participantConnections.keySet(), voteResponseCollector.keySet());

                // Log and handle unresponsive servers
                unresponsiveServers.forEach(key -> CoordinatorLogger.error(String.format("No response from Server[%s]. Considering as vote to ABORT.", key)));
                
                // Analyze votes including considering unresponsive servers as ABORT
                boolean shouldAbort = analyzeVotes() || !unresponsiveServers.isEmpty();
            
                if (shouldAbort) {
                    // If any server voted to abort or did not respond, send abort messages to all
                    sendDecisionToAll(message, false); // false indicates abort
                } else {
                    // If all responded and voted to commit, send commit messages to all
                    sendDecisionToAll(message, true); // true indicates commit
                }

                // clear the ack collector
                voteResponseCollector.clear();
                hasReceivedInitialResponse = false;
            });
        }
    }

    private void sendDecisionToAll(TransactionMessage message, boolean commitDecision) {
        participantConnections.forEach((serverId, serverProxy) -> {
            try {
                if (commitDecision) {
                    serverProxy.commit(message);
                    CoordinatorLogger.info(String.format("Sent COMMIT to Server[%s].", serverId));
                } else {
                    serverProxy.abort(message);
                    CoordinatorLogger.info(String.format("Sent ABORT to Server[%s].", serverId));
                }
            } catch (RemoteException e) {
                CoordinatorLogger.error(String.format("Failed to send decision to Server[%s]. Attempting reconnection.", serverId));
            }
        });
    }

     /**
     * Analyzes acknowledgments from all participating servers to determine the completion status of the transaction.
     * If not all acknowledgments are received within a specified timeout, it identifies unresponsive servers.
     *
     * @param message The transaction message indicating the operation that was acknowledged.
     */
    public void analyzeAcknowledgments(TransactionMessage message) {
        // when received the first response of commit or abort from one server
        // start timing
        // if we cannot receive ack from all server, then timeout
        if (!hasReceivedInitialAck) {
            hasReceivedInitialAck = true;
            String operationInfo = message.getType().toString(); // Example, adjust based on your implementation

            CoordinatorLogger.info(String.format("Synchronizing: %s", message));
            executor.execute(() -> {
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    CoordinatorLogger.info("Analysis for ACK from participant servers was interrupted.");
                }

                /** TEST: simulate the scenario where the coordinator fails to receive all ACKs in time */ 
                // try {
                //     Thread.sleep(500000); // Simulate timeout failure
                // } catch (InterruptedException e) {
                //     Thread.currentThread().interrupt();
                //     CoordinatorLogger.info("Interrupted during simulated delay.");
                // }

                if (transactionAckCollector.size() != participantConnections.size()) {
                    Set<String> unresponsiveServers = identifyUnresponsiveServers(transactionAckCollector, participantConnections.keySet());
                    unresponsiveServers.forEach((key) -> {
                        CoordinatorLogger.error(String.format("No ACK from Server[%s] for %s. Attempting reconnection.", key, operationInfo));
                        markServerAsCrashed(key);
                    });
                } else {
                    CoordinatorLogger.info(String.format("All servers ACK. %s transaction successfully synchronized.", operationInfo));
                }
                transactionAckCollector.clear();
                hasReceivedInitialAck = false;
            });
        }
    }

    /**
     * Marks the specified server ID as crashed and adds it to the set of servers that need recovery actions.
     *
     * @param serverId The unique identifier of the crashed server.
     */
    public void markServerAsCrashed(String serverId) {
        crashedServers.add(serverId);
    }

    /**
     * Identifies unresponsive servers by comparing the set of all server IDs against
     * the set of server IDs that have responded.
     *
     * @param responsiveServers Set<String> containing the IDs of servers that have responded.
     * @param allServers Set<String> containing the IDs of all known servers.
     * @return Set<String> containing the IDs of servers that did not respond.
     */
    private Set<String> identifyUnresponsiveServers(Set<String> responsiveServers, Set<String> allServers) {
        Set<String> unresponsiveServers = new HashSet<>();
        for (Map.Entry<String, KeyValueRpc> entry : participantConnections.entrySet()) {
            if (!voteResponseCollector.containsKey(entry.getKey())) {
                unresponsiveServers.add(entry.getKey());
            }
        }
        return unresponsiveServers;
    }
}
