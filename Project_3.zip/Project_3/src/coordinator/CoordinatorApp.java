package coordinator;

import java.net.UnknownHostException;
import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;

/**
 * CoordinatorApp is the main class for the Coordinator App in a distributed system.
 * It initializes and starts the Coordinator on a specified network port, facilitating the coordination
 * of transactions across multiple participant servers. This class parses command-line arguments to
 * retrieve the port number on which the Coordinator should listen for incoming connections and transaction
 * requests. Upon successful initialization, the Coordinator is ready to manage Two-Phase Commit (2PC), 
 * thus ensuring consistency and reliability in the distributed environment.
 */
public class CoordinatorApp {

    /**
     * Main entry point of the application. Parses command-line arguments to
     * establish a connection to the server and handles connection errors.
     *
     * @param args Command-line arguments specifying coordinator's port.
     */
    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Usage: java -jar coordinator.jar <port-number> " + 
                                "e.g. `java -jar coordinator.jar 1099`");
            return;
        }


        String port = args[0];
        try {
            // start coordinator
            new Coordinator(port);
        } catch (RemoteException | AlreadyBoundException | NumberFormatException | UnknownHostException e) {
            CoordinatorLogger.error("Error while setting up the coordinator: " + e.getMessage());
            System.exit(1);
        }
    }
}
