package coordinator;

import api.TransactionService;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 * Initializes the Coordinator for a distributed transaction system.
 * This class is responsible for creating and setting up the RMI infrastructure,
 * which allows remote clients to interact with the Coordinator through defined
 * transaction operations.
 */
public class Coordinator  {

    /**
     * Initializes and starts the RMI service for the Coordinator on the specified port.
     * It creates a remote object implementation, binds it to the RMI registry,
     * and makes it available for remote interactions.
     *
     * @param port   The port number as a String on which the RMI registry is created
     *               and listens for incoming connections.
     * @throws RemoteException If a RemoteException occurs during the creation of the RMI registry
     *                         or binding the remote object.
     * @throws AlreadyBoundException If the registry already contains a binding for the specified
     *                               name ("Transaction").
     * @throws NumberFormatException If the provided portString cannot be parsed as an integer.
     * @throws UnknownHostException If the local host name could not be resolved into an address.
     */
    public Coordinator(String port) throws RemoteException, AlreadyBoundException, NumberFormatException, UnknownHostException {
        // create skeleton
        TransactionService stub = new CoordinatorImpl();
        // bind the stub to registry
        Registry registry = LocateRegistry.createRegistry(Integer.parseInt(port));
        registry.bind("Transaction", stub);
        String host = InetAddress.getLocalHost().getHostName();
        CoordinatorLogger.info(String.format("Coordinator is ready at host[%s] port[%s]: ", host, port));
    }

}
