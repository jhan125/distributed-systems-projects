package protocol;

import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;

/**
 * Represents a message used for data transfer during the two-phase commit protocol in a distributed system.
 * This class encapsulates the details of the transaction operation, including the unique identifiers
 * for the message and the client, the type of operation being performed, and the key-value pair involved
 * in the operation if applicable. It is designed to be serializable so that it can be easily transmitted
 * over a network or stored and retrieved from persistent storage.
 */
public class TransactionMessage implements Serializable {

    private static final long serialVersionUID = 1234567L;
    private UUID messageId;
    private OperationType type;
    private String key;
    private String value;
    private UUID clientId;

    /**
     * Constructs a new TransactionMessage with specified details.
     *
     * @param messageId     The unique identifier of the message.
     * @param operationType The type of operation being performed (e.g., PUT, DELETE, GET).
     * @param dataKey       The key associated with the operation, if applicable.
     * @param dataValue     The value associated with the operation, for PUT operations.
     * @param clientId      The unique identifier of the client initiating the transaction.
     */
    public TransactionMessage(UUID messageId, OperationType type, String key, String value, UUID clientId) {
        this.messageId = messageId;
        this.type = type;
        this.key = key;
        this.value = value;
        this.clientId = clientId;
    }

    // Getters
    public UUID getMessageId() { return messageId; }
    public OperationType getType() { return type; }
    public String getKey() { return key; }
    public String getValue() { return value; }
    public UUID getClientId() { return clientId; }

    // Setters
    public void setMessageId(UUID messageId) { this.messageId = messageId; }
    public void setType(OperationType type) { this.type = type; }
    public void setKey(String key) { this.key = key; }
    public void setValue(String value) { this.value = value; }
    public void setClientId(UUID clientId) { this.clientId = clientId; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TransactionMessage)) return false;
        TransactionMessage message = (TransactionMessage) o;
        return messageId.equals(message.messageId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(messageId);
    }

    @Override
    public String toString() {
        return "Message{" +
                "messageId=" + messageId +
                ", type=" + type +
                ", key='" + key + '\'' +
                ", value='" + value + '\'' +
                ", clientId=" + clientId +
                '}';
    }
}
