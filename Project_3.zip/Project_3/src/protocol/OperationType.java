package protocol;

/**
 * Enumerates the types of operations that can be performed on a key-value store or database.
 * This enumeration is used to specify the kind of action that is being requested or carried out,
 * such as inserting or updating a value (`PUT`), removing a value (`DELETE`), or retrieving a value (`GET`).
 * Utilizing this enumeration helps in defining clear and type-safe APIs for database interactions.
 */
public enum OperationType {
    PUT, 
    DELETE, 
    GET
}
