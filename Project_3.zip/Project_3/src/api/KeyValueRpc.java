package api;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Map;
import java.util.UUID;

import protocol.TransactionMessage;

/**
 * Defines the Remote Procedure Call (RPC) interface for interacting with a key-value store.
 * This interface allows clients to perform get, put, and delete operations on the key-value store
 * in a thread-safe manner over a network.
 */
public interface KeyValueRpc extends Remote {

    /**
     * Retrieves the value associated with a given key from the key-value store.
     *
     * @param clientId Unique identifier of the client requesting the operation, enhancing traceability and security.
     * @param key The key whose associated value is to be retrieved.
     * @return The value associated with the specified key, or an error if the key does not exist.
     * @throws RemoteException If a network or execution error occurs during the remote call.
     */
    String doGet(UUID clientId, String key) throws RemoteException;

    /**
     * Inserts or updates a key-value pair in the key-value store. If the key already exists, its associated value
     * is updated; otherwise, a new key-value pair is created.
     *
     * @param message Contains the key-value pair to be inserted or updated.
     * @param hostname The hostname of the server performing the operation.
     * @param port The network port of the server.
     * @throws RemoteException If an error occurs during the remote method call.
     */
    void doPut(TransactionMessage message, String hostname, int port) throws RemoteException;

    /**
     * Deletes a key-value pair from the key-value store, if the key exists.
     *
     * @param message Contains the key of the key-value pair to be deleted.
     * @param hostname The hostname of the server performing the operation.
     * @param port The network port of the server.
     * @throws RemoteException If an error occurs during the remote method call.
     */
    void doDelete(TransactionMessage message, String hostname, int port) throws RemoteException;

    /**
     * Prepares for a transaction following a call from the coordinator, ensuring that the key-value store
     * is ready for the upcoming transactional operations.
     *
     * @param message Contains transaction-related data or instructions.
     * @throws RemoteException If a network or execution error occurs during the remote call.
     */
    void prepare(TransactionMessage message) throws RemoteException;

    /**
     * Commits the data involved in the current transaction to the key-value store, making all changes permanent.
     *
     * @param message Contains the final state of the data to be committed.
     * @throws RemoteException If a network or execution error occurs during the remote call.
     */
    void commit(TransactionMessage message) throws RemoteException;

    /**
     * Aborts the current transaction, rolling back any changes made to the key-value store during the transaction.
     *
     * @param message Contains information or instructions related to the transaction to be aborted.
     * @throws RemoteException If a network or execution error occurs during the remote call.
     */
    void abort(TransactionMessage message) throws RemoteException;

    /**
     * Retrieves the unique identifier of the server, allowing clients to verify the server's identity.
     *
     * @return The unique identifier of the server.
     * @throws RemoteException If a network or execution error occurs during the remote call.
     */
    String getServerId() throws RemoteException;

    /**
     * Synchronizes the key-value store data with the transaction coordinator, particularly useful when
     * the server has been absent from transactions and needs to update its data to maintain consistency.
     *
     * @param data Contains the key-value pairs that need to be synchronized with the coordinator.
     * @throws RemoteException If a network or execution error occurs during the remote call.
     */
    void synchronizeData(Map<String, String> data) throws RemoteException;
}

