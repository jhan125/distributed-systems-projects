package api;

import protocol.TransactionMessage;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Defines the protocol for managing distributed transactions in a network of servers. This interface extends
 * the Remote interface, enabling methods to be called from a remote client. It supports the initiation,
 * preparation, acceptance, rejection, commitment, and abortion of transactions, as well as the registration
 * of servers with a transaction coordinator. This ensures that transactions across multiple servers can
 * be coordinated effectively, maintaining data consistency and integrity across the network.
 */
public interface TransactionService extends Remote {

     /**
     * Initiates the preparation phase of a transaction on a server. This method is called by a transaction
     * coordinator to inform a server that it should prepare for a transaction. The server is expected to
     * validate the transaction details and respond whether it can commit to the transaction or not.
     *
     * @param serverId  A unique identifier for the server on which the transaction is to be prepared.
     * @param message   A message containing details about the transaction that is to be prepared.
     * @throws RemoteException If an error occurs in remote method invocation.
     */
    void prepare(String serverId, TransactionMessage message) throws RemoteException;

    /**
     * Acknowledges the acceptance of a prepare request by a server. This method is called to confirm that
     * a server has successfully prepared for a transaction and is ready to commit it pending final
     * coordination.
     *
     * @param serverId The unique identifier of the server that has accepted the prepare request.
     * @param message  The message associated with the prepare request that was accepted.
     * @throws RemoteException If an error occurs in remote method invocation.
     */
    void accept(String serverId, TransactionMessage message) throws RemoteException;

    /**
     * Notifies the transaction coordinator of a server's rejection of a prepare request. This method is
     * called when a server cannot prepare for a transaction and therefore cannot commit to it.
     *
     * @param serverId  The unique identifier of the server that has rejected the prepare request.
     * @param message   The message associated with the prepare request that was rejected.
     * @throws RemoteException If an error occurs in remote method invocation.
     */
    void reject(String serverId, TransactionMessage message) throws RemoteException;

    /**
     * Confirms the successful commitment of a transaction on a server. This method is called after a server
     * has committed the transaction data successfully.
     *
     * @param serverIdentifier The unique identifier of the server that has committed the transaction.
     * @param commitMessage The message indicating the successful commitment of the transaction.
     * @throws RemoteException If an error occurs in remote method invocation.
     */
    void acknowledgeCommit(String serverId, TransactionMessage message) throws RemoteException;

    /**
     * Acknowledges the abortion of a transaction on a server. This method is called if a server has to abort
     * a transaction due to failure or rejection during the preparation phase.
     *
     * @param serverId  The unique identifier of the server that has aborted the transaction.
     * @param message   The message indicating the abortion of the transaction.
     * @throws RemoteException If an error occurs in remote method invocation.
     */
    void acknowledgeAbort(String serverId, TransactionMessage message) throws RemoteException;

    /**
     * Registers a server with the transaction coordinator. This method is used to ensure that a server is
     * recognized by the coordinator and included in transaction coordination. If a server is found to be
     * absent from ongoing transactions, this can trigger mechanisms such as synchronization to ensure
     * consistency.
     *
     * @param serverId  The unique identifier of the server being registered.
     * @param serverIp The IP address of the server.
     * @param serverPort The port number on which the server is listening for transactions.
     * @throws RemoteException If an error occurs in remote method invocation.
     */
    void registerServer(String serverId, String serverIp, int serverPort) throws RemoteException;
}
