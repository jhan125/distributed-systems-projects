package server;

import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.rmi.AlreadyBoundException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.security.NoSuchAlgorithmException;

/**
 * ServerApp is the main class for the server application for connection to a coordinator.
 * It ensures the input is valid and handles the setup of network connections. It also prepares for 
 * handling transaction requests from clients or coordination messages from the transaction coordinator.
 */
public class ServerApp {

    /**
     * The main method is the entry point of the server application.
     *
     * @param args Command-line arguments, expects to contain the participant port number,
     *             the coordinator's hostname, and the coordinator's port number.
     */
    public static void main(String[] args) {
        if (args.length < 3) {
            System.out.println("Usage: java -jar server.jar <coordinator-hostname> <coordinator-port-number> <participant-port-number>." +
                                "e.g. `java -jar server.jar localhost 1099 4001`");
            return;
        }

        String coordinatorHostname = args[0];
        String coordinatorPort = args[1];
        String port = args[2];
        
        try {
            // start server
            new Server(port, coordinatorHostname, coordinatorPort);
        } catch (RemoteException | AlreadyBoundException | NumberFormatException | NoSuchAlgorithmException e) {
            System.out.println(e.getMessage());
            System.out.println("Error occurred when registering at the given port. Please try again.");
            System.exit(1);
        } catch (MalformedURLException | NotBoundException | UnknownHostException e) {
            System.out.println("Error occurred when connecting to the coordinator. Please make sure the coordinator hostname and port are correct.");
            System.exit(1);
        }
    }
}
