package server;

import api.KeyValueRpc;
import api.TransactionService;
import client.Client;
import protocol.TransactionMessage;
import protocol.OperationType;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;

/**
 * Implements the server-side logic for a key-value storage system. This class handles remote
 * procedure calls from clients, including operations to get, put, and delete key-value pairs.
 * It also participates in transactions coordinated by a central transaction service, ensuring
 * consistent state changes across all participating servers.
 */
public class KeyValueRpcImpl extends UnicastRemoteObject implements KeyValueRpc {


    private final KeyValueStore keyValueStore;
    private final String serverID;
    private final TransactionService coordinator;

    // key: most recent client interaction (client hostname), value: port number on which the client is listening
    private final Map<String, Integer> currentClient;

    protected KeyValueRpcImpl(KeyValueStore db, String id, TransactionService coordinator) throws RemoteException {
        this.keyValueStore = db;
        this.serverID = id;
        this.coordinator = coordinator;
        this.currentClient = new HashMap<>();
    }

    @Override
    public String doGet(UUID clientId, String key) throws RemoteException {
        ServerLogger.info(String.format("Received GET request from client[%s] with [key=%s]", clientId,  key));
        // get the key from key value store
        String value = keyValueStore.get(key);
        if (value != null) {
            ServerLogger.info(String.format("Sent response for GET request to client[%s] with [key=%s] [value=%s]", clientId, key, value));
            return value;
        }
        String result = "[key=" + key + "] is not found or has already been deleted from the database.";
        ServerLogger.info(String.format("Sent response for GET request to client[%s]: %s", clientId, result));
        return result;
    }

    @Override
    public void doPut(TransactionMessage message, String hostname, int port) throws RemoteException {
        String key = message.getKey();
        String value = message.getValue();
        ServerLogger.info(String.format("Received PUT request from client[%s] with <key=%s, value=%s>", message.getClientId(), key, value));
        currentClient.put(hostname, port);
        // call coordinator to start a transaction
        coordinator.prepare(serverID ,message);
    }

    @Override
    public void doDelete(TransactionMessage message, String hostname, int port) throws RemoteException {
        String key = message.getKey();
        ServerLogger.info(String.format("Received DELETE request from client[%s] with [key=%s]", message.getClientId(), key));
        currentClient.put(hostname, port);
        // call coordinator to start a transaction
        coordinator.prepare(serverID ,message);
    }

    @Override
    public void prepare(TransactionMessage message) throws RemoteException {
        ServerLogger.info("PREPARE: " + message);
        if (message.getType().equals(OperationType.DELETE) && !keyValueStore.containsKey(message.getKey())) {
            // If it's a DELETE operation and the key does not exist, vote to ABORT
            ServerLogger.info("Vote for ABORT due to DELETE request for non-existent key.");
            coordinator.reject(serverID, message);
        } else {
            // For all other conditions, including PUT operations and DELETE operations where the key exists, vote to COMMIT
            ServerLogger.info("Vote for COMMIT");
            coordinator.accept(serverID, message);
        }
    }

    @Override
    public void commit(TransactionMessage message) throws RemoteException {
        String result = null;
        // send ack
        coordinator.acknowledgeCommit(serverID, message);
        ServerLogger.info("COMMITTED: " + message);
        switch (message.getType()) {
            case PUT:
                // do operation
                keyValueStore.put(message.getKey(), message.getValue());
                result = String.format("<key=%s, value=%s> has been successfully stored.", message.getKey(), message.getValue());
                break;
            case DELETE:
                // do operation
                keyValueStore.delete(message.getKey());
                result = "[key=" + message.getKey() + "] has been successfully deleted.";
                break;
        }
        // send response to the client
        responseToClient(result, message);
    }

    @Override
    public void abort(TransactionMessage message) throws RemoteException {
        String result;
        ServerLogger.info("ABORT: " + message);
        // send ack
        coordinator.acknowledgeAbort(serverID, message);
        ServerLogger.info("Transaction aborted. No changes were made.");
        if (message.getType().equals(OperationType.PUT)) {
            result = String.format("The attempted PUT operation for key='%s' with value='%s' was not completed and remains unchanged.", message.getKey(), keyValueStore.get(message.getKey()));
        } else {
            result = String.format("The operation for key='%s' was aborted and did not change the database.", message.getKey());
        }
        // send the response to the client
        responseToClient(result, message);
    }

    /**
     * Sends the result of a transaction operation back to the client.
     *
     * @param result  The result message to send.
     * @param message The original transaction message for context.
     */
    private void responseToClient(String result, TransactionMessage message) {
        if (!currentClient.isEmpty()) {
            String clientHostname = new ArrayList<>(currentClient.keySet()).get(0);
            Integer clientPort = new ArrayList<>(currentClient.values()).get(0);
            currentClient.clear();
            try {
                Client client = (Client) Naming.lookup("rmi://"+ InetAddress.getByName(clientHostname).getHostAddress() + ":" + clientPort + "/Client");
                client.setResponse(serverID, result, message);
                ServerLogger.info("Sent response: " + result);
            } catch (NotBoundException | MalformedURLException | UnknownHostException | RemoteException e) {
                // log if the client lost connection
                ServerLogger.error(String.format("Client[%s] lost connection in sending result[%s] ", message.getClientId(), result));
            }
        }
    }

    @Override
    public String getServerId() throws RemoteException {
        return serverID;
    }

    @Override
    public void synchronizeData(Map<String, String> data) throws RemoteException {
        // synchronize the data the with the coordinator if the server was absent in transactions
        keyValueStore.addAll(data);
        ServerLogger.info("Synchronized the data from the coordinator.");
    }
}
