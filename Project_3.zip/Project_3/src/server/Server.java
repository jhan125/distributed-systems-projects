package server;

import api.KeyValueRpc;
import api.TransactionService;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.rmi.AlreadyBoundException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;


/**
 * Server class initializes a server instance that connects to a specified coordinator
 * and sets up RMI services. It generates a unique server ID, registers the service in the
 * RMI registry, and registers the server with the coordinator.
 */
public class Server {

    /**
     * Constructs a server object, sets up its RMI service, and registers with a coordinator.
     * Initializes the server with the given port, coordinator's hostname, and port.
     *
     * @param port The server's port number as a String.
     * @param coordinatorHostname The hostname of the coordinator.
     * @param coordinatorPort The port number of the coordinator.
     * @throws RemoteException If a remote method call fails.
     * @throws AlreadyBoundException If the server is already bound.
     * @throws NumberFormatException If parsing integers fails.
     * @throws MalformedURLException If the URL for the coordinator is malformed.
     * @throws NotBoundException If the coordinator is not bound in the registry.
     * @throws UnknownHostException If the IP address of the host could not be determined.
     * @throws NoSuchAlgorithmException If the MD5 digest algorithm is not available.
     */
    public Server(String port, String coordinatorHostname, String coordinatorPort) throws RemoteException,
            AlreadyBoundException, NumberFormatException, MalformedURLException, NotBoundException, UnknownHostException, NoSuchAlgorithmException {
        // create a key value storage
        KeyValueStore db = new KeyValueStore();
        // get the coordinator api
        TransactionService coordinator = (TransactionService) Naming.lookup("rmi://"+ InetAddress.getByName(coordinatorHostname).getHostAddress() + ":" + coordinatorPort + "/Transaction");
        // create stub
        String id = generateId(port);
        KeyValueRpc stub = new KeyValueRpcImpl(db, id, coordinator);
        // bind the stub to registry
        Registry registry = LocateRegistry.createRegistry(Integer.parseInt(port));
        registry.bind("Service", stub);
        ServerLogger.info(String.format("Server[%s] is ready at port[%s]", id, port));
        // register at coordinator
        coordinator.registerServer(id, InetAddress.getLocalHost().getHostName(), Integer.parseInt(port));
    }

    /**
     * Generates a unique ID for the server using MD5 hashing of its IP address and port.
     * This ID is used to uniquely identify the server in the network and the coordinator.
     * Reference:
     *
     * @param port The server port to include in the ID generation.
     * @return A String representing the unique server ID.
     * @throws UnknownHostException If the local host name could not be resolved into an address.
     * @throws NoSuchAlgorithmException If the MD5 hashing algorithm is not available.
     */
    // public String generateId(String port) throws UnknownHostException, NoSuchAlgorithmException {
        // String toHash = InetAddress.getLocalHost().getHostAddress() + port;
        // MessageDigest md = MessageDigest.getInstance("MD5");
        // byte[] digest = md.digest(toHash.getBytes(StandardCharsets.UTF_8));
        // return String.format("%032X", new BigInteger(1, digest));
    // }
    public String generateId(String port) throws UnknownHostException {
        // String toHash = InetAddress.getLocalHost().getHostAddress() + port;
        // MessageDigest md = MessageDigest.getInstance("MD5");
        // byte[] digest = md.digest(toHash.getBytes(StandardCharsets.UTF_8));
        // return String.format("%032X", new BigInteger(1, digest));
        return UUID.randomUUID().toString();
    }
}
