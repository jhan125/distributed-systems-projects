package server;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Represents a thread-safe storage for key-value pairs. It uses a {@link ReentrantLock} to
 * ensure that all operations on the key-value store are thread-safe. The class provides methods to
 * insert, update, delete, and retrieve key-value pairs, making it suitable for environments where
 * multiple threads need to access and modify the data concurrently. 
 * Another option is to use a {@link ConcurrentHashMap}. 
 */
 public class KeyValueStore {

    private final Map<String, String> keyValStore;
    private final ReentrantLock mutex = new ReentrantLock();

    /**
     * Constructs a new KeyValueStore instance. Initializes the underlying storage
     * with a HashMap.
     */
    public KeyValueStore() {
        this.keyValStore = new HashMap<>();
    }

    /**
     * Inserts or updates a key-value pair in the store. If the key already exists, its
     * associated value is updated. Otherwise, the key-value pair is added to the store.
     * This operation is thread-safe.
     *
     * @param key The key to insert or update.
     * @param value The value associated with the key.
     */
    public void put(String key, String value) {
        try {
            mutex.lock();
            keyValStore.put(key, value);
            ServerLogger.info(String.format("Added/Updated pair <key=%s, value=%s>.", key, value));
        } finally {
            mutex.unlock();
        }
    }

    /**
     * Deletes a key-value pair from the store if the key exists. This operation is thread-safe.
     *
     * @param key The key of the pair to delete.
     * @return True if the key was found and the pair was deleted, false otherwise.
     */
    public boolean delete(String key) {
        try {
            mutex.lock();
            if (keyValStore.containsKey(key)) {
                keyValStore.remove(key);
                ServerLogger.info(String.format("Deleted key=%s.", key));
                return true;
            } else {
                ServerLogger.error(String.format("Key=%s not found.", key));
                return false;
            }
        } finally {
            mutex.unlock();
        }
    }

    /**
     * Retrieves the value associated with the given key, if it exists. This operation is thread-safe.
     *
     * @param key The key whose value to retrieve.
     * @return The value associated with the key, or null if the key does not exist.
     */
    public String get(String key) {
        try {
            mutex.lock();
            return keyValStore.get(key);
        } finally {
            mutex.unlock();
        }
    }

    /**
     * Checks if the store contains the given key. This operation is thread-safe.
     *
     * @param key The key to check.
     * @return True if the store contains the key, false otherwise.
     */
    public boolean containsKey(String key) {
        try {
            mutex.lock();
            return keyValStore.containsKey(key);
        } finally {
            mutex.unlock();
        }
    }

    /**
     * Adds all the given key-value pairs to the store. Existing keys will be updated
     * with new values. This operation is thread-safe.
     *
     * @param data The key-value pairs to add.
     */
    public void addAll(Map<String, String> data) {
        try {
            mutex.lock();
            keyValStore.putAll(data);
            data.forEach((key, value) -> 
                ServerLogger.info(String.format("Bulk Added/Updated pair <key=%s, value=%s>.", key, value)));
        } finally {
            mutex.unlock();
        }
    }   

    /**
     * Provides a thread-safe way to access the entire key-value store.
     * Returns an unmodifiable view of the map to prevent external modification.
     *
     * @return An unmodifiable view of the key-value store.
     */
    public Map<String, String> getKeyValStore() {
        try {
            mutex.lock();
            return Collections.unmodifiableMap(keyValStore);
        } finally {
            mutex.unlock();
        }
    }
}
