package client;

import java.rmi.Remote;
import java.rmi.RemoteException;

import protocol.TransactionMessage;

/**
 * Represents the behavior of a client in a distributed system. 
 * This interface extends the Remote interface to allow for remote method invocation, enabling the client 
 * to communicate with a server over a network.
 * The client can receive asynchronous responses from the server as a part of the communication protocol.
 */
public interface Client extends Remote {

    /**
     * Allows the server to asynchronously send a response back to the client. This method is intended to be
     * called by the server to deliver the result of a client's request back to the client. The method includes
     * parameters for identifying the server, the response content, and an optional message object that may
     * contain additional data or context about the response.
     *
     * @param serverId          A unique identifier for the server sending the response. This helps the client
     *                         to distinguish responses from different servers if communicating with multiple servers.
     * @param serverResponse   The actual response content sent by the server. This could be the result of a 
     *                         computation, a status update, or any other type of message the server wishes to
     *                         communicate back to the client.
     * @param responseMessage  An optional Message object providing additional context or data about the response.
     *                         This could be used to include metadata, error information, or any other supplementary
     *                         information related to the response.
     * @throws RemoteException If a remote communication error occurs. This exception is thrown to indicate
     *                         communication problems, such as network issues, that prevent the successful
     *                         execution of the remote method call.
     */
    void setResponse(String serverId, String serverResponse, TransactionMessage responseMessage) throws RemoteException;
}