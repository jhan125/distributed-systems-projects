package client;

import api.KeyValueRpc;
import protocol.TransactionMessage;
import protocol.OperationType;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.AlreadyBoundException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.security.InvalidParameterException;
import java.util.*;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * ClientApp is the main class for the client application of a key-value store.
 * It handles command-line arguments to establish connections to the multiple servers and
 * interact with a remote key-value store via RMI.
 * It allows performing basic CRUD operations like get, put, and delete on the key-value store.
 * It starts monitoring for responses and request timeouts as soon as the client is set up.
 * This ensures that the client can handle asynchronous communication with servers,
 * checking for the timely arrival of expected responses or detecting when requests have timed out.
 */
public class ClientApp extends UnicastRemoteObject implements Client {

    // Unique identifier for the client
    private static final UUID clientId = UUID.randomUUID();

    // key: participant servers' IDs, value: server's respective RPC interfaces for communication
    private static final Map<Integer, Map.Entry<String, KeyValueRpc>> participantsConnections = new HashMap<>();

    // key: transaction message, value: responses from servers
    private static final Map<TransactionMessage, String> responseCollector = new HashMap<>();

    // key: transaction requests, time: their timestamps
    private static final Map<TransactionMessage, Long> requestCollector = new HashMap<>();

    // Thread pool for asynchronous tasks
    private static final Executor executor = Executors.newFixedThreadPool(3);

    // Port number for the client's RMI registry
    private static int clientPort;

    public static final String INTERACTION_INSTRUCTIONS = "----------------------------------------\n" +
                                                        "Want to INTERACT with Server?\n" + 
                                                        "Enter a number from [0, 1, 2, 3, 4] to interact with any server.\n" +
                                                        "If you want to exit, just enter [ctrl + C].\n" + 
                                                        "-----------------------------------------\n" +
                                                        "Please enter a server number for the interaction: ";;

    public static final String REQUEST_INSTRUCTIONS = "----------------------------------------\n" +
                                            "How to Enter Your Request:\n" +
                                            "Enter 1: GET the value by a certain key\n" +
                                            "Enter 2: ADD or UPDATE a key-value pair\n" +
                                            "Enter 3: DELETE an existing key-value pair\n" +
                                            "Enter 4: EXIT this program\n" +
                                            "-----------------------------------------\n" +
                                            "Please enter a number for your request: ";

    public static final String INVALID_INTERACTION_INPUT = "Invalid input. Please enter 0 or 1 or 2 or 3 or 4 to select a server.";
    public static final String INVALID_REQUEST_INPUT = "Invalid input. Please enter 1 or 2 or 3 or 4 to select an operation.";
    public static final String INVALID_KEY_OR_VALUE = "Key or value must NOT be NULL or EMPTY. Please enter a valid input.";

    /**
     * Constructs a ClientApp instance and initiates the monitoring of responses and request timeouts.
     * This constructor calls the {@link #monitorResponsesAndTimeouts()} method to start the monitoring process,
     * which is essential for managing asynchronous communication with the server.
     * 
     * @throws RemoteException if an RMI error occurs during client app initialization.
     */
    protected ClientApp() throws RemoteException {
        // as long as the client sets up, start monitoring for responses and request timeouts.
        monitorResponsesAndTimeouts(); 
    }

    /**
     * Main entry point of the application. Parses command-line arguments to
     * establish a connection to the server and handles connection errors.
     *
     * @param args Command-line arguments specifying 5 participant server's hostnames, ports, and client's port.
     */
    public static void main(String[] args) {
        if (args.length < 11) {
            System.out.println("Invalid arguments. Usage: java -jar client.jar " +
                    "<server1-hostname> <server1-port> " +
                    "<server2-hostname> <server2-port> " +
                    "<server3-hostname> <server3-port> " + 
                    "<server4-hostname> <server4-port> " +
                    "<server5-hostname> <server5-port> " +
                    "<client-port> " +
                    "e.g. `java -jar client.jar localhost 4001 localhost 4002 localhost 4003 localhost 4004 localhost 4005 4010`");
            return;
        }

        try {
            // Set up client
            ClientLogger.info(String.format("Client started with ID[%s]", clientId));
            clientPort = Integer.parseInt(args[10]);
            Registry registry = LocateRegistry.createRegistry(clientPort);
            registry.bind("Client", new ClientApp());

            // Establish connections to 5 participant servers
            for (int i = 0; i < 5; i++) {
                KeyValueRpc service = (KeyValueRpc) Naming.lookup("rmi://" + args[i * 2] + ":" + args[i * 2 + 1] + "/Service");
                String serverId = service.getServerId();
                Map.Entry<String, KeyValueRpc> entry = Map.entry(serverId, service);
                participantsConnections.put(i, entry);
                ClientLogger.info(String.format("Connected to server[%s] with serverId[%s]", i, serverId));
            }

            executor.execute(() -> {
                // PRELOAD 5 PUTs, 5 GETs, 5 DELETEs, 5 PUTs to any of the 5 servers
                Map<String, String> preloadData = new LinkedHashMap<>(); // LinkedHashMap to preserve insertion order
                preloadData.put("6650", "Scalable Distributed Systems");
                preloadData.put("5800", "Algorithms");
                preloadData.put("5700", "Computer Networking");
                preloadData.put("6140", "Machine Learning");
                preloadData.put("5200", "Database Management");
                
                ClientLogger.info("Per project requirement, preload operations to any server from [0,1,2,3,4]. ");

                try {
                    preloadData(preloadData);
                } catch (Exception e) {
                    ClientLogger.error("Error occurred when preloading data.");
                
                }
    
                ClientLogger.info("Preload operations completed.");           
            });

            // HANDLE USER INTERACTION
            executor.execute(() -> {
                try {
                    // wait for the pre-populate done 
                    // 5 PUTs, 5 GETs, 5 DELETEs, 5 PUTs 
                    // PUT, DELETE both need about 3600 to complete, GET doesn't need coordinate
                    Thread.sleep(3600 * 15);
                    handleUserInput();
                } catch (IOException | InterruptedException e) {
                    ClientLogger.error("Error occurred when starting user interface.");
                }
            });

        } catch (NotBoundException | IOException e) {
            ClientLogger.error("Cannot find the stub at the given hostnames and ports, or some server is unavailable.");
        } catch (AlreadyBoundException e) {
            ClientLogger.error("Cannot register the client in the given port.");
        }
    }

    /**
     * Preloads data by performing a series of PUT, GET, and DELETE operations.
     * This method simulates client interactions with the server to ensure initial data is populated
     * and subsequently accessed and deleted, testing the full range of CRUD operations.
     *
     * @param preloadData The data to preload, represented as key-value pairs.
     * @throws Exception If there are issues executing preload operations.
     */
    private static void preloadData(Map<String, String> preloadData) throws Exception {
        Random random = new Random();
        // 5 PUTs
        ClientLogger.info("Preload 5 PUTs to any server from [0,1,2,3,4].");  
        preloadData.forEach((key, value) -> {
            try {
                int num = random.nextInt(4);
                KeyValueRpc service = participantsConnections.get(num).getValue();
                TransactionMessage putMessage = new TransactionMessage(UUID.randomUUID(), OperationType.PUT, key, value, clientId);
                service.doPut(putMessage, InetAddress.getLocalHost().getHostName(), clientPort);
                requestCollector.put(putMessage, System.currentTimeMillis());
            } catch (RemoteException | UnknownHostException e) {
                ClientLogger.error(String.format("Error occurred during PUT operation for key: %s", key));
            }
            try {
                Thread.sleep(3500);
            } catch (InterruptedException e) {
                ClientLogger.info("Preload interrupt.");
            }
        });

        // 5 GETs
        ClientLogger.info("Preload 5 GETs to any server from [0,1,2,3,4]."); 
        preloadData.keySet().forEach(key -> {
            try {
                int num = random.nextInt(4);
                KeyValueRpc service = participantsConnections.get(num).getValue();
                ClientLogger.info(String.format("Received response from server[%s]: value=%s", num, service.doGet(clientId, key)));
            } catch (RemoteException e) {
                ClientLogger.error(String.format("Error occurred during GET operation for key: %s", key));
            }
        });

        // 5 DELETEs
        ClientLogger.info("Preload 5 DELETEs to any server from [0,1,2,3,4]."); 
        preloadData.keySet().forEach(key -> {
            try {
                TransactionMessage deleteMessage = new TransactionMessage(UUID.randomUUID(), OperationType.DELETE, key, "", clientId);
                int num = random.nextInt(4);
                KeyValueRpc service = participantsConnections.get(num).getValue();
                service.doDelete(deleteMessage, InetAddress.getLocalHost().getHostName(), clientPort);
                requestCollector.put(deleteMessage, System.currentTimeMillis());
            } catch (RemoteException | UnknownHostException e) {
                ClientLogger.error(String.format("Error occurred during DELETE operation for key: %s", key));
            }
            try {
                Thread.sleep(3500);
            } catch (InterruptedException e) {
                ClientLogger.info("Preload interrupt.");
            }
        });

        // 5 PUTs again
        ClientLogger.info("Preload 5 PUTs to any server from [0,1,2,3,4]."); 
        preloadData.forEach((key, value) -> {
            try {
                TransactionMessage putMessage = new TransactionMessage(UUID.randomUUID(), OperationType.PUT, key, value, clientId);
                int num = random.nextInt(4);
                KeyValueRpc service = participantsConnections.get(num).getValue();
                service.doPut(putMessage, InetAddress.getLocalHost().getHostName(), clientPort);
                requestCollector.put(putMessage, System.currentTimeMillis());
            } catch (RemoteException | UnknownHostException e) {
                ClientLogger.error(String.format("Error occurred during PUT operation for key: %s", key));
            }
            try {
                Thread.sleep(3500);
            } catch (InterruptedException e) {
                ClientLogger.info("Preload interrupt.");
            }
        });
    } 

    /**
     * Handles user input for various operations (GET, PUT, DELETE) on the server.
     * Users can select a server to operate on and then choose the operation to perform.
     * The method supports dynamically showing the available servers based on the current connections.
     *
     * @throws IOException if an error occurs reading input from the console.
     */
    private static void handleUserInput() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        while (true) {
            // Display available servers and prompt for user interaction
            System.out.println("\n" + participantsConnections.keySet().size() + " servers are now available: " + Arrays.toString(participantsConnections.keySet().toArray()));
            System.out.println(INTERACTION_INSTRUCTIONS);

            String serverIdInput = reader.readLine();
            // for better user interface
            serverIdInput = serverIdInput.trim();
            if (serverIdInput.equalsIgnoreCase("exit")) {
                break;
            }

            int serverId = -1;
            try {
                serverId = Integer.parseInt(serverIdInput);
                // Ask user select the server they would like to interact
                if (serverId < 0 || serverId >= participantsConnections.size()) {
                    System.out.println(INVALID_INTERACTION_INPUT);
                    continue;
                }

                // Fetch the selected server's connection
                Map.Entry<String, KeyValueRpc> entry = participantsConnections.get(serverId);
                
                // Process the selected operation
                System.out.println(REQUEST_INSTRUCTIONS);
                String selectedOption = reader.readLine();
                selectedOption = selectedOption.replaceAll("\\s", ""); 
        
                String key, value;
                switch (selectedOption) {
                    case "1": // Get operation
                        System.out.println("Enter the key:");
                        key = reader.readLine();
                        if (key == null || key.trim().isEmpty()) {
                            System.out.println(INVALID_KEY_OR_VALUE);
                            break;
                        }
                        // for better management, trim all inputs
                        key = key.trim();
                        ClientLogger.info(String.format("Sent GET request for key=%s to server[%s]", key, serverId));
                        ClientLogger.info(String.format("Received response from server[%s]: %s", serverId, entry.getValue().doGet(clientId, key)));
                        break;
                    case "2": // Put operation
                        System.out.println("Enter the key:");
                        key = reader.readLine();
                        // for better management, trim all inputs
                        key = key.trim();
                        if (key == null || key.trim().isEmpty()) {
                            System.out.println(INVALID_KEY_OR_VALUE);
                            break;
                        }
                        System.out.println("Enter the value:");
                        value = reader.readLine();
                        // for better management, trim all inputs
                        value = value.trim();
                        if (value == null || value.trim().isEmpty()) {
                            System.out.println(INVALID_KEY_OR_VALUE);
                            break;
                        }
                        TransactionMessage putMessage = new TransactionMessage(UUID.randomUUID(), OperationType.PUT, key, value, clientId);
                        entry.getValue().doPut(putMessage, InetAddress.getLocalHost().getHostName(), clientPort);
                        requestCollector.put(putMessage, System.currentTimeMillis());
                        ClientLogger.info(String.format("Sent PUT request for <key=%s, value=%s> to server[%s]", key, value, serverId));
                        try {
                            Thread.sleep(3500);
                        } catch (InterruptedException e) {
                            ClientLogger.info("Interrupt while waiting for server's response.");
                        }
                        break;
                    case "3": // Delete operation
                        System.out.println("Enter the key:");
                        key = reader.readLine();
                        // for better management, trim all inputs
                        key = key.trim();
                        if (key == null || key.trim().isEmpty()) {
                            System.out.println(INVALID_KEY_OR_VALUE);
                            break;
                        }
                        TransactionMessage deleteMessage = new TransactionMessage(UUID.randomUUID(), OperationType.DELETE, key, null, clientId);
                        entry.getValue().doDelete(deleteMessage, InetAddress.getLocalHost().getHostName(), clientPort);
                        requestCollector.put(deleteMessage, System.currentTimeMillis());
                        ClientLogger.info(String.format("Sent DELETE request for key=%s to server[%s]", key, serverId));
                        try {
                            Thread.sleep(3500);
                        } catch (InterruptedException e) {
                            ClientLogger.info("Interrupt while waiting for server's response.");
                        }
                        break;
                    default:
                        System.out.println(INVALID_REQUEST_INPUT);
                        break;
                }
            } catch (InvalidParameterException | NumberFormatException e) {
                ClientLogger.error("Error occurred when interacting. Please enter a valid input.");
            } catch (RemoteException e) {
                ClientLogger.error(String.format("Lost connection with Server[%s]", serverId));
                // remove the unresponsive server when the client send the request to the server
                participantsConnections.remove(serverId);
            }
        }
        // on close
        reader.close();
        ClientLogger.info("Client successfully exited.");
    }

    /**
     * Handles asynchronous server responses for client requests.
     * Stores the server response in a response collector for later retrieval.
     *
     * @param serverId The identifier of the server sending the response.
     * @param response The response message from the server.
     * @param message  The original transaction message sent to the server.
     * @throws RemoteException if an issue occurs during remote method execution.
     */
    public void setResponse(String serverId, String response, TransactionMessage message) throws RemoteException {
        // Iterate over participantsConnections to find the server by its ID and log its response.
        participantsConnections.forEach((id, serverEntry) -> {
            if (serverEntry.getKey().equals(serverId)) {
                // Store server response associated with the original request message.
                responseCollector.put(message, String.format("Received response from server[%s]: %s", id, response));
            }
        });
    }

    /**
     * Monitors for responses to sent requests and logs them.
     * If a response is not received within a specified timeout period (20 seconds), logs a timeout error.
     * This method runs continuously in a background thread to track request statuses.
     */
    public void monitorResponsesAndTimeouts() {
        executor.execute(() -> {
            while (true) {
                long currentTime = System.currentTimeMillis();
                requestCollector.entrySet().removeIf(entry -> {
                    // set timeout as 30 seconds
                    boolean isTimeout = currentTime - entry.getValue() > 30000;

                    /** TEST: simulate timeout scenario by setting it as 1 second */
                    // boolean isTimeout = currentTime - entry.getValue() > 1000;

                    if (isTimeout) {
                        // Log timeout error if no response is received within the timeout period.
                        ClientLogger.error("TIMEOUT because client cannot receive response for the request: " + entry.getKey());
                    } else {
                        // Check and log received responses.
                        String result = responseCollector.get(entry.getKey());
                        if (result != null) {
                            ClientLogger.info(result);
                            responseCollector.remove(entry.getKey());
                            return true; // Remove the entry from requestCollector after processing.
                        }
                    }
                    return isTimeout; // Remove the entry from requestCollector if it timed out.
                });
    
                try {
                    Thread.sleep(1000); // Wait for a second before checking again.
                } catch (InterruptedException e) {
                    ClientLogger.info("Monitor interrupted");
                    Thread.currentThread().interrupt(); // Restore the interrupted status.
                }
            }
        });
    }
}

